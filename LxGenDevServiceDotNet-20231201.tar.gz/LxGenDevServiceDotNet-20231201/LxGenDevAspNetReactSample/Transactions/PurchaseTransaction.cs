﻿//#define USE_MOCK_DEVICE_PINPAD

using LxGenDevAspNetReactSample.Devices;
using Microsoft.AspNetCore.DataProtection.KeyManagement;
using System.Diagnostics;
using System.Text;

namespace LxGenDevAspNetReactSample.Transactions
{
    /*
    # Purchase Sequence
      - Select Wallet (Create Wallet/Scan Wallet)
        - Scan Wallet
      - Insert Card
      - Select Amount
      - Type PIN
      - Wait Transaction
      - Print Receipt
      - Thanks
    */
    public class PurchaseTransaction
    {
        enum Page {
            Page_PrintReceipt,
            Page_Thanks,
            Page_SelectWalletType,
            Page_InsertCard,
            Page_ScanWallet,
            Page_GetPin,
            Page_SelectAmount,
            Page_ProcessingTransaction,
        }

        private String? _wallet;
        private Decimal? _amount;
        private String? _cardTrack2;
        private bool? _createNewWallet;
        private String? _pinBlock;

        private IPageController _pageController;
        private LinuxDeviceService _deviceService;

        private Page _currentPage = Page.Page_SelectWalletType;

        private bool _startedPinEncryption = false;

        public PurchaseTransaction(IPageController pageController, LinuxDeviceService deviceService)
        {
            _pageController = pageController;
            _deviceService = deviceService;
        }

        public async Task StartTransaction()
        {
            _deviceService.PinPad.OnKeyPressed += PinPad_OnKeyPressed;
            _deviceService.PinPad.OnEncryptCompleted += PinPad_OnEncryptCompleted;
            _deviceService.PinPad.OnEncryptStarted += PinPad_OnEncryptStarted;
            
            _deviceService.BarcodeScanner.OnScanCodeCompleted += BarcodeScanner_OnScanCodeCompleted;
            _deviceService.CardReader.OnCardReadCompleted += CardReader_OnCardReadCompleted;

            await GotoSelectWalletTypePage();
        }

        private async Task EndTransaction()
        {
            if (_startedPinEncryption)
            {
                _deviceService.PinPad.EndEncryptPIN();
                _startedPinEncryption = false;
            }

            _deviceService.PinPad.OnKeyPressed -= PinPad_OnKeyPressed;
            _deviceService.PinPad.OnEncryptCompleted -= PinPad_OnEncryptCompleted;
            _deviceService.PinPad.OnEncryptStarted -= PinPad_OnEncryptStarted;
            
            _deviceService.BarcodeScanner.OnScanCodeCompleted -= BarcodeScanner_OnScanCodeCompleted;
            _deviceService.CardReader.OnCardReadCompleted -= CardReader_OnCardReadCompleted;

            await _pageController.DisplayPageAsync("home");
        }

        public async Task CancelTransaction()
        {
            await EndTransaction();
        }

        private void PinPad_OnEncryptStarted(object? sender, EventArgs e)
        {
            _startedPinEncryption = true;
        }

        private async void PinPad_OnEncryptCompleted(object? sender, string pinBlock)
        {
            _pinBlock = pinBlock;
            // Got PIN
            await GotoProcessTransactionPage();
        }

        private void PinPad_OnKeyPressed(object? sender, string key)
        {
            if (key == "CANCEL")
            {
                _ = CancelTransaction();
                return;
            }

            switch(_currentPage)
            {
                case Page.Page_GetPin:
                    //
                    // Don't display garbage data.
                    //
                    if (_startedPinEncryption)
                    {
                        _pageController.OnKeyPressed(key);
                    }
                    break;
                default:
                    _pageController.OnKeyPressed(key);
                    break;
            }
        }

        private async void CardReader_OnCardReadCompleted(object? sender, LxGenDevCardReader.CardReaderTrack tracks)
        {
            _cardTrack2 = tracks.Track2;
            await GotoSelectAmountPage();
        }

        private async void BarcodeScanner_OnScanCodeCompleted(object? sender, string barcode)
        {
            _wallet = barcode;
            await _pageController.OnScanCode(barcode);
        }

        public async Task SelectWallet(bool createNewWallet)
        {
            _createNewWallet = createNewWallet;
            if (createNewWallet)
            {
                _wallet = Guid.NewGuid().ToString();
                await GotoInsertCardPage();
            }
            else
            {
                await GotoScanWalletPage();
            }
        }

        public async Task SelectAmount(decimal amount)
        {
            _amount = amount;
            await GotoGetPinPage();
        }

        public async Task ConfirmWallet(string wallet)
        {
            _wallet = wallet;
            await GotoInsertCardPage();
        }

        private async Task GotoSelectWalletTypePage()
        {
            _currentPage = Page.Page_SelectWalletType;

            await _pageController.DisplayPageAsync("purchase-select-wallet");
        }

        private async Task GotoScanWalletPage()
        {
            _currentPage = Page.Page_ScanWallet;

            await _pageController.DisplayPageAsync("purchase-scan-wallet");

            _deviceService.BarcodeScanner.AcceptScanCode(false) ;
        }

        private async Task GotoInsertCardPage()
        {
            _currentPage = Page.Page_InsertCard;

            await _pageController.DisplayPageAsync("purchase-insert-card");

            _deviceService.Indicator.SetIndicatorById(-1, false);
            _deviceService.Indicator.SetIndicatorByIdEx(LinuxDeviceService.FLICKER_CARDREADER, true, 0 );

            _deviceService.CardReader.AcceptCard(-1);
        }

        private async Task GotoSelectAmountPage()
        {
            _currentPage = Page.Page_SelectAmount;

            await _pageController.DisplayPageAsync("purchase-select-amount");

#if USE_MOCK_DEVICE_PINPAD
            _ = Task.Run(() =>
            {
                Thread.Sleep(2000);

                _pageController.OnKeyPressed("1");
                _pageController.OnKeyPressed("0");
                _pageController.OnKeyPressed("0");
            });
#endif
        }

        private async Task GotoProcessTransactionPage()
        {
            _currentPage = Page.Page_ProcessingTransaction;

            await _pageController.DisplayPageAsync("processing-tran");

            _ = Task.Run(() =>
            {
                Thread.Sleep(3000);

                // Transaction Completed;

                _ = GotoPrintReceiptPage();
            });
        }

        private async Task GotoThanksPage()
        {
            await _pageController.DisplayPageAsync("thanks");

            _ = Task.Run(() =>
            {
                Thread.Sleep(5000);

                // Transaction Completed;

                _ = EndTransaction();
            });
        }

        private async Task GotoPrintReceiptPage()
        {
            _currentPage = Page.Page_PrintReceipt;

            await _pageController.DisplayPageAsync("print-receipt");

            _deviceService.Indicator.SetIndicatorById(-1, false);
            _deviceService.Indicator.SetIndicatorByIdEx(LinuxDeviceService.FLICKER_RECEIPTPRINTER, true, 0);

            String imgPath = Path.Combine(_pageController.GetWebRootPath(), "img", "bitcoin-logo.png");
            _deviceService.ReceiptPrinter.PrintImage(imgPath, false, 0, 0);

            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Bitcoin Purchase Receipt");
            sb.AppendLine("");
            sb.AppendLine($"Transaction ID: {Guid.NewGuid().ToString()}");
            sb.AppendLine("");
            sb.AppendLine($"Date: {DateTime.Now.ToShortDateString()} {DateTime.Now.ToShortTimeString()}");
            sb.AppendLine($"Address: {_wallet}");

            sb.AppendLine($"Exchange rate: $8390.55");
            sb.AppendLine($"Cash Amount: ${_amount}");
            sb.AppendLine($"Bitcoin Purchased: 0.00476727");
            sb.AppendLine("");
            sb.AppendLine("");
            sb.AppendLine("Phone Support: 1 (000) 000-0000");
            sb.AppendLine("Email Support: support@yourdomain.com");
            sb.AppendLine("");
            sb.Append("\u001b02"); // Horizontal Double Size
            sb.Append("\u001b12"); // Vertical Double Size
            sb.AppendLine("Thank you");
            sb.Append("\u001b01"); // Horizontal Normal Size
            sb.Append("\u001b11"); // Vertical Normal Size

            _deviceService.ReceiptPrinter.PrintText(sb.ToString(), true);

            await GotoThanksPage();
        }

        private async Task GotoGetPinPage()
        {
            _currentPage = Page.Page_GetPin;

            // Turn off all flickers.
            _deviceService.Indicator.SetIndicatorById(-1, false);
            _deviceService.Indicator.SetIndicatorByIdEx(LinuxDeviceService.FLICKER_PINPAD, true, 0);

            _deviceService.PinPad.EncryptPIN(_cardTrack2, 4, true);

            await _pageController.DisplayPageAsync("purchase-get-pin");
        }
    }
}
