﻿namespace LxGenDevAspNetReactSample.Transactions
{
    public interface IPageController
    {
        Task DisplayPageAsync(string pageName);
        Task OnKeyPressed(string key);
        Task OnScanCode(string code);
        String GetWebRootPath();
    }
}
