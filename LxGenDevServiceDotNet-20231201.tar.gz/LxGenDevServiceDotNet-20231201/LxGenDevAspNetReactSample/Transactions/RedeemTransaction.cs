﻿//#define USE_MOCK_DEVICE_PINPAD

using System.Text;
using LxGenDevAspNetReactSample.Devices;
using LxGenDevCashDispenser;
using Microsoft.AspNetCore.DataProtection.KeyManagement;

namespace LxGenDevAspNetReactSample.Transactions
{
    /*
    # Redeem
        - Enter Redeem Code
        - Enter Authentication Code
        - Wait Transaction
        - Dispese Cash
        - Print Receipt
        - Thanks
    */
    public class RedeemTransaction
    {
        enum Page
        {
            Page_PrintReceipt,
            Page_Thanks,
            Page_EnterRedeemCode,
            Page_EnterAuthenCode,
            Page_ProcessTransaction,
            Page_DispenseCash,
        }

        private string? _redeemCode;
        private string? _authenCode;
        private decimal? _amount;

        IPageController _pageController;
        LinuxDeviceService _deviceService;

        private Page _currentPage;

        public RedeemTransaction(IPageController pageController, LinuxDeviceService deviceService)
        {
            _pageController = pageController;
            _deviceService = deviceService;
        }

        public async Task StartTransaction()
        {
            _deviceService.PinPad.OnKeyPressed += PinPad_OnKeyPressed;
            _deviceService.CashDispenser.OnDispenseCompleted += CashDispenser_OnDispenseCompleted;

            await GotoEnterRedeemCodePage();
        }

        private async Task EndTransaction()
        {
            _deviceService.PinPad.OnKeyPressed -= PinPad_OnKeyPressed;
            _deviceService.CashDispenser.OnDispenseCompleted -= CashDispenser_OnDispenseCompleted;

            await _pageController.DisplayPageAsync("home");
        }

        public async Task CancelTransaction()
        {
            await EndTransaction();
        }

        private void CashDispenser_OnDispenseCompleted(object? sender, DispenseCompleted e)
        {
            _ = GotoPrintReceiptPage();
        }

        private void PinPad_OnKeyPressed(object? sender, string key)
        {
            if (key == "CANCEL")
            {
                _ = EndTransaction();
                return;
            }

            if (_currentPage != Page.Page_EnterRedeemCode && _currentPage != Page.Page_EnterAuthenCode)
                return;

            _pageController.OnKeyPressed(key);
        }

        private async Task GotoEnterRedeemCodePage()
        {
            _currentPage = Page.Page_EnterRedeemCode;
            _deviceService.Indicator.SetIndicatorById(-1, false);
            _deviceService.Indicator.SetIndicatorByIdEx(LinuxDeviceService.FLICKER_PINPAD, true, 0);
            await _pageController.DisplayPageAsync("redeem-enter-redeem-code");
#if USE_MOCK_DEVICE_PINPAD
            _ = Task.Run(() =>
            {
                Thread.Sleep(2000);

                _pageController.OnKeyPressed("1");
                Thread.Sleep(500);
                _pageController.OnKeyPressed("2");
                Thread.Sleep(500);
                _pageController.OnKeyPressed("3");
                Thread.Sleep(500);
                _pageController.OnKeyPressed("4");
                Thread.Sleep(500);
                _pageController.OnKeyPressed("5");
                Thread.Sleep(500);
                _pageController.OnKeyPressed("6");
            });
#endif
        }

        private async Task GotoEnterAuthenCodePage()
        {
            _currentPage = Page.Page_EnterAuthenCode;
            _deviceService.Indicator.SetIndicatorById(-1, false);
            _deviceService.Indicator.SetIndicatorByIdEx(LinuxDeviceService.FLICKER_PINPAD, true,0);
            await _pageController.DisplayPageAsync("redeem-enter-authen-code");
#if USE_MOCK_DEVICE_PINPAD
            _ = Task.Run(() =>
            {
                Thread.Sleep(2000);

                _pageController.OnKeyPressed("4");
                Thread.Sleep(500);
                _pageController.OnKeyPressed("5");
                Thread.Sleep(500);
                _pageController.OnKeyPressed("6");
                Thread.Sleep(500);
                _pageController.OnKeyPressed("9");
                Thread.Sleep(500);
                _pageController.OnKeyPressed("5");
                Thread.Sleep(500);
                _pageController.OnKeyPressed("1");
            });
#endif
        }

        private async Task GotoProcessTransactionPage()
        {
            _currentPage = Page.Page_ProcessTransaction;

            await _pageController.DisplayPageAsync("processing-tran");

            _ = Task.Run(() =>
            {
                Thread.Sleep(3000);

                // Transaction Completed;
                _amount = 20;
                _ = GotoDispenseCashPage();
            });
        }

        private async Task GotoDispenseCashPage()
        {
            _currentPage = Page.Page_DispenseCash;
            _deviceService.Indicator.SetIndicatorById(-1, false);
            _deviceService.Indicator.SetIndicatorByIdEx(LinuxDeviceService.FLICKER_CASHDISPENSER, true, 0);
            await _pageController.DisplayPageAsync("redeem-dispense-cash");
            _deviceService.CashDispenser.Dispense(2, 0, 0, 0, 0, 0);
        }

        private async Task GotoPrintReceiptPage()
        {
            _currentPage = Page.Page_PrintReceipt;
            _deviceService.Indicator.SetIndicatorById(-1, false);
            _deviceService.Indicator.SetIndicatorByIdEx(LinuxDeviceService.FLICKER_RECEIPTPRINTER, true, 0);

            await _pageController.DisplayPageAsync("print-receipt");

            _deviceService.Indicator.SetIndicatorById(-1, false);
            _deviceService.Indicator.SetIndicatorByIdEx(LinuxDeviceService.FLICKER_RECEIPTPRINTER, true, 0);

            String imgPath = Path.Combine(_pageController.GetWebRootPath(), "img", "bitcoin-logo.png");
            _deviceService.ReceiptPrinter.PrintImage(imgPath, false, 0, 0);

            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"Bitcoin Redeem Receipt");
            sb.AppendLine("");
            sb.AppendLine($"Transaction ID: {Guid.NewGuid().ToString()}");
            sb.AppendLine("");
            sb.AppendLine($"Date: {DateTime.Now.ToShortDateString()} {DateTime.Now.ToShortTimeString()}");
            sb.AppendLine($"Redeem Code: {_redeemCode}");
            sb.AppendLine($"Cash Amount: ${_amount}");
            sb.AppendLine($"Bitcoin Redeemed: 0.00476727");
            sb.AppendLine("");
            sb.AppendLine("");
            sb.AppendLine("Phone Support: 1 (000) 000-0000");
            sb.AppendLine("Email Support: support@yourdomain.com");
            sb.AppendLine("");
            sb.Append("\u001b02"); // Horizontal Double Size
            sb.Append("\u001b12"); // Vertical Double Size
            sb.AppendLine("Thank you");
            sb.Append("\u001b01"); // Horizontal Normal Size
            sb.Append("\u001b11"); // Vertical Normal Size

            _deviceService.ReceiptPrinter.PrintText(sb.ToString(), true);         

            await GotoThanksPage();
        }

        private async Task GotoThanksPage()
        {
            _currentPage = Page.Page_Thanks;
            _deviceService.Indicator.SetIndicatorById(-1, false);
            _deviceService.Indicator.SetIndicatorByIdEx(LinuxDeviceService.FLICKER_CASHTRAY, true, 0);
            await _pageController.DisplayPageAsync("thanks");

            _ = Task.Run(() =>
            {
                Thread.Sleep(5000);

                // Transaction Completed;

                _ = EndTransaction();
            });
        }

        public async Task SetRedeemCode(string redeemCode)
        {
            _redeemCode = redeemCode;
            await GotoEnterAuthenCodePage();
        }

        public async Task SetAuthenCode(string authenCode)
        {
            _authenCode = authenCode;
            await GotoProcessTransactionPage();
        }
    }
}
