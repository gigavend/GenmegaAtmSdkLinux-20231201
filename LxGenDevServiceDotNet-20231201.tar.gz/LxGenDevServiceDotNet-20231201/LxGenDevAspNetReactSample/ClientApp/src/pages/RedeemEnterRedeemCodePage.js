﻿import React, { Component } from 'react';
import { Logo } from '../components/Logo'
import { KioskClient } from '../KioskClient';

export class RedeemEnterRedeemCodePage extends Component {
    static displayName = RedeemEnterRedeemCodePage.name;

    constructor(props) {
        super(props);
        this.state = { valueRedeemCode: '' };
        this.kioskClient = KioskClient.getInstance();
        this.setRedeemCode = this.setRedeemCode.bind(this);

        this.kioskClient.onKeyPress = (key) => {
            if (key === "ENTER") {
                this.setRedeemCode();
                return;
            }
            this.setState((prevState) => {
                const newState = {
                    valueRedeemCode: prevState.valueRedeemCode + key
                }
                return newState;
            });
        }
    }

    setRedeemCode = () => {
        this.kioskClient.redeemSetRedeemCode(this.state.valueRedeemCode);
    };

    render() {
        return (
            <>
                <Logo />
                <h1>Enter Redeem Code</h1>
                <div className="page-content">
                    <div className="menu-list">
                        <input type="text" className="menu-item" value={this.state.valueRedeemCode} readOnly ></input>
                        <button onClick={(e) => { this.setRedeemCode() }} className="menu-item">Next</button>
                    </div>
                </div>
                <div className="toolbar">
                    <button onClick={ (e) => this.kioskClient.cancelRedeem() } className="toolbar-item">Cancel</button>
                </div>
            </>
        );
    }
}
