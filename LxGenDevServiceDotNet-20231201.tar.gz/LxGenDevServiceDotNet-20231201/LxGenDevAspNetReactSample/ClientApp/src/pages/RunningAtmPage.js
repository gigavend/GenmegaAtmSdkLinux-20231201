﻿import React, { Component, useEffect } from 'react';
import { Logo } from '../components/Logo'
import { KioskClient } from '../KioskClient';

export class RunningAtmPage extends Component {
    static displayName = RunningAtmPage.name;

    constructor(props) {
        super(props);
        this.kioskClient = KioskClient.getInstance();
    }

    render() {
        return (
            <>
                <Logo />
                <div className="page-content">
                </div>
            </>
        );
    }
}
