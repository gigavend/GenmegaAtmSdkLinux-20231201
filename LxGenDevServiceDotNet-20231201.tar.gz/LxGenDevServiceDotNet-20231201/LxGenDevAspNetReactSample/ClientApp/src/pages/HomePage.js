import React, { Component } from 'react';
import { Logo } from '../components/Logo'
import { KioskClient } from '../KioskClient';

export class HomePage extends Component {
    static displayName = HomePage.name;

    constructor(props) {
        super(props);
        this.kioskClient = KioskClient.getInstance();
    }


    startPurchase() {
        this.kioskClient.startPurchase();
    }

    startRedeem() {
        this.kioskClient.startRedeem();
    }

    startAtmTransaction() {
        this.kioskClient.startAtmApp("transaction");
    }

    startAtmOp() {
        this.kioskClient.startAtmApp("op");
    }

    render() {
        return (
            <>
                <Logo />
                <h1>Select Transaction</h1>
                <div className="page-content">
                    <div className="menu-list">
                        <button onClick={this.startPurchase.bind(this)} className="menu-item">Buy</button>
                        <button onClick={this.startRedeem.bind(this)} className="menu-item">Redeem</button>
                        <button onClick={this.startAtmTransaction.bind(this)} className="menu-item">ATM</button>
                    </div>
                </div>
                <div className="toolbar">
                    <button onClick={this.startAtmOp.bind(this)} className="toolbar-item">ATM OP</button>
                </div>
            </>
        );
    }
}


