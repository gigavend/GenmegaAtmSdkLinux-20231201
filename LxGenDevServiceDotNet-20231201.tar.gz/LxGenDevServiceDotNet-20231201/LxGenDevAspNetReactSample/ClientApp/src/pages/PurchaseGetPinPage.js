﻿import React, { Component } from 'react';
import { Logo } from '../components/Logo'
import { KioskClient } from '../KioskClient';

export class PurchaseGetPinPage extends Component {
    static displayName = PurchaseGetPinPage.name;

    constructor(props) {
        super(props);
        this.state = { valuePin: '' };
        this.kioskClient = KioskClient.getInstance();

        this.kioskClient.onKeyPress = (key) => {
            if (key === "ENTER") {
                return;
            }
            
            this.setState((prevState) => {
                const newState = {
                    valuePin: prevState.valuePin + key
                }
                return newState;
            });
        }
    }

    render() {
        return (
            <>
                <Logo />
                <h1>Enter Your PIN</h1>
                <div className="page-content">
                    <div className="menu-list">
                        <input type="text" id="textboxPin" className="menu-item" value={this.state.valuePin} readOnly ></input>
                    </div>
                </div>
                <div className="toolbar">
                    <button onClick={ (e) => this.kioskClient.cancelPurchase() } className="toolbar-item">Cancel</button>
                </div>
            </>
        );
    }
}
