﻿import React, { Component } from 'react';
import { Logo } from '../components/Logo'
import { KioskClient } from '../KioskClient';

export class PurchaseSelectWalletPage extends Component {
    static displayName = PurchaseSelectWalletPage.name;

    constructor(props) {
        super(props);
        this.kioskClient = KioskClient.getInstance();
    }

    selectWalletType(walletType) {
        this.kioskClient.purchaseSelectWalletType(walletType);
    }

    render() {
        return (
            <>
                <Logo />
                <h1>Select Wallet</h1>
                <div className="page-content">
                    <div className="home-page">
                        <div className="menu-list">
                            <button onClick={(e) => this.selectWalletType("NewWallet")} className="menu-item">New Wallet</button>
                            <button onClick={(e) => this.selectWalletType("ScanWallet")} className="menu-item">Scan Wallet</button>
                        </div>
                    </div>
                </div>
                <div className="toolbar">
                    <button onClick={ (e) => this.kioskClient.cancelPurchase() } className="toolbar-item">Cancel</button>
                </div>
            </>
        );
    }
}
