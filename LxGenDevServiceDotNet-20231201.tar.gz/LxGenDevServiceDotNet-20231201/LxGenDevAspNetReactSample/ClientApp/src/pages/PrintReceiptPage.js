﻿import React, { Component } from 'react';
import { Logo } from '../components/Logo'

export class PrintReceiptPage extends Component {
    static displayName = PrintReceiptPage.name;

    render() {
        return (
            <>
                <Logo />
                <div className="page-content">
                    <h1>Printing a receipt</h1>
                </div>
            </>
        );
    }
}
