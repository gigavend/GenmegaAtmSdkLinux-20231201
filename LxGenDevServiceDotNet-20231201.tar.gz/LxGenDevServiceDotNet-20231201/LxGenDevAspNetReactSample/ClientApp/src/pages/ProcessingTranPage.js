﻿import React, { Component } from 'react';
import { Logo } from '../components/Logo'

export class ProcessingTranPage extends Component {
    static displayName = ProcessingTranPage.name;

    render() {
        return (
            <>
                <Logo />
                <div className="page-content">
                    <h1>Processing your transaction</h1>
                </div>
            </>
        );
    }
}
