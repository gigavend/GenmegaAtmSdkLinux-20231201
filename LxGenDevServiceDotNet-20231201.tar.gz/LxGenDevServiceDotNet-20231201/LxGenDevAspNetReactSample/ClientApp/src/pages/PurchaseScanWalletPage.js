﻿import React, { Component } from 'react';
import { Logo } from '../components/Logo'
import { KioskClient } from '../KioskClient';

export class PurchaseScanWalletPage extends Component {
    static displayName = PurchaseScanWalletPage.name;

    constructor(props) {
        super(props);
        this.state = { valueWallet: '' };
        this.kioskClient = KioskClient.getInstance();

        this.kioskClient.onKeyPress = (key) => {
            if (key === "ENTER") {
                this.confirmWallet();
            }
        }

        this.kioskClient.onScanCode = (code) => {
            this.setState({ valueWallet: code });
        }
    }

    confirmWallet = () => {
        this.kioskClient.purchaseConfirmWallet(this.state.valueWallet);
    };

    render() {
        return (
            <>
                <Logo />
                <h1>Scan your wallet</h1>
                <div className="page-content">
                    <div className="menu-list">
                        <input type="text" className="menu-item" value={this.state.valueWallet} readOnly ></input>
                        <button onClick={(e) => { this.confirmWallet() }} className="menu-item">Next</button>
                    </div>
                </div>
                <div className="toolbar">
                    <button onClick={ (e) => this.kioskClient.cancelPurchase() } className="toolbar-item">Cancel</button>
                </div>
            </>
        );
    }
}
