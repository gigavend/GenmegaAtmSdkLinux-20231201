﻿import React, { Component } from 'react';
import { Logo } from '../components/Logo'

export class RedeemDispenseCashPage extends Component {
    static displayName = RedeemDispenseCashPage.name;

    render() {
        return (
            <>
                <Logo />
                <div className="page-content">
                    <h1>Dispensing cash...</h1>
                </div>
            </>
        );
    }
}
