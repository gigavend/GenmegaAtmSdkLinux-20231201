﻿import React, { Component } from 'react';
import { Logo } from '../components/Logo'

export class ThanksPage extends Component {
    static displayName = ThanksPage.name;

    render() {
        return (
            <>
                <Logo />
                <div className="page-content">
                    <h1>Thank you</h1>
                </div>
            </>
        );
    }
}
