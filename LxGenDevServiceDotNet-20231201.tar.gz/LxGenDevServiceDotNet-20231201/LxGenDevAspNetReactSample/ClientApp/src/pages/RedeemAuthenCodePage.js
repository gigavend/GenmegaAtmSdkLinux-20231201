﻿import React, { Component } from 'react';

export class RedeemAuthenCodePage extends Component {
    static displayName = RedeemAuthenCodePage.name;

    render() {
        return (
            <div>
                <h1>RedeemAuthenCodePage</h1>
            </div>
        );
    }
}
