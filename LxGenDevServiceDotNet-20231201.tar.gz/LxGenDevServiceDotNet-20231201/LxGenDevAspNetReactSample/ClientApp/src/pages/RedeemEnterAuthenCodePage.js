﻿import React, { Component } from 'react';
import { Logo } from '../components/Logo'
import { KioskClient } from '../KioskClient';

export class RedeemEnterAuthenCodePage extends Component {
    static displayName = RedeemEnterAuthenCodePage.name;

    constructor(props) {
        super(props);
        this.state = { valueAuthenCode: '' };
        this.kioskClient = KioskClient.getInstance();
        this.setAuthenCode = this.setAuthenCode.bind(this);

        this.kioskClient.onKeyPress = (key) => {
            if (key === "ENTER") {
                this.setAuthenCode();
                return;
            }
            this.setState((prevState) => {
                const newState = {
                    valueAuthenCode: prevState.valueAuthenCode + key
                }
                return newState;
            });
        }
    }

    setAuthenCode = () => {
        this.kioskClient.redeemSetAuthenCode(this.state.valueRedeemCode);
    };

    render() {
        return (
            <>
                <Logo />
                <h1>Enter Authentication Code</h1>
                <div className="page-content">
                    <div className="menu-list">
                        <input type="text" className="menu-item" value={this.state.valueAuthenCode} readOnly ></input>
                        <button onClick={(e) => { this.setAuthenCode() }} className="menu-item">Next</button>
                    </div>
                </div>
                <div className="toolbar">
                    <button onClick={ (e) => this.kioskClient.cancelRedeem() } className="toolbar-item">Cancel</button>
                </div>
            </>
        );
    }
}
