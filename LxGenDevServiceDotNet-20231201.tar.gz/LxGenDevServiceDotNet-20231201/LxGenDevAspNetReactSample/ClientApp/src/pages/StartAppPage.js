﻿import React, { Component } from 'react';
import { Logo } from '../components/Logo'
import { KioskClient } from '../KioskClient';

export class StartAppPage extends Component {
    static displayName = StartAppPage.name;

    constructor(props) {
        super(props);
        this.kioskClient = KioskClient.getInstance();
    }

    render() {
        return (
            <>
                <Logo />
                <div className="page-content">
                    <h1>Initializing...</h1>
                </div>
            </>
        );
    }
}

//export InitializePage;

//function InitializePage(props) {
//    return (
//        <div>HELLO</div>
//    );
//}





//import React, { Component } from 'react';
//import { useNavigate } from 'react-router-dom';

//export class InitializePage extends Component {
//    static displayName = InitializePage.name;

//    constructor(props) {
//        super(props);
//        this.state = { forecasts: [], loading: true };
//    }

//    componentDidMount() {
//        this.initializeDevices();
//    }

//    async initializeDevices() {
//        const navigate = useNavigate();
//        const response = await fetch('kiosk/InitializeApplication');
//        //const data = await response.json();
//        //this.setState({ forecasts: data, loading: false });
//        navigate('/')
//    }

//    static renderPage(forecasts) {
//        return (
//            <table className="table table-striped" aria-labelledby="tableLabel">
//                <thead>
//                    <tr>
//                        <th>Date</th>
//                        <th>Temp. (C)</th>
//                        <th>Temp. (F)</th>
//                        <th>Summary</th>
//                    </tr>
//                </thead>
//                <tbody>
//                    {forecasts.map(forecast =>
//                        <tr key={forecast.date}>
//                            <td>{forecast.date}</td>
//                            <td>{forecast.temperatureC}</td>
//                            <td>{forecast.temperatureF}</td>
//                            <td>{forecast.summary}</td>
//                        </tr>
//                    )}
//                </tbody>
//            </table>
//        );
//    }

//    render() {
//        let contents = this.state.loading
//            ? <p><em>Intializing ...</em></p>
//            : InitializePage.renderPage(this.state.forecasts);

//        return (
//            <div>
//                <h1 id="tableLabel">Weather forecast</h1>
//                <p>This component demonstrates fetching data from the server.</p>
//                {contents}
//            </div>
//        );
//    }
//}
