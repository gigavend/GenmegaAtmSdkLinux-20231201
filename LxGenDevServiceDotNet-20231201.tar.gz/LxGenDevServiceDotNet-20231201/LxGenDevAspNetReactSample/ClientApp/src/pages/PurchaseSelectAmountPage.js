﻿import React, { Component } from 'react';
import { Logo } from '../components/Logo'
import { KioskClient } from '../KioskClient';

export class PurchaseSelectAmountPage extends Component {
    static displayName = PurchaseSelectAmountPage.name;

    constructor(props) {
        super(props);
        this.state = { valueAmount: '' };
        this.kioskClient = KioskClient.getInstance();
        this.selectAmount = this.selectAmount.bind(this);

        this.kioskClient.onKeyPress = (key) => {
            if (key === "ENTER") {
                this.selectAmount();
                return;
            }
            this.setState((prevState) => {
                const newState = {
                    valueAmount: prevState.valueAmount + key
                }
                return newState;
            });
        }
    }

    selectAmount = () => {
        this.kioskClient.purchaseSelectAmount(this.state.valueAmount);
    };

    render() {
        return (
            <>
                <Logo />
                <h1>Enter Amount</h1>
                <div className="page-content">
                    <div className="menu-list">
                        <input type="text" id="textboxAmount" className="menu-item" value={this.state.valueAmount} readOnly ></input>
                        <button onClick={(e) => { this.selectAmount() }} className="menu-item">Next</button>
                    </div>
                </div>
                <div className="toolbar">
                    <button onClick={ (e) => this.kioskClient.cancelPurchase() } className="toolbar-item">Cancel</button>
                </div>
            </>
        );
    }
}
