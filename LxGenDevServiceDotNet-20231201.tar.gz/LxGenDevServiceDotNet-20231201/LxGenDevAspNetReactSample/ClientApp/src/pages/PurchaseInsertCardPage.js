﻿import React, { Component } from 'react';
import { Logo } from '../components/Logo'
import { KioskClient } from '../KioskClient';

export class PurchaseInsertCardPage extends Component {
    static displayName = PurchaseInsertCardPage.name;

    constructor(props) {
        super(props);
        this.kioskClient = KioskClient.getInstance();
    }

    cancelTransaction() {
        this.kioskClient.cancelPurchase();
    }

    render() {
        return (
            <>
                <Logo />
                <div className="page-content">
                    <h1>Insert your card</h1>
                </div>
                <div className="toolbar">
                    <button onClick={ (e) => this.kioskClient.cancelPurchase() } className="toolbar-item">Cancel</button>
                </div>
            </>
        );
    }
}
