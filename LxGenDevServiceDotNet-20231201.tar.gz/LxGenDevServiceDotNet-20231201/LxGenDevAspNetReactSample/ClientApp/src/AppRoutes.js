import { Counter } from "./components/Counter";
import { FetchData } from "./components/FetchData";

import { HomePage } from "./pages/HomePage";

import { PurchaseGetPinPage } from "./pages/PurchaseGetPinPage"
import { PurchaseInsertCardPage } from "./pages/PurchaseInsertCardPage"
import { PurchaseScanWalletPage } from "./pages/PurchaseScanWalletPage"
import { PurchaseSelectAmountPage } from "./pages/PurchaseSelectAmountPage"
import { PurchaseSelectWalletPage } from "./pages/PurchaseSelectWalletPage"

import { RedeemEnterRedeemCodePage } from "./pages/RedeemEnterRedeemCodePage"
import { RedeemEnterAuthenCodePage } from "./pages/RedeemEnterAuthenCodePage"
import { RedeemDispenseCashPage } from "./pages/RedeemDispenseCashPage"

import { PrintReceiptPage } from "./pages/PrintReceiptPage"
import { StartAppPage } from "./pages/StartAppPage";
import { ThanksPage } from "./pages/ThanksPage"
import { ProcessingTranPage } from "./pages/ProcessingTranPage"
import { RunningAtmPage } from "./pages/RunningAtmPage";

const AppRoutes = [
    {
        path: '/home',
        element: <HomePage />
    },
    {
        path: '/running-atm',
        element: <RunningAtmPage />
    },
    // Purchasing
    {
        path: '/purchase-get-pin',
        element: <PurchaseGetPinPage />
    },
    {
        path: '/purchase-insert-card',
        element: <PurchaseInsertCardPage />
    },
    {
        path: '/purchase-scan-wallet',
        element: <PurchaseScanWalletPage />
    },
    {
        path: '/purchase-select-amount',
        element: <PurchaseSelectAmountPage />
    },
    {
        path: '/purchase-select-wallet',
        element: <PurchaseSelectWalletPage />
    },
    {
        path: '/redeem-enter-redeem-code',
        element: <RedeemEnterRedeemCodePage />
    },
    {
        path: '/redeem-enter-authen-code',
        element: <RedeemEnterAuthenCodePage />
    },
    {
        path: '/redeem-dispense-cash',
        element: <RedeemDispenseCashPage />
    },
    {
        path: '/print-receipt',
        element: <PrintReceiptPage />
    },
    {
        index: true,
        element: <StartAppPage />
    },
    {
        path: '/thanks',
        element: <ThanksPage />
    },
    {
        path: '/processing-tran',
        element: <ProcessingTranPage />
    },
    {
        path: '/fetch-data',
        element: <FetchData />
    },
];

export default AppRoutes;
