﻿import * as signalR from "@microsoft/signalr";

const URL = process.env.HUB_ADDRESS ?? "http://localhost:5118/hub"; //or whatever your backend port is

export class KioskClient {
    static instance;

    startApplication() {
        this.connection.invoke("StartApplication")
            .catch(function (err) {
                return console.error(err.toString());
            });
    }

    setHookObjects(navigate) {
        this.navigate = navigate;
    }

    startAtmApp(mode) {
        this.connection.invoke("StartAtmApp", mode)
            .catch(function (err) {
                return console.error(err.toString());
            });
    }

    startPurchase() {
        this.connection.invoke("StartPurchase")
            .catch(function (err) {
                return console.error(err.toString());
            });
    }

    cancelPurchase() {
        this.connection.invoke("CancelPurchase")
            .catch(function (err) {
                return console.error(err.toString());
            });
    }

    purchaseSelectWalletType(walletType) {
        this.connection.invoke("PurchaseSelectWalletType", walletType)
            .catch(function (err) {
                return console.error(err.toString());
            });
    }

    purchaseSelectAmount(amount) {
        this.connection.invoke("PurchaseSelectAmount", amount)
            .catch(function (err) {
                return console.error(err.toString());
            });
    }

    purchaseConfirmWallet(wallet) {
        this.connection.invoke("PurchaseConfirmWallet", wallet)
            .catch(function (err) {
                return console.error(err.toString());
            });
    }

    startRedeem() {
        this.connection.invoke("StartRedeem")
            .catch(function (err) {
                return console.error(err.toString());
            });
    }

    cancelRedeem() {
        this.connection.invoke("CancelRedeem")
            .catch(function (err) {
                return console.error(err.toString());
            });
    }

    redeemSetRedeemCode(redeemCode) {
        this.connection.invoke("RedeemSetRedeemCode", redeemCode)
            .catch(function (err) {
                return console.error(err.toString());
            });
    }

    redeemSetAuthenCode(redeemCode) {
        this.connection.invoke("RedeemSetAuthenCode", redeemCode)
            .catch(function (err) {
                return console.error(err.toString());
            });
    }

    constructor() {
        if (KioskClient.instance)
            return KioskClient.instance;

        this.connection = new signalR.HubConnectionBuilder()
            .withUrl(URL)
            .withAutomaticReconnect()
            .build();

        this.connection.on("event", (eventName) => {
            //onMessageReceived(username, message);
            console.log("EVENT: " + eventName);
            this.navigate('/');
        });

        this.connection.on("key-press", (key) => {
            this.onKeyPress(key);
        });

        this.connection.on("scan-code", (code) => {
            this.onScanCode(code);
        });

        this.connection.on("error", (message) => {

        });

        this.connection.on("displayPage", (pagePath) => {
            this.navigate("/" + pagePath);
            console.debug("moving page to /" + pagePath);
        });

        this.connection.start()
            .then(() => {
                console.log("Connected SignalR client");
                this.startApplication();
            })
            .catch(err => console.log(err));

        KioskClient.instance = this;
    }

    static getInstance() {
        if (!KioskClient.instance)
            KioskClient.instance = new KioskClient();
        return KioskClient.instance;
    }
}
