import React, { Component } from 'react';
import { Container } from 'reactstrap';
//import { NavMenu } from './NavMenu';
import { Head } from './Head';
import { Logo } from './Logo';

export class Layout extends Component {
    static displayName = Layout.name;

    render() {
        return (
            <Container tag="main">
                <Head />
                <div className="page">
                    {this.props.children}
                </div>
            </Container>
        );
    }
}
