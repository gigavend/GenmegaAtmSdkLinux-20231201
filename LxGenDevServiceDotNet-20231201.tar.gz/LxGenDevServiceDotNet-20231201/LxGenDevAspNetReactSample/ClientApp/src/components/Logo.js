﻿export function Logo() {
    console.log("Rendered Logo....");
    return (
        <div className="logo">
            <img src="/img/bitcoin-btc-logo.svg" alt="logo" ></img>
        </div>
    );
}