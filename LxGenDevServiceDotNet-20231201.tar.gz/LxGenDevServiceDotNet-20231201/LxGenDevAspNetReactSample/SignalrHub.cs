﻿//#define USE_MOCK_APPMANAGER
using System.Diagnostics;
using LxGenDevAppManager;
using LxGenDevAspNetReactSample.Devices;
using LxGenDevAspNetReactSample.Devices.MockDevices;
using LxGenDevAspNetReactSample.Transactions;
using Microsoft.AspNetCore.DataProtection.KeyManagement;
using Microsoft.AspNetCore.SignalR;

namespace LxGenDevAspNetReactSample
{
    public class SignalrHub : Hub, IPageController
    {
        private PurchaseTransaction? _purchaseTransaction;
        private RedeemTransaction? _redeemTransaction;
        private LinuxDeviceService _deviceService;
        private IWebHostEnvironment _webHostEnvironment;

#if USE_MOCK_APPMANAGER
        private MockAppManager? _appManager;
#else
        private GenDevAppManager? _appManager;
#endif

        //
        //  True if the Kiosk application support ATM function.
        //
        public bool AtmAppIntegrated { get; set; }

        public SignalrHub(LinuxDeviceService deviceService,IWebHostEnvironment webHostEnvironment)
        {
            AtmAppIntegrated = true;

            _deviceService = deviceService;
            _webHostEnvironment = webHostEnvironment;

            if (AtmAppIntegrated)
            {
                _appManager = new();
                _appManager.OnChangedActiveApp += _appManager_OnChangedActiveApp;
                _appManager.OnInitializedApp += _appManager_OnInitializedApp;
            }
        }

        public async Task StartApplication()
        {
            //
            // Register current application in application manager.
            // ATM appication is registered as "com.genmega.atm".
            //
            _appManager?.RegisterApp("com.genmega.bitcoin", "BitcoinKiosk");

            //
            // Execute ATM application first.
            // OnAppMgrEventInitializedApp event will be fired after ATM application is initialized.
            //
            if (AtmAppIntegrated)
            {
                Process.Start("/usr/local/bin/LxATM", "");
            }
            else
            {
                await _deviceService.OpenDevices(AtmAppIntegrated);
                await DisplayPageAsync("home");
            }
        }

        //
        // Fired when ATM application finished initializing.
        //
        private async void _appManager_OnInitializedApp(object? sender, InitializedApp e)
        {
            switch(e.AppId)
            {
                case "com.genmega.atm":
                    if (e.Succeeded)
                    {
                        _appManager.ActivateApp("com.genmega.bitcoin", "");
                        
                        //
                        // If your application runs as standalone without ATM app. integration,
                        // integratedAtmmApp parameter shold be false.
                        //
                        await _deviceService.OpenDevices(AtmAppIntegrated);

                        await DisplayPageAsync("home");
                    }
                    break;
                case "com.genmega.bitcoin":
                    break;
            }
        }

        //
        // Fired whenever ATM or Kiosk application changed active status.
        //
        private async void _appManager_OnChangedActiveApp(object? sender, ChangedActiveApp e)
        {
            if (e.AppId == "com.genmega.atm")
            {
                if (e.Active)
                {
                    //
                    // Started ATM transaction or operating menu above this kiosk application.
                    // Need to wait finishing ATM transaction or exit OP menu.
                    // 
                    await DisplayPageAsync("running-atm");
                }
                else
                {
                    //
                    // Finished an ATM transaction.
                    // Go back to transaction selection page.
                    //
                    await DisplayPageAsync("home");

                    //
                    //
                    //
                    switch(e.Mode)
                    {
                        case "daytotal":
                            Console.WriteLine($"ATM DayTotal Result: {_appManager.GetAppResult("com.genmega.atm")}");
                            break;
                        case "op":
                            Console.WriteLine("Exit ATM OP menu");
                            break;
                        default:
                            // Finished a transaction
                            Console.WriteLine($"ATM Transaction Result: {_appManager.GetAppResult("com.genmega.atm")}");
                            break;
                    }
                }
            }
        }

        // Implements of IPageController
        //
        // Send event when the react pages should be changed.
        //
        public async Task DisplayPageAsync(string pagePath)
        {
            Debug.WriteLine($"DisplayPageAsync {pagePath}");
            await Clients.All.SendAsync("displayPage", pagePath);
        }

        // Implements of IPageController
        //
        // Send event when PinPad pressed keys.
        // Then react page update UI.
        //
        public async Task OnKeyPressed(string key)
        {
            await Clients.All.SendAsync("key-press", key);
        }

        // Implements of IPageController
        //
        // Send event when barcode scanner got some data.
        // Then react page can update UI.
        //
        public async Task OnScanCode(string code)
        {
            await Clients.All.SendAsync("scan-code", code);
        }

        //
        // React page call StartAtmApp when user hit 'ATM' application button.
        //
        public void StartAtmApp(string mode)
        {
            _appManager.ActivateApp("com.genmega.atm", mode);
        }

        //
        // For purchase transaction.
        //
        public async Task StartPurchase()
        {
            _purchaseTransaction = new PurchaseTransaction(this, _deviceService);
            await _purchaseTransaction.StartTransaction();
        }

        public async Task CancelPurchase()
        {
            if (_purchaseTransaction == null)
            {
                return;
            }
            await _purchaseTransaction.CancelTransaction();
        }

        public async Task PurchaseSelectWalletType(String walletType)
        {
            if (_purchaseTransaction == null)
            {
                return;
            }
            await _purchaseTransaction.SelectWallet(walletType == "NewWallet");
        }

        public async Task PurchaseSelectAmount(String amount)
        {
            if (_purchaseTransaction == null)
            {
                return;
            }
            await _purchaseTransaction.SelectAmount(decimal.Parse(amount));
        }

        public async Task PurchaseConfirmWallet(String wallet)
        {
            if (_purchaseTransaction == null)
            {
                return;
            }
            await _purchaseTransaction.ConfirmWallet(wallet);
        }

        //
        // For redeem transaction
        //
        public async Task StartRedeem()
        {
            _redeemTransaction = new RedeemTransaction(this, _deviceService);
            await _redeemTransaction.StartTransaction();
        }

        public async Task CancelRedeem()
        {
            if (_redeemTransaction == null)
            {
                return;
            }
            await _redeemTransaction.CancelTransaction();
        }

        public async Task RedeemSetRedeemCode(string redeemCode)
        {
            if (_redeemTransaction == null)
            {
                return;
            }
            await _redeemTransaction.SetRedeemCode(redeemCode);
        }

        public async Task RedeemSetAuthenCode(string authenCode)
        {
            if (_redeemTransaction == null)
            {
                return;
            }
            await _redeemTransaction.SetAuthenCode(authenCode);
        }

        public string GetWebRootPath()
        {
#if DEBUG
            return Path.Combine(Directory.GetCurrentDirectory(), "ClientApp","public");
#else
            return Path.Combine(Directory.GetCurrentDirectory(), "wwwroot");
#endif
        }
    }
}
