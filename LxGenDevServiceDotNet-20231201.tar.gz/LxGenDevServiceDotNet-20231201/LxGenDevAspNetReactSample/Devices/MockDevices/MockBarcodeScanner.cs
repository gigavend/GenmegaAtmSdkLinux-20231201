﻿using LxGenDevBarcodeScanner;

namespace LxGenDevAspNetReactSample.Devices.MockDevices
{
    public class MockBarcodeScanner
    {
        // Properties
        public string PortPath { get;set; }
        public int BaudRate { get; set; }
        public int ByteSize { get; set; }
        public int Parity { get; set; }
        public int StopBits { get; set; }
        public bool TraceLog { get; set; }
        public bool ScanMode { get; set; }
        public bool MobilePhoneMode { get; set; }
        public String Version { get; }
        public String StDevice { get; }

        public MockBarcodeScanner()
        {
        }

        // Events
        public event EventHandler<String>? OnDeviceOpened;
        public event EventHandler? OnDeviceClosed;
        public event EventHandler<int>? OnDeviceError;
        public event EventHandler? OnScancodeError;
        public event EventHandler? OnScancodeCancel;
        public event EventHandler? OnResetCompleted;
        public event EventHandler? OnSendSerialCommandCompleted;
        public event EventHandler<String>? OnScanCodeCompleted;
        public event EventHandler<String>? OnScanDataCompleted;

        // Methods
        public void OpenDevice()
        {
            Task.Run(() =>
            {
                Thread.Sleep(1);
                OnDeviceOpened?.Invoke(this, PortPath);
            });
        }

        public void CloseDevice()
        {
            Task.Run(() =>
            {
                Thread.Sleep(1);
                OnDeviceClosed?.Invoke(this, new());
            });
        }

        public void AcceptScanCode(bool flag)
        {
            Task.Run(() =>
            {
                Thread.Sleep(2000);
                OnScanCodeCompleted?.Invoke(this, Guid.NewGuid().ToString());
            });
        }

        public void CancelScanCode()
        {
        }

        public void ResetDevice()
        {
        }

        public void SendSerialCommand(string command)
        {
        }
    }
}
