﻿using LxGenDevAppManager;
using System.Text;

namespace LxGenDevAspNetReactSample.Devices.MockDevices
{
    public class MockAppManager
    {
        public event EventHandler<ChangedActiveApp>? OnChangedActiveApp;
        public event EventHandler<InitializedApp>? OnInitializedApp;

        public MockAppManager() 
        {
            Task.Run(() =>
            {
                Thread.Sleep(10 * 1000);
                OnInitializedApp?.Invoke(this, new InitializedApp(true, "com.genmega.atm"));
            });
        }

        public bool RegisterApp(string appId, string appName)
        {
            return true;
        }

        public bool ActivateApp(string appId, string mode)
        {
            return true;
        }

        public string GetAppResult(string appId)
        {
            return "";
        }

    }
}
