﻿using LxGenDevIndicator;
using System.Text;

namespace LxGenDevAspNetReactSample.Devices.MockDevices
{
    public class MockIndicator
    {
        // Properties
        public string PortPath { get; set; }
        public int BaudRate { get; set; }
        public int ByteSize { get; set; }
        public int Parity { get; set; }
        public int StopBits { get; set; }
        public bool TraceLog { get; set; }
        public string LED1_RGB { get; set; }
        public string LED2_RGB { get; set; }
        public string LED3_RGB { get; set; }
        public string LED4_RGB { get; set; }
        public string LED5_RGB { get; set; }
        public string LED6_RGB { get; set; }
        public string FLK1_RGB { get; set; }
        public string FLK2_RGB { get; set; }
        public string FLK3_RGB { get; set; }
        public string FLK4_RGB { get; set; }
        public string FLK5_RGB { get; set; }
        public string FLK6_RGB { get; set; }
        public string FLK7_RGB { get; set; }
        public string FLK8_RGB { get; set; }
        public string FLK9_RGB { get; set; }
        public string FLK11_RGB { get; set; }
        public string Proximity { get; }
        public string StDevice { get; }
        public string StDoor { get; }
        public string StDoor2 { get; }
        public string StDoor3 { get; }
        public string StDoor4 { get; }
        public string StDoor5 { get; }
        public string StDoor6 { get; }
        public string StDoor7 { get; }
        public string StDoor8 { get; }
        public string StDoor9 { get; }
        public string Version { get; }

        public MockIndicator()
        {
        }

        // Methods
        public void OpenDevice()
        {
            Task.Run(() =>
            {
                Thread.Sleep(1000);
                OnDeviceOpened?.Invoke(this, PortPath);
            });
        }

        public void CloseDevice()
        {
            Task.Run(() =>
            {
                Thread.Sleep(1000);
                OnDeviceClosed?.Invoke(this, new());
            });
        }

        public void Initialize()
        {
            Task.Run(() =>
            {
                Thread.Sleep(1000);
                OnInitialized?.Invoke(this, new());
            });
        }

        public void SetIndicatorById(short IndicatorID, bool State)
        {
        }

        public void SetIndicatorByName(string IndicatorName, bool State)
        {
        }

        public string GetIndicatorNames()
        {
            return "";
        }

        public void SetIndicatorNames(string IndicatorNames)
        {
        }

        public void SetWatchDog(bool State)
        {
        }

        public void SetFeedAction()
        {
        }

        public void SetIndicatorByIdEx(short IndicatorID, bool State, short Mode)
        {
        }

        public void SetIndicatorByNameEx(string IndicatorName, bool State, short Mode)
        {
        }

        public void SetLED(bool State, short Mode)
        {
        }

        public void SetIndicatorRGB()
        {
        }

        public void McrPowerReset()
        {
        }

        // Events
        public event EventHandler<String>? OnDeviceOpened;
        public event EventHandler? OnDeviceClosed;
        public event EventHandler? OnInitialized;
        public event EventHandler<SetIndicatorCompleted>? OnSetIndicatorCompleted;
        public event EventHandler<short>? OnDeviceError;
        public event EventHandler<short>? OnFunctionKeyPressed;
        public event EventHandler<short>? OnFunctionKeyReleased;
        public event EventHandler<string>? OnAudioGuidanceChanged;
        public event EventHandler<StatusChanged>? OnStatusChanged;
        public event EventHandler? OnSetFeedActionCompleted;
        public event EventHandler? OnSetLEDCompleted;
        public event EventHandler<string>? OnAdminSwitchChanged;
        public event EventHandler? OnSetIndicatorRGBCompleted;
        public event EventHandler? OnMcrPowerResetCompleted;
    }
}
