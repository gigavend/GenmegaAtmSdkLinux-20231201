﻿using LxGenDevCashDispenser;

namespace LxGenDevAspNetReactSample.Devices.MockDevices
{
    public class MockCashDispenser
    {
        // Properties
        public string PortPath { get; set; }
        public int BaudRate { get; set; }
        public int ByteSize { get; set; }
        public int Parity { get; set; }
        public int StopBits { get; set; }
        public long PollingInterval { get; set; }
        public bool TraceLog { get; set; }
        public string CountryCode { get; }
        public short CassetteNumber { get; }
        public string CDUType { get; }
        public string Version { get; }

        public bool EnableDispenseProcessingEvent { get; set; }

        public string ManufactorType { get; }
        public string StDevice { get; }
        public string StTransporter { get; }
        public string StCassette { get; }
        public string StCstOutlet { get; }
        public string ErrorCode { get; }
        public string StCassetteID1 { get; }
        public string StCassetteID2 { get; }
        public string StCassetteID3 { get; }
        public string StCassetteID4 { get; }
        public string StCassetteID5 { get; }
        public string StCassetteID6 { get; }
        public bool XPCduShutter { get; set; }
        public string StExitSensor { get; }

        public MockCashDispenser()
        {
        }

        // Methods
        public void OpenDevice(string LicenseKey)
        {
            Task.Run(() =>
            {
                Thread.Sleep(1000);
                OnDeviceOpened?.Invoke(this, LicenseKey);
            });
        }

        public void CloseDevice()
        {
            Task.Run(() =>
            {
                Thread.Sleep(1000);
                OnDeviceClosed?.Invoke(this, new());
            });
        }

        public void Initialize(bool Force)
        {
            Task.Run(() =>
            {
                Thread.Sleep(1000);
                OnInitialized?.Invoke(this, new());
            });
        }

        public void GetCDUInformation()
        {
            Task.Run(() =>
            {
                Thread.Sleep(1000);
                OnGetCDUInfoCompleted?.Invoke(this, new CDUInfo( "USA", 1, "HCDU", "Genmega", "Mock 1.0" ));
            });
        }


        public void SetCDUInformation(string CountryCode, short CassetteCount, string CDUType)
        {
            Task.Run(() =>
            {
                Thread.Sleep(1000);
                OnSetCDUInfoCompleted?.Invoke(this, new());
            });
        }

        public void TestDispense(short ReqCount1, short ReqCount2, short ReqCount3, short ReqCount4)
        {
            Task.Run(() =>
            {
                Thread.Sleep(1000);
                OnTestDispenseCompleted?.Invoke(this, new TestDispenseCompleted("", "", "", "","",""));
            });
        }

        public void Dispense(short ReqCount1, short ReqCount2, short ReqCount3, short ReqCount4, short ReqCount5, short ReqCount6)
        {
            Task.Run(() =>
            {
                Thread.Sleep(1000);
                OnDispenseCompleted?.Invoke(this, new DispenseCompleted("", "", "", "", "","",""));
            });
        }

        public void Present()
        {
            Task.Run(() =>
            {
                Thread.Sleep(1000);
                OnPresentCompleted?.Invoke(this, new());
            });
        }

        public void ShutterAction(bool Open)
        {
            Task.Run(() =>
            {
                Thread.Sleep(1000);
                OnShutterActionCompleted?.Invoke(this, new());
            });
        }

        public void Retract()
        {
            Task.Run(() =>
            {
                Thread.Sleep(1000);
                OnRetractCompleted?.Invoke(this, new());
            });
        }


        public void ExitPurge()
        {
        }

        // Events
        public event EventHandler<String>? OnDeviceOpened;
        public event EventHandler? OnDeviceClosed;
        public event EventHandler? OnInitialized;
        public event EventHandler<CDUInfo>? OnGetCDUInfoCompleted;
        public event EventHandler? OnSetCDUInfoCompleted;
        public event EventHandler<Status>? OnStatusChanged;
        public event EventHandler<DispenseCount>? OnDispenseProcessing;
        public event EventHandler<DispenseFailed>? OnDispenseFailed;
        public event EventHandler<DispenseCompleted>? OnDispenseCompleted;
        public event EventHandler<TestDispenseFailed>? OnTestDispenseFailed;
        public event EventHandler<TestDispenseCompleted>? OnTestDispenseCompleted;
        public event EventHandler<short>? OnDeviceError;
        public event EventHandler? OnPresentCompleted;
        public event EventHandler? OnShutterActionCompleted;
        public event EventHandler? OnRetractCompleted;
        public event EventHandler<DenominationDispenseCompleted>? OnDenominationDispenseCompleted;
        public event EventHandler? OnExitPurgeCompleted;
    }
}
