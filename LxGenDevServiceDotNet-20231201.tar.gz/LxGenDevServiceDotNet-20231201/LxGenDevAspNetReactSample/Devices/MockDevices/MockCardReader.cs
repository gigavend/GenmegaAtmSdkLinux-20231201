﻿using LxGenDevCardReader;
using System.Text;

namespace LxGenDevAspNetReactSample.Devices.MockDevices
{
    public class MockCardReader
    {
        // Properties
        public string PortPath {  get; set; }

        public int BaudRate {  get; set; }

        public int ByteSize {  get; set; }

        public int Parity {  get; set; }

        public int StopBits {  get; set; }

        public bool TraceLog {  get; set; }

        public int MCRType {  get; set; }

        public int EMVOption {  get; set; }

        public string StDevice { get; }

        public string StMedia { get; }

        public string Version { get; }

        public string SensorInfo { get; }

        public MockCardReader()
        {
        }

        // Methods
        public void OpenDevice()
        {
            Task.Run(() =>
            {
                Thread.Sleep(1000);
                OnDeviceOpened?.Invoke(this, PortPath);
            });
        }

        public void CloseDevice()
        {
            Task.Run(() =>
            {
                Thread.Sleep(1000);
                OnDeviceClosed?.Invoke(this, new());
            });
        }

        public void AcceptCard(long waitTimeout)
        {
            Task.Run(() =>
            {
                Thread.Sleep(1000);
                OnCardPresented?.Invoke(this, new());
                Thread.Sleep(1000);
                OnCardReadCompleted?.Invoke(this, new CardReaderTrack("track1", "track2", ""));
            });
        }

        public void CancelAccept()
        {
            Task.Run(() =>
            {
                Thread.Sleep(1000);
                OnAcceptCardCanceled?.Invoke(this, new());
            });
        }

        public void PowerReset()
        {
        }

        public void EjectCard()
        {
            Task.Run(() =>
            {
                Thread.Sleep(1000);
                OnEjectCardCompleted?.Invoke(this, new());
            });
        }

        public void AcceptEmvCard(long waitTimeout)
        {
            Task.Run(() =>
            {
                Thread.Sleep(1000);
                OnCardPresented?.Invoke(this, new());
                Thread.Sleep(1000);
                OnCardReadCompleted?.Invoke(this, new CardReaderTrack("track1", "track2", ""));
            });
        }

        public string ChipIO(string data)
        {
            return "";
        }

        public string GetATRasChipReset()
        {
            return "";
        }

        public string ICDirection(string icSend)
        {
            return "";
        }

        // EMV Methods
        public void EMV_parameter_init(int terminalType, string termID, string paramPath)
        {
        }

        public void EMV_set_term(int seq_cnt)
        {
        }

        public void EMV_transaction_type_select(int tranType)
        {
        }

        public void EMV_account_type_select(int accType)
        {
        }

        public void EMV_application_selection(int keyValue)
        {
        }

        public string EMV_get_candidateList()
        {
            return "";
        }

        public void EMV_read_application()
        {
        }

        public void EMV_offline_data_authentication()
        {
        }

        public void EMV_processing_restrictions()
        {
        }

        public void EMV_cardholder_verification(ref string pinValue)
        {
        }

        public void EMV_terminal_risk_management()
        {
        }

        public void EMV_terminal_action_analysis()
        {
        }

        public void EMV_set_purchase_amount(int type, int amount)
        {
        }

        public void EMV_card_action_analysis()
        {
        }

        public void EMV_online_reversal()
        {
        }

        public void EMV_online_confirm()
        {
        }

        public void EMV_online_advice()
        {
        }

        public void EMV_online_reject()
        {
        }

        public void EMV_online_referral()
        {
        }

        public void EMV_emvkrnl_unable_online()
        {
        }

        public void EMV_online_process(string arc, string iad, string issuerscript)
        {
        }

        public void EMV_completion()
        {
        }

        public string EMV_read_dataElemet(string tagName)
        {
            return "";
        }


        // Events
        public event EventHandler<String>? OnDeviceOpened;
        public event EventHandler? OnDeviceClosed;
        public event EventHandler? OnCardNotPresented;
        public event EventHandler? OnCardPresented;
        public event EventHandler<CardReaderTrack>? OnCardReadCompleted;
        public event EventHandler? OnCardReadError;
        public event EventHandler? OnAcceptCardCanceled;
        public event EventHandler<int>? OnDeviceError;
        public event EventHandler? OnPowerResetCompleted;
        public event EventHandler? OnChipResetCompleted;
        public event EventHandler? OnChipResetError;
        public event EventHandler? OnEjectCardCompleted;
        public event EventHandler? OnStatusChanged;
    }
}
