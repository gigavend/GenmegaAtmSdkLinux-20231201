﻿using LxGenDevEncryptingPinPad;

namespace LxGenDevAspNetReactSample.Devices.MockDevices
{
    public class MockPinPad
    {
        // Properties
        public string PortPath {  get; set; }

        public int BaudRate { get; set; }

        public int ByteSize { get; set; }

        public int Parity { get; set; }

        public int StopBits { get; set; }

        public bool TraceLog { get; set; }

        public String Version { get; }
        public String PCIVersion { get; }
        public String SerialNumber { get; }


        public MockPinPad()
        {
        }

        // Methods
        public void OpenDevice()
        {
            Task.Run(() =>
            {
                Thread.Sleep(1);
                OnDeviceOpened?.Invoke(this, PortPath);
            });
        }

        public void CloseDevice()
        {
            Task.Run(() =>
            {
                Thread.Sleep(1);
                OnDeviceClosed?.Invoke(this, new());
            });
        }

        public void Initialize()
        {
            Task.Run(() =>
            {
                Thread.Sleep(1);
                OnInitialized?.Invoke(this, new());
            });
        }

        public void EncryptPIN(string AccountNo, short LeastLen, bool EnterKey)
        {
            Task.Run(() =>
            {
                Thread.Sleep(1000);
                
                OnKeyPressed?.Invoke(this, "*");
                Thread.Sleep(500);
                OnKeyPressed?.Invoke(this, "*");
                Thread.Sleep(500);
                OnKeyPressed?.Invoke(this, "*");
                Thread.Sleep(500);
                OnKeyPressed?.Invoke(this, "*");
                Thread.Sleep(500);
                OnEncryptCompleted?.Invoke(this, "2134234234234234234");
            });
        }

        public void MockAmount()
        {
            Task.Run(() =>
            {
                Thread.Sleep(1000);

                OnKeyPressed?.Invoke(this, "1");
                Thread.Sleep(500);
                OnKeyPressed?.Invoke(this, "0");
                Thread.Sleep(500);
                OnKeyPressed?.Invoke(this, "0");
                Thread.Sleep(500);
            });
        }

        public void MockRedeemCode()
        {
            Task.Run(() =>
            {
                Thread.Sleep(1000);

                OnKeyPressed?.Invoke(this, "1");
                Thread.Sleep(500);
                OnKeyPressed?.Invoke(this, "2");
                Thread.Sleep(500);
                OnKeyPressed?.Invoke(this, "3");
                Thread.Sleep(500);
                OnKeyPressed?.Invoke(this, "4");
                Thread.Sleep(500);
                OnKeyPressed?.Invoke(this, "5");
                Thread.Sleep(500);
            });
        }

        public void MockRedeemAuthCode()
        {
            Task.Run(() =>
            {
                Thread.Sleep(1000);

                OnKeyPressed?.Invoke(this, "8");
                Thread.Sleep(500);
                OnKeyPressed?.Invoke(this, "8");
                Thread.Sleep(500);
                OnKeyPressed?.Invoke(this, "8");
                Thread.Sleep(500);
                OnKeyPressed?.Invoke(this, "8");
                Thread.Sleep(500);
                OnKeyPressed?.Invoke(this, "9");
                Thread.Sleep(500);
                OnKeyPressed?.Invoke(this, "9");
                Thread.Sleep(500);
                OnKeyPressed?.Invoke(this, "9");
                Thread.Sleep(500);
            });
        }

        public void ClearAllData()
        {
        }


        public void EncryptByMac(string AccountNo, long Len)
        {
        }

        public void EPPDownlaodKey(short KeyMode, string Key1, string Key2, string Key3, string MacKey)
        {
        }

        public void ConfirmKeyValue(short KeyMode)
        {
        }

        public void GetKeyStatus(short KeyMode)
        {
        }

        public void GetActiveKey(short KeyMode)
        {
        }

        public void GetKeyMode()
        {
        }

        public void CancelEncryptPIN()
        {
            Task.Run(() =>
            {
                Thread.Sleep(1000);

                OnEncryptCanceled?.Invoke(this, new());
            });
        }

        public void SetKeyMode(short KeyMode)
        {
        }

        public void SetActiveKey(short KeyIndex)
        {
        }

        public void EndEncryptPIN()
        {
            //Task.Run(() =>
            //{
            //    Thread.Sleep(1000);
            //});
        }

        public void CallKeyManagementApp()
        {
        }

        public void InputControl(bool Enable)
        {
        }

        public void InjectKey(short KeyMode, short KeyIndex, short InputPart, short InputType)
        {
        }

        public void CheckSensitivePwd(short Part)
        {
        }

        public void GetStatus()
        {
        }

        public void ChangeSensitivePwd(short Part, short InputType)
        {
        }

        public void DownloadTRKey(short InputPart, string TRKey)
        {
        }

        public void AuthorizedMoving(string Pwd, string UserID)
        {
        }

        public void AuthorizedFixing(string Pwd, string UserID)
        {
        }

        public void DownloadNPKey(string Key1, string Key2, string Key3)
        {
        }

        // Events
        public event EventHandler<String>? OnDeviceOpened;
        public event EventHandler? OnDeviceClosed;
        public event EventHandler? OnInitialized;
        public event EventHandler<String>? OnKeyPressed;
        public event EventHandler<String>? OnKeyReleased;
        public event EventHandler<String>? OnEncryptCompleted;
        public event EventHandler? OnClearDataCompleted;
        public event EventHandler<CheckSum>? OnDownloadKeyCompleted;
        public event EventHandler<CheckSum>? OnConfirmKeyCompleted;
        public event EventHandler? OnEncryptCanceled;
        public event EventHandler? OnEncryptStarted;
        public event EventHandler<KeyStatus>? OnGetKeyStatusCompleted;
        public event EventHandler<GetActiveKeyResult>? OnGetActiveKeyCompleted;
        public event EventHandler<short>? OnGetKeyModeCompleted;
        public event EventHandler<short>? OnDeviceError;
        public event EventHandler? OnSetKeyModeCompleted;
        public event EventHandler<SetActiveKeyResult>? OnSetActiveKeyCompleted;
        public event EventHandler? OnInputControlCompleted;
        public event EventHandler<String>? OnInjectKeyCompleted;
        public event EventHandler? OnInjectKeyStarted;
        public event EventHandler? OnSetSecureModeCompleted;
        public event EventHandler? OnSetSecureModeStarted;
        public event EventHandler<String>? OnGetStatusCompleted;
        public event EventHandler? OnChangePasswordCompleted;
        public event EventHandler? OnChangePasswordStarted;
        public event EventHandler? OnDownloadTRKeyCompleted;
        public event EventHandler? OnAuthorizedMovingCompleted;
        public event EventHandler? OnAuthorizedFixingCompleted;
    }
}
