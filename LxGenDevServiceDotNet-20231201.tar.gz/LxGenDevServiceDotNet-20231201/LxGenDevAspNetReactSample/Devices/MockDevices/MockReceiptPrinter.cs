﻿using LxGenDevReceiptPrinter;

namespace LxGenDevAspNetReactSample.Devices.MockDevices
{
    public class MockReceiptPrinter
    {
        // Events
        public event EventHandler<String>? OnDeviceOpened;
        public event EventHandler? OnDeviceClosed;
        public event EventHandler? OnInitialized;
        public event EventHandler? OnPrinted;
        public event EventHandler? OnCut;
        public event EventHandler<ReceiptPrinterStatus>? OnChangedStatus;
        public event EventHandler<int>? OnDeviceError;
        public event EventHandler<ReceiptMargin>? OnGotVerticalMargin;
        public event EventHandler? OnSetVerticalMargin;

        // Properties
        public string PortPath {  get; set; }

        public int BaudRate {  get; set; }

        public int ByteSize {  get; set; }

        public int Parity {  get; set; }

        public int StopBits {  get; set; }

        public bool TraceLog {  get; set; }

        public int PollingInterval {  get; set; }

        public bool UsbType {  get; set; }

        public short ProductId {  get; set; }

        public String Version { get; }
        public String ErrorCode { get; }
        public String ErrorDesc { get; }
        public String StDevice { get; }
        public String StMedia { get; }
        public String StPaper { get; }
        public String StPaperEx { get; }
        public String StLever { get; }
        public String StPrinterHead { get; }
        public String CRCValue { get; }


        public MockReceiptPrinter()
        {
        }

        // Methods
        public void OpenDevice()
        {
            Task.Run(() =>
            {
                OnDeviceOpened?.Invoke(null, PortPath);
            });
        }

        public void CloseDevice()
        {
            Task.Run(() =>
            {
                OnDeviceClosed?.Invoke(null, new());
            });
        }

        public void Initialize(bool cutPaper)
        {
            Task.Run(() =>
            {
                Thread.Sleep(3000);
                OnInitialized?.Invoke(this, new());
            });
        }

        public void PrintText(string text, bool cutPaper)
        {
            Task.Run(() =>
            {
                Thread.Sleep(2000);
                OnPrinted?.Invoke(this, new());
            });
        }

        public void PrintImage(string filename, bool cutPaper, int paddingLeftColumns, int alignment)
        {
            Task.Run(() =>
            {
                Thread.Sleep(2000);
                OnPrinted?.Invoke(this, new());
            });
        }

        public void Cut()
        {
            Task.Run(() =>
            {
                Thread.Sleep(2000);
                OnCut?.Invoke(this, new());
            });
        }

        public void GetVerticalMargin()
        {
            Task.Run(() =>
            {
                Thread.Sleep(2000);
                OnGotVerticalMargin?.Invoke(this, new());
            });
        }

        public void SetVerticalMargin(ReceiptMargin margin)
        {
            Task.Run(() =>
            {
                Thread.Sleep(2000);
                OnSetVerticalMargin?.Invoke(this, new());
            });
        }
    }
}
