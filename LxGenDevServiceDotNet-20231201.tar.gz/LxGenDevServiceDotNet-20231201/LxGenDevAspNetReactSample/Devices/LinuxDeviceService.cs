﻿#if DEBUG
#define USE_USB_TO_SERIAL
#endif
//#define USE_MOCK_DEVICE_PRINTER
//#define USE_MOCK_DEVICE_PINPAD
//#define USE_MOCK_DEVICE_BARCODESCANNER
//#define USE_MOCK_DEVICE_CARDREADER
//#define USE_MOCK_DEVICE_CASHDISPENSER
//#define USE_MOCK_DEVICE_INDICATOR

using System.Net.NetworkInformation;
using System.Text;

using LxGenDevAspNetReactSample.Devices.MockDevices;
using LxGenDevBarcodeScanner;
using LxGenDevCardReader;
using LxGenDevCashDispenser;
using LxGenDevEncryptingPinPad;
using LxGenDevIndicator;
using LxGenDevReceiptPrinter;

namespace LxGenDevAspNetReactSample.Devices
{
    public class LinuxDeviceService
    {
#if USE_MOCK_DEVICE_PRINTER
        public MockReceiptPrinter ReceiptPrinter { get; }
#else
        public GenDevReceiptPrinter ReceiptPrinter { get; }
#endif

#if USE_MOCK_DEVICE_CARDREADER
        public MockCardReader CardReader { get; }
#else
        public GenDevCardReader CardReader { get; }
#endif

#if USE_MOCK_DEVICE_PINPAD
        public MockPinPad   PinPad { get; }
#else
        public GenDevEncryptingPinPad PinPad { get; }
#endif

#if USE_MOCK_DEVICE_BARCODESCANNER
        public MockBarcodeScanner BarcodeScanner { get; }
#else
        public GenDevBarcodeScanner BarcodeScanner { get; }
#endif

#if USE_MOCK_DEVICE_CASHDISPENSER
        public MockCashDispenser CashDispenser { get; }
#else
        public GenDevCashDispenser CashDispenser { get; }
#endif

#if USE_MOCK_DEVICE_INDICATOR
        public MockIndicator    Indicator { get; }
#else
        public GenDevIndicator Indicator { get; }
#endif

        private TaskCompletionSource<bool>? _tcsInitCdu;
        private TaskCompletionSource<bool>? _tcsInitRpu;
        private TaskCompletionSource<bool>? _tcsInitMcr;
        private TaskCompletionSource<bool>? _tcsInitSiu;
        private TaskCompletionSource<bool>? _tcsInitEpp;
        private TaskCompletionSource<bool>? _tcsInitBcs;

        public const int FLICKER_RECEIPTPRINTER = 1;
        public const int FLICKER_CARDREADER = 2;
        public const int FLICKER_CASHTRAY = 3;
        public const int FLICKER_CASHDISPENSER = 4;
        public const int FLICKER_PINPAD = 6;

#if USE_USB_TO_SERIAL
        private string PortBarcodeScanner = "/dev/ttyUSB6";
        private string PortCardReader = "/dev/ttyUSB0";
        private string PortReceiptPrinter = "/dev/ttyUSB4";
        private string PortIndicator = "/dev/ttyUSB5";
        private string PortPinPad = "/dev/ttyUSB1";
        private string PortCashDispenser = "/dev/ttyUSB3";
#else
        private string PortBarcodeScanner = "/dev/ttyS7";
        private string PortCardReader = "/dev/ttyS0";
        private string PortReceiptPrinter = "/dev/ttyS4";
        private string PortIndicator = "/dev/ttyS5";
        private string PortPinPad = "/dev/ttyS1";
        private string PortCashDispenser = "/dev/ttyS3";
#endif

        public LinuxDeviceService() 
        {
            ReceiptPrinter = new();
            CardReader = new();
            PinPad = new();
            BarcodeScanner = new();
            CashDispenser = new();
            Indicator = new();
        }

        public async Task OpenDevices(bool integratedAtmApp)
        {
            if (integratedAtmApp)
            {
                //
                // Don't need to open devices that ATM application already opened and initialized.
                // Therefore, the ATM app. doesn't use a barcode scanner, 
                // Kiosk application needs to open and initialize the barcode scanner.
                //
                _tcsInitBcs = new TaskCompletionSource<bool>();
                OpenBarcodeScanner();

                await Task.WhenAll( _tcsInitBcs.Task);
            }
            else
            {
                //
                // If the Kiosk application is running standalone,
                // All of devices should be opened and initialized.
                //
                _tcsInitSiu = new TaskCompletionSource<bool>();
                _tcsInitRpu = new TaskCompletionSource<bool>();
                _tcsInitEpp = new TaskCompletionSource<bool>();
                _tcsInitMcr = new TaskCompletionSource<bool>();
                _tcsInitCdu = new TaskCompletionSource<bool>();
                _tcsInitBcs = new TaskCompletionSource<bool>();

                OpenPrinter();
                OpenPinPad();
                OpenCardReader();
                OpenCashDispenser();
                OpenIndicator();
                OpenBarcodeScanner();

                await Task.WhenAll( _tcsInitCdu.Task, _tcsInitBcs.Task, _tcsInitEpp.Task, _tcsInitMcr.Task, _tcsInitRpu.Task, _tcsInitSiu.Task);

                // Checking result
                if (_tcsInitBcs.Task.Result == false)
                {
                    throw new Exception("Failed to initialize barcode scanner");
                }

                _tcsInitSiu = null;
                _tcsInitRpu = null;
                _tcsInitEpp = null;
                _tcsInitMcr = null;
                _tcsInitCdu = null;
                _tcsInitBcs = null;
            }
        }

        private void OpenIndicator()
        {
            Indicator.PortPath = PortIndicator;;
            Indicator.OnDeviceError += _indicator_OnDeviceError;
            Indicator.OnInitialized += _indicator_OnInitialized;
            Indicator.OnDeviceOpened += _indicator_OnDeviceOpened;
            Indicator.OpenDevice();
        }

        private void _indicator_OnDeviceOpened(object? sender, string e)
        {
            Indicator.Initialize();
        }

        private void _indicator_OnInitialized(object? sender, EventArgs e)
        {
            _tcsInitSiu?.TrySetResult(true);
        }

        private void _indicator_OnDeviceError(object? sender, short e)
        {
            _tcsInitSiu?.TrySetResult(true);
        }

        private void OpenCashDispenser()
        {
            CashDispenser.PortPath = PortCashDispenser;
            CashDispenser.OnInitialized +=  _cashDispenser_OnInitialized;
            CashDispenser.OnDeviceError += _cashDispenser_OnDeviceError;
            CashDispenser.OnDeviceOpened += _cashDispenser_OnDeviceOpened;
            
            // Pass your CDU license key.
            CashDispenser.OpenDevice("1CD81CB23D7E3AA");
        }

        private void _cashDispenser_OnDeviceOpened(object? sender, string e)
        {
            CashDispenser.Initialize(true);
        }

        private void _cashDispenser_OnInitialized(object? sender, EventArgs e)
        {
            _tcsInitCdu?.TrySetResult(true);
        }

        private void _cashDispenser_OnDeviceError(object? sender, short e)
        {
            _tcsInitCdu?.TrySetResult(false);
        }

        private void OpenPrinter()
        {
            ReceiptPrinter.PortPath = PortReceiptPrinter;
            ReceiptPrinter.BaudRate = 115200;
            ReceiptPrinter.OnDeviceError += _receiptPrinter_OnDeviceError;
            ReceiptPrinter.OnDeviceOpened += _receiptPrinter_OnDeviceOpened;
            ReceiptPrinter.OnInitialized += _receiptPrinter_OnInitialized;
            ReceiptPrinter.OpenDevice();
        }

        private void _receiptPrinter_OnDeviceOpened(object? sender, string e)
        {
            ReceiptPrinter.Initialize(false);
        }

        private void _receiptPrinter_OnInitialized(object? sender, EventArgs e)
        {
            _tcsInitRpu?.TrySetResult(true);
        }

        private void _receiptPrinter_OnDeviceError(object? sender, int e)
        {
            _tcsInitRpu?.TrySetResult(false);
        }

        private void OpenPinPad()
        {
            PinPad.PortPath = PortPinPad;
            PinPad.OnDeviceOpened += _pinPad_OnDeviceOpened;
            PinPad.OnInitialized += _pinPad_OnInitialized;
            PinPad.OnDeviceError += _pinPad_OnDeviceError;
            PinPad.OpenDevice();
        }

        private void _pinPad_OnDeviceOpened(object? sender, string e)
        {
            PinPad.Initialize();
        }

        private void _pinPad_OnInitialized(object? sender, EventArgs e)
        {
            _tcsInitEpp?.TrySetResult(true);
            
        }

        private void _pinPad_OnDeviceError(object? sender, short e)
        {
            _tcsInitEpp?.TrySetResult(false);
        }

        private void OpenCardReader()
        {
            CardReader.PortPath = PortCardReader;
            CardReader.OnDeviceOpened += _cardReader_OnDeviceOpened;
            CardReader.OnDeviceError += _cardReader_OnDeviceError;
            CardReader.OpenDevice();
        }

        private void _cardReader_OnDeviceOpened(object? sender, string e)
        {
            _tcsInitMcr?.TrySetResult(true);
        }


        private void _cardReader_OnDeviceError(object? sender, int e)
        {
            _tcsInitMcr?.TrySetResult(false);
        }

        private void OpenBarcodeScanner()
        {
            BarcodeScanner.PortPath = PortBarcodeScanner;
            BarcodeScanner.OnDeviceError += _barcodeScanner_OnDeviceError;
            BarcodeScanner.OnDeviceOpened += _barcodeScanner_OnDeviceOpened;
            BarcodeScanner.OpenDevice();
        }

        private void _barcodeScanner_OnDeviceOpened(object? sender, string e)
        {
            _tcsInitBcs?.TrySetResult(true);
        }

        private void _barcodeScanner_OnDeviceError(object? sender, int e)
        {
            _tcsInitBcs?.TrySetResult(false);
        }
    }
}
