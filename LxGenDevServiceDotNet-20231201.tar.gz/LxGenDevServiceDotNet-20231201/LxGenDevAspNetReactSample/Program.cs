using System.Diagnostics;
using LxGenDevAspNetReactSample.Devices;
using Microsoft.Net.Http.Headers;

namespace LxGenDevAspNetReactSample
{
    public class Program
    {


        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);


            // Add services to the container.

            builder.Services.AddControllersWithViews();

            builder.Services.AddSignalR();

            builder.Services.AddSingleton<LinuxDeviceService>();
            builder.Services.AddSingleton<SignalrHub>();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
            }

            app.UseStaticFiles();
            app.UseRouting();

            app.UseCors(builder =>
            {
                builder.WithOrigins("http://localhost:44414")
                    .AllowAnyHeader()
                    .AllowAnyMethod()
                    .AllowCredentials();
            });

            app.MapHub<SignalrHub>("/hub");

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller}/{action=Index}/{id?}");

            app.MapFallbackToFile("index.html");

#if !DEBUG
            Task.Run(() => {
                Thread.Sleep(3000);
                Process.Start("/snap/bin/chromium", "http://localhost:5118 --kiosk");
            });
#endif
            app.Run();
        }
    }
}