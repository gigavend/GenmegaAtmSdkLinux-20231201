﻿# Genmega .NET Core with React.js Example Application

This project is an example for Genmega .NET SDK.

# Installation
 - Install Genmega Device SDK.
 - Install Genmega ATM SDK.
 - Install Chromium from Ubuntu Software Repository.
 - Extract GenmegaDotNetKioskAppExample.gz.
 - Execute 'dotnet run' in LxGenDevAskNetReactSample folder.
