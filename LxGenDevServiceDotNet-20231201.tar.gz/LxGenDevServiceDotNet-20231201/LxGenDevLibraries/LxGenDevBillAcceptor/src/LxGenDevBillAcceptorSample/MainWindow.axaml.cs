using System;
using System.Linq;
using System.Threading.Tasks;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Platform.Storage;
using Avalonia.Threading;
using LxGenDevBillAcceptor;

namespace LxGenDevBillAcceptorSample;

public partial class MainWindow : Window
{
    GenDevBillAcceptor _billAcceptor = new GenDevBillAcceptor();
    public MainWindow()
    {
        InitializeComponent();
    }
}
