using System.Diagnostics;
using System.Net;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.VisualBasic.FileIO;

using static LxGenDevBillAcceptor.GenDevBillAcceptorLib;

namespace LxGenDevBillAcceptor;

public class GenDevBillAcceptor
{
    // Properties
    public string PortPath
    {
        get { return GenDevBillAcceptorLib.PortPath; }
        set { GenDevBillAcceptorLib.PortPath = value; }
    }

    public int BaudRate
    {
        get { return GenDevBillAcceptorLib.BaudRate; }
        set { GenDevBillAcceptorLib.BaudRate = value; }
    }

    public int ByteSize
    {
        get { return GenDevBillAcceptorLib.ByteSize; }
        set { GenDevBillAcceptorLib.ByteSize = value; }
    }

    public int Parity
    {
        get { return GenDevBillAcceptorLib.Parity; }
        set { GenDevBillAcceptorLib.Parity = value; }
    }

    public int StopBits
    {
        get { return GenDevBillAcceptorLib.StopBits; }
        set { GenDevBillAcceptorLib.StopBits = value; }
    }

    public bool TraceLog
    {
        get { return GenDevBillAcceptorLib.TraceLog; }
        set { GenDevBillAcceptorLib.TraceLog = value; }
    }

    public long PollingInterval
    {
         get { return GenDevBillAcceptorLib.PollingInterval; }
        set { GenDevBillAcceptorLib.PollingInterval = value; }
    }

    public long Orientation
    {
        get { return GenDevBillAcceptorLib.Orientation; }
        set { GenDevBillAcceptorLib.Orientation = value; }
    }

    public long AcceptTimeout
    {
        get { return GenDevBillAcceptorLib.AcceptTimeout; }
        set { GenDevBillAcceptorLib.AcceptTimeout = value; }
    }

    public long ReturnTimeout
    {
        get { return GenDevBillAcceptorLib.ReturnTimeout; }
        set { GenDevBillAcceptorLib.ReturnTimeout = value; }
    }

    public string stUnitCal
    {
        get { return GenDevBillAcceptorLib.StUnitCal; }
        set { GenDevBillAcceptorLib.StUnitCal = value; }
    }

    public string stDenomination
    {
        get { return GenDevBillAcceptorLib.StDenomination; }
        set { GenDevBillAcceptorLib.StDenomination = value; }
    }

    public bool EscrowEnable
    {
        get { return GenDevBillAcceptorLib.EscrowEnable; }
        set { GenDevBillAcceptorLib.EscrowEnable = value; }
    }

    public bool Extended
    {
        get { return GenDevBillAcceptorLib.Extended; }
        set { GenDevBillAcceptorLib.Extended = value; }
    }

    public bool EnableNoteIndex1
    {
        get { return GenDevBillAcceptorLib.EnableNoteIndex1; }
        set { GenDevBillAcceptorLib.EnableNoteIndex1 = value; }
    }

    public bool EnableNoteIndex2
    {
        get { return GenDevBillAcceptorLib.EnableNoteIndex2; }
        set { GenDevBillAcceptorLib.EnableNoteIndex2 = value; }
    }

    public bool EnableNoteIndex3
    {
        get { return GenDevBillAcceptorLib.EnableNoteIndex3; }
        set { GenDevBillAcceptorLib.EnableNoteIndex3 = value; }
    }

    public bool EnableNoteIndex4
    {
        get { return GenDevBillAcceptorLib.EnableNoteIndex4; }
        set { GenDevBillAcceptorLib.EnableNoteIndex4 = value; }
    }

    public bool EnableNoteIndex5
    {
        get { return GenDevBillAcceptorLib.EnableNoteIndex5; }
        set { GenDevBillAcceptorLib.EnableNoteIndex5 = value; }
    }

    public bool EnableNoteIndex6
    {
        get { return GenDevBillAcceptorLib.EnableNoteIndex6; }
        set { GenDevBillAcceptorLib.EnableNoteIndex6 = value; }
    }

    public bool EnableNoteIndex7
    {
        get { return GenDevBillAcceptorLib.EnableNoteIndex7; }
        set { GenDevBillAcceptorLib.EnableNoteIndex7 = value; }
    }

    public bool EnableNoteIndex8
    {
        get { return GenDevBillAcceptorLib.EnableNoteIndex8; }
        set { GenDevBillAcceptorLib.EnableNoteIndex8 = value; }
    }

    public bool EnableNoteIndex9
    {
        get { return GenDevBillAcceptorLib.EnableNoteIndex9; }
        set { GenDevBillAcceptorLib.EnableNoteIndex9 = value; }
    }

    public bool EnableNoteIndex10
    {
        get { return GenDevBillAcceptorLib.EnableNoteIndex10; }
        set { GenDevBillAcceptorLib.EnableNoteIndex10 = value; }
    }


    public String stDevice => GenDevBillAcceptorLib.StDevice;
    public String stStacker => GenDevBillAcceptorLib.StStacker;
    public String stLRC => GenDevBillAcceptorLib.StLRC;
    public String StTransporter => GenDevBillAcceptorLib.StTransporter;
    public String stEscrow => GenDevBillAcceptorLib.StEscrow;
    public String Version => GenDevBillAcceptorLib.Version;
    public String stSensorInfo => GenDevBillAcceptorLib.StSensorInfo;


    public GenDevBillAcceptor()
    {
        _bauEventDeviceOpenedDelegate = new BAUEventDeviceOpenedDelegate(EventDeviceOpened);
        _bauEventDeviceClosedDelegate = new BAUEventDeviceClosedDelegate(EventDeviceClosed);
        _bauEventInitializeCompletedDelegate = new BAUEventInitializeCompletedDelegate(EventInitializeCompleted);
        _bauEventBillAcceptedDelegate = new BAUEventBillAcceptedDelegate(EventBillAccepted);
        _bauEventBillStackedDelegate = new BAUEventBillStackedDelegate(EventBillStacked);
        _bauEventBillReturnedDelegate = new BAUEventBillReturnedDelegate(EventBillReturned);
        _bauEventBillRejectedDelegate = new BAUEventBillRejectedDelegate(EventBillRejected);
        _bauEventBillCheatedDelegate = new BAUEventBillCheatedDelegate(EventBillCheated);
        _bauEventAcceptCanceledDelegate = new BAUEventAcceptCanceledDelegate(EventAcceptCanceled);
        _bauEventAcceptTimeoutDelegate = new BAUEventAcceptTimeoutDelegate(EventAcceptCanceled);
        _bauEventBillReturnTimeoutDelegate = new BAUEventBillReturnTimeoutDelegate(EventBillReturnTimeout);
        _bauEventEnteringCalibrationDelegate = new BAUEventEnteringCalibrationDelegate(EventEnteringCalibration);
        _bauEventCalibrationCompletedDelegate = new BAUEventCalibrationCompletedDelegate(EventCalibrationCompleted);
        _bauEventDevicePowerUpDelegate = new BAUEventDevicePowerUpDelegate(EventDevicePowerUp);
        _bauEventStatusChangedDelegate = new BAUEventStatusChangedDelegate(EventStatusChanged);
        _bauEventDeviceErrorDelegate = new BAUEventDeviceErrorDelegate(EventDeviceError);
        _bauUEventBillAcceptedExDelegate = new BAUEventBillAcceptedExDelegate(EventBillAcceptedEx);
        _bauEventBillStackedExDelegate = new BAUEventBillStackedExDelegate(EventBillStackedEx);
        _bauEventSoftResetCompletedDelegate = new BAUEventSoftResetCompletedDelegate(EventSoftResetCompleted);
        _bauEventSetEnableDenoCompletedDelegate = new BAUEventSetEnableDenoCompletedDelegate(EventSetEnableDenoCompleted);


        BAURegCallbackDeviceOpened(_bauEventDeviceOpenedDelegate);
        BAURegCallbackDeviceClosed(_bauEventDeviceClosedDelegate);
        BAURegCallbackInitializeCompleted(_bauEventInitializeCompletedDelegate);
        BAURegCallbackBillAccepted(_bauEventBillAcceptedDelegate);
        BAURegCallbackBillStacked(_bauEventBillStackedDelegate);
        BAURegCallbackBillReturned(_bauEventBillReturnedDelegate);
        BAURegCallbackBillRejected(_bauEventBillRejectedDelegate);
        BAURegCallbackBillCheated(_bauEventBillCheatedDelegate);
        BAURegCallbackAcceptCanceled(_bauEventAcceptCanceledDelegate);
        BAURegCallbackAcceptTimeout(_bauEventAcceptTimeoutDelegate);
        BAURegCallbackBillReturnTimeout(_bauEventBillReturnTimeoutDelegate);
        BAURegCallbackEnteringCalibration(_bauEventEnteringCalibrationDelegate);
        BAURegCallbackCalibrationCompleted(_bauEventCalibrationCompletedDelegate);
        BAURegCallbackDevicePowerUp(_bauEventDevicePowerUpDelegate);
        BAURegCallbackStatusChanged(_bauEventStatusChangedDelegate);
        BAURegCallbackDeviceError(_bauEventDeviceErrorDelegate);
        BAURegCallbackBillAcceptedEx(_bauUEventBillAcceptedExDelegate);
        BAURegCallbackBillStackedEx(_bauEventBillStackedExDelegate);
        BAURegCallbackSoftResetCompleted(_bauEventSoftResetCompletedDelegate);
        BAURegCallbackSetEnableDenoCompleted(_bauEventSetEnableDenoCompletedDelegate);
    }


    // Methods
    public void OpenDevice()
    {
        short retval = BAUOpenDevice();
        if (retval != 0)
        {
            throw new BillAcceptorException(retval);
        }
    }

    public void CloseDevice()
    {
        int retval = BAUCloseDevice();
        if (retval != 0)
        {
            throw new BillAcceptorException(retval);
        }
    }

    public void Initialize()
    {
        int retval = BAUInitializeDevice();
        if (retval != 0)
        {
            throw new BillAcceptorException(retval);
        }
    }

    public void AcceptBill()
    {
        int retval = BAUAcceptBill();
        if (retval != 0)
        {
            throw new BillAcceptorException(retval);
        }
    }

    public void StackBill()
    {
        int retval = BAUStackBill();
        if (retval != 0)
        {
            throw new BillAcceptorException(retval);
        }
    }

    public void ReturnBill()
    {
        int retval = BAUReturnBill();
        if (retval != 0)
        {
            throw new BillAcceptorException(retval);
        }
    }

    public void AcceptBookmark()
    {
        int retval = BAUAcceptBookmark();
        if (retval != 0)
        {
            throw new BillAcceptorException(retval);
        }
    }

    public void SetCalibration()
    {
        int retval = BAUSetCalibration();
        if (retval != 0)
        {
            throw new BillAcceptorException(retval);
        }
    }

    public void CancelAccept()
    {
        int retval = BAUCancelAccept();
        if (retval != 0)
        {
            throw new BillAcceptorException(retval);
        }
    }

    public void ChangeCurrency(string Currency)
    {
        int retval = BAUChangeCurrency(Currency);
        if (retval != 0)
        {
            throw new BillAcceptorException(retval);
        }
    }

    public void SoftReset()
    {
        int retval = BAUSoftReset();
        if (retval != 0)
        {
            throw new BillAcceptorException(retval);
        }
    }

    public void SetEnableDeno(string EnableDeno)
    {
        int retval = BAUSetEnableDeno(EnableDeno);
        if (retval != 0)
        {
            throw new BillAcceptorException(retval);
        }
    }

    public string QueryAcceptor(string Request)
    {
        int MaxLength = 1024;
        StringBuilder Response = new StringBuilder(MaxLength);

        int retval = BAUQueryAcceptor(Request, Response, MaxLength);
        if (retval < 0)
        {
            throw new BillAcceptorException(retval);
        }

        return Response.ToString();
    }


    // Events
    public event EventHandler<String>? OnDeviceOpened;
    public event EventHandler? OnDeviceClosed;
    public event EventHandler? OnInitialized;
    public event EventHandler<short>? OnBillAccepted;
    public event EventHandler<short>? OnBillStacked;
    public event EventHandler? OnBillReturned;
    public event EventHandler? OnBillRejected;
    public event EventHandler? OnBillCheated;
    public event EventHandler? OnAcceptCanceled;
    public event EventHandler? OnAcceptTimeout;
    public event EventHandler? OnBillReturnTimeout;
    public event EventHandler? OnEnteringCalibration;
    public event EventHandler? OnCalibrationCompleted;
    public event EventHandler? OnDevicePowerUp;
    public event EventHandler<StatusChanged>? OnDStatusChanged;
    public event EventHandler<short>? OnDeviceError;
    public event EventHandler<String>? OnBillAcceptedEx;
    public event EventHandler<String>? OnBillStackedEx;
    public event EventHandler? OnSoftResetCompleted;
    public event EventHandler? OnSetEnableDenoCompleted;

     // Processing callback
    private void EventDeviceOpened(IntPtr pObj, String portPath)
    {
        OnDeviceOpened?.Invoke(null, portPath);
    }

    private void EventDeviceClosed(IntPtr pObj)
    {
        OnDeviceClosed?.Invoke(null, new ());
    }

    private void EventInitializeCompleted(IntPtr pObj)
    {
        OnInitialized?.Invoke(null, new ());
    }

    private void EventBillAccepted(IntPtr pObj, short bill)
    {
        OnBillAccepted?.Invoke(null, bill);
    }

    private void EventBillStacked(IntPtr pObj,  short bill)
    {
        OnBillStacked?.Invoke(null, bill);
    }

    private void EventBillReturned(IntPtr pObj)
    {
        OnBillReturned?.Invoke(null, new ());
    }

    private void EventBillRejected(IntPtr pObj)
    {
        OnBillRejected?.Invoke(null, new ());
    }

    private void EventBillCheated(IntPtr pObj)
    {
        OnBillCheated?.Invoke(null, new ());
    }

    private void EventAcceptCanceled(IntPtr pObj)
    {
        OnAcceptCanceled?.Invoke(null, new ());
    }

    private void EventAcceptTimeout(IntPtr pObj)
    {
        OnAcceptTimeout?.Invoke(null, new ());
    }

    private void EventBillReturnTimeout(IntPtr pObj)
    {
        OnBillReturnTimeout?.Invoke(null, new ());
    }

    private void EventEnteringCalibration(IntPtr pObj)
    {
        OnEnteringCalibration?.Invoke(null, new ());
    }

    private void EventCalibrationCompleted(IntPtr pObj)
    {
        OnCalibrationCompleted?.Invoke(null, new ());
    }

    private void EventDevicePowerUp(IntPtr pObj)
    {
        OnDevicePowerUp?.Invoke(null, new ());
    }

    private void EventStatusChanged(IntPtr pObj, string changedStatus, string prevStatus, string currentStatus)
    {
        OnDStatusChanged?.Invoke(null, new StatusChanged(changedStatus, prevStatus, currentStatus));
    }

    private void EventDeviceError(IntPtr pObj, short reason)
    {
        OnDeviceError?.Invoke(null, reason);
    }

    private void EventBillAcceptedEx(IntPtr pObj, String billInfo)
    {
        OnBillAcceptedEx?.Invoke(null, billInfo);
    }

    private void EventBillStackedEx(IntPtr pObj, String billInfo)
    {
        OnBillStackedEx?.Invoke(null, billInfo);
    }

    private void EventSoftResetCompleted(IntPtr pObj)
    {
        OnSoftResetCompleted?.Invoke(null, new ());
    }

    private void EventSetEnableDenoCompleted(IntPtr pObj)
    {
        OnSetEnableDenoCompleted?.Invoke(null, new ());
    }


    //  Delegate can be deleted by Gabage collector if it pass as marshalling callback function.
    //  It need to keep reference to get callback function works.
    private readonly BAUEventDeviceOpenedDelegate _bauEventDeviceOpenedDelegate;
    private readonly BAUEventDeviceClosedDelegate _bauEventDeviceClosedDelegate;
    private readonly BAUEventInitializeCompletedDelegate _bauEventInitializeCompletedDelegate;
    private readonly BAUEventBillAcceptedDelegate _bauEventBillAcceptedDelegate;
    private readonly BAUEventBillStackedDelegate _bauEventBillStackedDelegate;
    private readonly BAUEventBillReturnedDelegate _bauEventBillReturnedDelegate;
    private readonly BAUEventBillRejectedDelegate _bauEventBillRejectedDelegate;
    private readonly BAUEventBillCheatedDelegate _bauEventBillCheatedDelegate;
    private readonly BAUEventAcceptCanceledDelegate _bauEventAcceptCanceledDelegate;
    private readonly BAUEventAcceptTimeoutDelegate _bauEventAcceptTimeoutDelegate;
    private readonly BAUEventBillReturnTimeoutDelegate _bauEventBillReturnTimeoutDelegate;
    private readonly BAUEventEnteringCalibrationDelegate _bauEventEnteringCalibrationDelegate;
    private readonly BAUEventCalibrationCompletedDelegate _bauEventCalibrationCompletedDelegate;
    private readonly BAUEventDevicePowerUpDelegate _bauEventDevicePowerUpDelegate;
    private readonly BAUEventStatusChangedDelegate _bauEventStatusChangedDelegate;
    private readonly BAUEventDeviceErrorDelegate _bauEventDeviceErrorDelegate;
    private readonly BAUEventBillAcceptedExDelegate _bauUEventBillAcceptedExDelegate;
    private readonly BAUEventBillStackedExDelegate _bauEventBillStackedExDelegate;
    private readonly BAUEventSoftResetCompletedDelegate _bauEventSoftResetCompletedDelegate;
    private readonly BAUEventSetEnableDenoCompletedDelegate _bauEventSetEnableDenoCompletedDelegate;

}