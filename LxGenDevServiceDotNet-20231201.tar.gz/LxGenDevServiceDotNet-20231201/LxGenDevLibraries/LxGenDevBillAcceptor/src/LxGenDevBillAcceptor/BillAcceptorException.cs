namespace LxGenDevBillAcceptor;

public class BillAcceptorException : Exception
{
    public int ErrorCode { get; internal set; }

    internal BillAcceptorException(int errorCode) : base($"Error Code : {errorCode}")
    {
        ErrorCode = errorCode;
    }
}