public class StatusChanged
{
    public string? ChangedStatus {get;set;}
    public string? PrevStatus {get;set;}
    public string? CurrentStatus {get;set;}
    
    public StatusChanged(string changedStatus, string prevStatus , string currentStatus)
    {
        ChangedStatus = changedStatus;
        PrevStatus = prevStatus;
        CurrentStatus = currentStatus;
    }
}