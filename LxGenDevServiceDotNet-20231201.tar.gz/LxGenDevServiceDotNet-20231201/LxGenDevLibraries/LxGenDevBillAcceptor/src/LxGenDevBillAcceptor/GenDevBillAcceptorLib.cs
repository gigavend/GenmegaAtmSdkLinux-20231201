﻿
using System.Runtime.InteropServices;
using System.Text;

namespace LxGenDevBillAcceptor;

internal static class GenDevBillAcceptorLib
{
    private const string LibraryName = "libLxGenDevBillAcceptor.so";

    private delegate int GetStringPropertyDelegate(StringBuilder buffer, int bufferLenth);

    private static String GetStringProperty(GetStringPropertyDelegate getProperty)
    {
        int bufferSize = 1024; // Adjust the buffer size as needed
        StringBuilder buffer = new StringBuilder(bufferSize);
        getProperty(buffer, bufferSize);
        return buffer.ToString();
    }

    /*
    //Events
    typedef void (*BAUEventDeviceOpened)(void* pObj, const char* OpenedPortPath);
    typedef void (*BAUEventDeviceClosed)(void* pObj);
    typedef void (*BAUEventInitializeCompleted)(void* pObj);
    typedef void (*BAUEventBillAccepted)(void* pObj, short Bill);
    typedef void (*BAUEventBillStacked)(void* pObj, short Bill);
    typedef void (*BAUEventBillReturned)(void* pObj);
    typedef void (*BAUEventBillRejected)(void* pObj);
    typedef void (*BAUEventBillCheated)(void* pObj);
    typedef void (*BAUEventAcceptCanceled)(void* pObj);
    typedef void (*BAUEventAcceptTimeout)(void* pObj);
    typedef void (*BAUEventBillReturnTimeout)(void* pObj);
    typedef void (*BAUEventEnteringCalibration)(void* pObj);
    typedef void (*BAUEventCalibrationCompleted)(void* pObj);
    typedef void (*BAUEventDevicePowerUp)(void* pObj);
    typedef void (*BAUEventStatusChanged)(void* pObj, const char* ChangedStatus, const char* PrevStatus, const char* CurrentStatus);
    typedef void (*BAUEventDeviceError)(void* pObj, short Reason);
    typedef void (*BAUEventBillAcceptedEx)(void* pObj, const char* BillInfo);
    typedef void (*BAUEventBillStackedEx)(void* pObj, const char* BillInfo);
    typedef void (*BAUEventSoftResetCompleted)(void* pobj);
    typedef void (*BAUEventSetEnableDenoCompleted)(void* pobj);

    void BAURegisterCallbackObject(void* pObject);
    void BAURegCallbackDeviceOpened(BAUEventDeviceOpened eventfunc);
    void BAURegCallbackDeviceClosed(BAUEventDeviceClosed eventfunc);
    void BAURegCallbackInitializeCompleted(BAUEventInitializeCompleted eventfunc);
    void BAURegCallbackBillAccepted(BAUEventBillAccepted eventfunc);
    void BAURegCallbackBillStacked(BAUEventBillStacked eventfunc);
    void BAURegCallbackBillReturned(BAUEventBillReturned eventfunc);
    void BAURegCallbackBillRejected(BAUEventBillRejected eventfunc);
    void BAURegCallbackBillCheated(BAUEventBillCheated eventfunc);
    void BAURegCallbackAcceptCanceled(BAUEventAcceptCanceled eventfunc);
    void BAURegCallbackAcceptTimeout(BAUEventAcceptTimeout eventfunc);
    void BAURegCallbackBillReturnTimeout(BAUEventBillReturnTimeout eventfunc);
    void BAURegCallbackEnteringCalibration(BAUEventEnteringCalibration eventfunc);
    void BAURegCallbackCalibrationCompleted(BAUEventCalibrationCompleted eventfunc);
    void BAURegCallbackDevicePowerUp(BAUEventDevicePowerUp eventfunc);
    void BAURegCallbackStatusChanged(BAUEventStatusChanged eventfunc);
    void BAURegCallbackDeviceError(BAUEventDeviceError eventfunc);
    void BAURegCallbackBillAcceptedEx(BAUEventBillAcceptedEx eventfunc);
    void BAURegCallbackBillStackedEx(BAUEventBillStackedEx eventfunc);
    void BAURegCallbackSoftResetCompleted(BAUEventSoftResetCompleted eventfunc);
    void BAURegCallbackSetEnableDenoCompleted(BAUEventSetEnableDenoCompleted eventfunc);
    */

    //Callback Delegates
    internal delegate void BAUEventDeviceOpenedDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String portPath);
    internal delegate void BAUEventDeviceClosedDelegate(IntPtr pObj);
    internal delegate void BAUEventInitializeCompletedDelegate(IntPtr pObj);
    internal delegate void BAUEventBillAcceptedDelegate(IntPtr pObj, short bill);
    internal delegate void BAUEventBillStackedDelegate(IntPtr pObj, short bill);
    internal delegate void BAUEventBillReturnedDelegate(IntPtr pObj);
    internal delegate void BAUEventBillRejectedDelegate(IntPtr pObj);
    internal delegate void BAUEventBillCheatedDelegate(IntPtr pObj);
    internal delegate void BAUEventAcceptCanceledDelegate(IntPtr pObj);
    internal delegate void BAUEventAcceptTimeoutDelegate(IntPtr pObj);
    internal delegate void BAUEventBillReturnTimeoutDelegate(IntPtr pObj);
    internal delegate void BAUEventEnteringCalibrationDelegate(IntPtr pObj);
    internal delegate void BAUEventCalibrationCompletedDelegate(IntPtr pObj);
    internal delegate void BAUEventDevicePowerUpDelegate(IntPtr pObj);
    internal delegate void BAUEventStatusChangedDelegate(IntPtr pObj,[MarshalAs(UnmanagedType.LPStr)] String ChangedStatus, [MarshalAs(UnmanagedType.LPStr)] String PrevStatus, [MarshalAs(UnmanagedType.LPStr)] String CurrentStatus );
    internal delegate void BAUEventDeviceErrorDelegate(IntPtr pObj, short reason);
    internal delegate void BAUEventBillAcceptedExDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String billInfo);
    internal delegate void BAUEventBillStackedExDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String billInfo);
    internal delegate void BAUEventSoftResetCompletedDelegate(IntPtr pObj);
    internal delegate void BAUEventSetEnableDenoCompletedDelegate(IntPtr pObj);

     //Raw Event
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAURegCallbackDeviceOpened([MarshalAs(UnmanagedType.FunctionPtr)] BAUEventDeviceOpenedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAURegCallbackDeviceClosed([MarshalAs(UnmanagedType.FunctionPtr)] BAUEventDeviceClosedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAURegCallbackInitializeCompleted([MarshalAs(UnmanagedType.FunctionPtr)] BAUEventInitializeCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAURegCallbackBillAccepted([MarshalAs(UnmanagedType.FunctionPtr)] BAUEventBillAcceptedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAURegCallbackBillStacked([MarshalAs(UnmanagedType.FunctionPtr)] BAUEventBillStackedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAURegCallbackBillReturned([MarshalAs(UnmanagedType.FunctionPtr)] BAUEventBillReturnedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAURegCallbackBillRejected([MarshalAs(UnmanagedType.FunctionPtr)] BAUEventBillRejectedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAURegCallbackBillCheated([MarshalAs(UnmanagedType.FunctionPtr)] BAUEventBillCheatedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAURegCallbackAcceptCanceled([MarshalAs(UnmanagedType.FunctionPtr)] BAUEventAcceptCanceledDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAURegCallbackAcceptTimeout([MarshalAs(UnmanagedType.FunctionPtr)] BAUEventAcceptTimeoutDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAURegCallbackBillReturnTimeout([MarshalAs(UnmanagedType.FunctionPtr)] BAUEventBillReturnTimeoutDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAURegCallbackEnteringCalibration([MarshalAs(UnmanagedType.FunctionPtr)] BAUEventEnteringCalibrationDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAURegCallbackCalibrationCompleted([MarshalAs(UnmanagedType.FunctionPtr)] BAUEventCalibrationCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAURegCallbackDevicePowerUp([MarshalAs(UnmanagedType.FunctionPtr)] BAUEventDevicePowerUpDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAURegCallbackStatusChanged([MarshalAs(UnmanagedType.FunctionPtr)] BAUEventStatusChangedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAURegCallbackDeviceError([MarshalAs(UnmanagedType.FunctionPtr)] BAUEventDeviceErrorDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAURegCallbackBillAcceptedEx([MarshalAs(UnmanagedType.FunctionPtr)] BAUEventBillAcceptedExDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAURegCallbackBillStackedEx([MarshalAs(UnmanagedType.FunctionPtr)] BAUEventBillStackedExDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAURegCallbackSoftResetCompleted([MarshalAs(UnmanagedType.FunctionPtr)] BAUEventSoftResetCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAURegCallbackSetEnableDenoCompleted([MarshalAs(UnmanagedType.FunctionPtr)] BAUEventSetEnableDenoCompletedDelegate func);


    /*
    //Properties
    int BAUGetPortPath(OUT char* pPortPath, IN int nMaxLength);
    void BAUSetPortPath(IN const char* lpszNewValue);
    int BAUGetBaudRate();
    void BAUSetBaudRate(IN int nNewValue);
    short BAUGetByteSize();
    void BAUSetByteSize(IN short nNewValue);
    short BAUGetParity();
    void BAUSetParity(IN short nNewValue);
    short BAUGetStopBits();
    void BAUSetStopBits(IN short nNewValue);
    long BAUGetPollingInterval();
    void BAUSetPollingInterval(IN long nNewValue);
    bool BAUGetTraceLog();
    void BAUSetTraceLog(IN bool bNewValue);

    long BAUGetOrientation();
    void BAUSetOrientation(IN long nNewValue);
    long BAUGetAcceptTimeout();
    void BAUSetAcceptTimeout(IN long nNewValue);
    long BAUGetReturnTimeout();
    void BAUSetReturnTimeout(IN long nNewValue);
    int BAUGetStUnitCal(OUT char* pStUnitCal, IN int nMaxLength);
    void BAUSetStUnitCal(IN const char* lpszNewValue);
    int BAUGetStDenomination(OUT char* pStDenomination, IN int nMaxLength);
    void BAUSetStDenomination(IN const char* lpszNewValue);
    bool BAUGetEscrowEnable();
    void BAUSetEscrowEnable(IN bool bNewValue);
    bool BAUGetExtended();
    void BAUSetExtended(IN bool bNewValue);
    bool BAUGetEnableNoteIndex1();
    void BAUSetEnableNoteIndex1(IN bool bNewValue);
    bool BAUGetEnableNoteIndex2();
    void BAUSetEnableNoteIndex2(IN bool bNewValue);
    bool BAUGetEnableNoteIndex3();
    void BAUSetEnableNoteIndex3(IN bool bNewValue);
    bool BAUGetEnableNoteIndex4();
    void BAUSetEnableNoteIndex4(IN bool bNewValue);
    bool BAUGetEnableNoteIndex5();
    void BAUSetEnableNoteIndex5(IN bool bNewValue);
    bool BAUGetEnableNoteIndex6();
    void BAUSetEnableNoteIndex6(IN bool bNewValue);
    bool BAUGetEnableNoteIndex7();
    void BAUSetEnableNoteIndex7(IN bool bNewValue);
    bool BAUGetEnableNoteIndex8();
    void BAUSetEnableNoteIndex8(IN bool bNewValue);
    bool BAUGetEnableNoteIndex9();
    void BAUSetEnableNoteIndex9(IN bool bNewValue);
    bool BAUGetEnableNoteIndex10();
    void BAUSetEnableNoteIndex10(IN bool bNewValue);
    int BAUGetStDevice(OUT char* pStDevice, IN int nMaxLength);
    int BAUGetStStacker(OUT char* pStStacker, IN int nMaxLength);
    int BAUGetStLRC(OUT char* pStLRC, IN int nMaxLength);
    int BAUGetStTransporter(OUT char* pStTransporter, IN int nMaxLength);
    int BAUGetStEscrow(OUT char* pStEscrow, IN int nMaxLength);
    int BAUGetVersion(OUT char* pVersion, IN int nMaxLength);
    int BAUGetStSensorInfo(OUT char* pStSensorInfo, IN int nMaxLength);
    */

     internal static string PortPath
    {
        get { return GetStringProperty(BAUGetPortPath); }
        set { BAUSetPortPath(value); }
    }

    internal static int BaudRate
    {
        get { return BAUGetBaudRate(); }
        set { BAUSetBaudRate(value); }
    }

    internal static int ByteSize
    {
        get { return BAUGetByteSize(); }
        set { BAUSetByteSize((short)value); }
    }

    internal static int Parity
    {
        get { return BAUGetParity(); }
        set { BAUSetParity((short)value); }
    }

    internal static int StopBits
    {
        get { return BAUGetStopBits(); }
        set { BAUSetStopBits((short)value); }
    }

    internal static long PollingInterval
    {
        get { return BAUGetPollingInterval(); }
        set { BAUSetPollingInterval((short)value); }
    }

    internal static bool TraceLog
    {
        get { return BAUGetTraceLog(); }
        set { BAUSetTraceLog(value); }
    }

    internal static long Orientation
    {
        get { return BAUGetOrientation(); }
        set { BAUSetOrientation((short)value); }
    }

    internal static long AcceptTimeout
    {
        get { return BAUGetAcceptTimeout(); }
        set { BAUSetAcceptTimeout((short)value); }
    }

    internal static long ReturnTimeout
    {
        get { return BAUGetReturnTimeout(); }
        set { BAUSetReturnTimeout((short)value); }
    }

    internal static string StUnitCal
    {
        get { return GetStringProperty(BAUGetStUnitCal); }
        set { BAUSetStUnitCal(value); }
    }

   internal static string StDenomination
    {
        get { return GetStringProperty(BAUGetStDenomination); }
        set { BAUSetStDenomination(value); }
    }


    internal static bool EscrowEnable
    {
        get { return BAUGetEscrowEnable(); }
        set { BAUSetEscrowEnable(value); }
    }

    internal static bool Extended
    {
        get { return BAUGetExtended(); }
        set { BAUSetExtended(value); }
    }

    internal static bool EnableNoteIndex1
    {
        get { return BAUGetEnableNoteIndex1(); }
        set { BAUSetEnableNoteIndex1(value); }
    }

    internal static bool EnableNoteIndex2
    {
        get { return BAUGetEnableNoteIndex2(); }
        set { BAUSetEnableNoteIndex2(value); }
    }

    internal static bool EnableNoteIndex3
    {
        get { return BAUGetEnableNoteIndex3(); }
        set { BAUSetEnableNoteIndex3(value); }
    }

    internal static bool EnableNoteIndex4
    {
        get { return BAUGetEnableNoteIndex4(); }
        set { BAUSetEnableNoteIndex4(value); }
    }

    internal static bool EnableNoteIndex5
    {
        get { return BAUGetEnableNoteIndex5(); }
        set { BAUSetEnableNoteIndex5(value); }
    }

    internal static bool EnableNoteIndex6
    {
        get { return BAUGetEnableNoteIndex6(); }
        set { BAUSetEnableNoteIndex6(value); }
    }

    internal static bool EnableNoteIndex7
    {
        get { return BAUGetEnableNoteIndex7(); }
        set { BAUSetEnableNoteIndex7(value); }
    }

    internal static bool EnableNoteIndex8
    {
        get { return BAUGetEnableNoteIndex8(); }
        set { BAUSetEnableNoteIndex8(value); }
    }

    internal static bool EnableNoteIndex9
    {
        get { return BAUGetEnableNoteIndex9(); }
        set { BAUSetEnableNoteIndex9(value); }
    }

    internal static bool EnableNoteIndex10
    {
        get { return BAUGetEnableNoteIndex10(); }
        set { BAUSetEnableNoteIndex10(value); }
    }

    internal static String StDevice
    {
        get { return GetStringProperty(BAUGetStDevice); }
    }

    internal static String StStacker
    {
        get { return GetStringProperty(BAUGetStStacker); }
    }

    internal static String StLRC
    {
        get { return GetStringProperty(BAUGetStLRC); }
    }

    internal static String StTransporter
    {
        get { return GetStringProperty(BAUGetStTransporter); }
    }

    internal static String StEscrow
    {
        get { return GetStringProperty(BAUGetStEscrow); }
    }

    internal static String Version
    {
        get { return GetStringProperty(BAUGetVersion); }
    }

    internal static String StSensorInfo
    {
        get { return GetStringProperty(BAUGetStSensorInfo); }
    }


     // Raw Properties
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int BAUGetPortPath(StringBuilder pPortPath, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAUSetPortPath([MarshalAs(UnmanagedType.LPStr)] string str);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int BAUGetBaudRate();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAUSetBaudRate(int baudrate);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short BAUGetByteSize();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAUSetByteSize(short byteSize);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short BAUGetParity();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAUSetParity(short parity);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short BAUGetStopBits();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAUSetStopBits(short stopBits);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern long BAUGetPollingInterval();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAUSetPollingInterval(long nNewValue);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern bool BAUGetTraceLog();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAUSetTraceLog([MarshalAs(UnmanagedType.I1)] bool traceLog);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern long BAUGetOrientation();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAUSetOrientation(long nNewValue);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern long BAUGetAcceptTimeout();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAUSetAcceptTimeout(long nNewValue);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern long BAUGetReturnTimeout();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAUSetReturnTimeout(long nNewValue);
  
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int BAUGetStUnitCal(StringBuilder pStUnitCal, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAUSetStUnitCal([MarshalAs(UnmanagedType.LPStr)] string lpszNewValue);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int BAUGetStDenomination(StringBuilder pStDenomination, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAUSetStDenomination([MarshalAs(UnmanagedType.LPStr)] string lpszNewValue);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern bool BAUGetEscrowEnable();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAUSetEscrowEnable([MarshalAs(UnmanagedType.I1)] bool bNewValue);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern bool BAUGetExtended();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAUSetExtended([MarshalAs(UnmanagedType.I1)] bool bNewValue);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern bool BAUGetEnableNoteIndex1();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAUSetEnableNoteIndex1([MarshalAs(UnmanagedType.I1)] bool bNewValue);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern bool BAUGetEnableNoteIndex2();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAUSetEnableNoteIndex2([MarshalAs(UnmanagedType.I1)] bool bNewValue);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern bool BAUGetEnableNoteIndex3();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAUSetEnableNoteIndex3([MarshalAs(UnmanagedType.I1)] bool bNewValue);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern bool BAUGetEnableNoteIndex4();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAUSetEnableNoteIndex4([MarshalAs(UnmanagedType.I1)] bool bNewValue);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern bool BAUGetEnableNoteIndex5();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAUSetEnableNoteIndex5([MarshalAs(UnmanagedType.I1)] bool bNewValue);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern bool BAUGetEnableNoteIndex6();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAUSetEnableNoteIndex6([MarshalAs(UnmanagedType.I1)] bool bNewValue);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern bool BAUGetEnableNoteIndex7();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAUSetEnableNoteIndex7([MarshalAs(UnmanagedType.I1)] bool bNewValue);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern bool BAUGetEnableNoteIndex8();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAUSetEnableNoteIndex8([MarshalAs(UnmanagedType.I1)] bool bNewValue);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern bool BAUGetEnableNoteIndex9();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAUSetEnableNoteIndex9([MarshalAs(UnmanagedType.I1)] bool bNewValue);

     [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern bool BAUGetEnableNoteIndex10();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BAUSetEnableNoteIndex10([MarshalAs(UnmanagedType.I1)] bool bNewValue);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int BAUGetStDevice(StringBuilder stDevice, int length);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int BAUGetStStacker(StringBuilder sttStacker, int length);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int BAUGetStLRC(StringBuilder stLRC, int length);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int BAUGetStTransporter(StringBuilder stTransporter, int length);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int BAUGetStEscrow(StringBuilder stEscrow, int length);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int BAUGetVersion(StringBuilder version, int length);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int BAUGetStSensorInfo(StringBuilder stSensorInfo, int length);


    /*
    //Methods
    short BAUOpenDevice();
    short BAUCloseDevice();
    short BAUInitializeDevice();
    short BAUAcceptBill();
    short BAUStackBill();
    short BAUReturnBill();
    short BAUAcceptBookmark();
    short BAUSetCalibration();
    short BAUCancelAccept();
    short BAUChangeCurrency(IN const char* sCurrency);
    short BAUSoftReset();
    short BAUSetEnableDeno(IN const char* sEnableDeno);
    int BAUQueryAcceptor(IN const char* sRequest, OUT char* pResponse, IN int nMaxLength);
    */

      // Raw Methods
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short BAUOpenDevice();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short BAUCloseDevice();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short BAUInitializeDevice();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short BAUAcceptBill();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short BAUStackBill();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short BAUReturnBill();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short BAUAcceptBookmark();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short BAUSetCalibration();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short BAUCancelAccept();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short BAUChangeCurrency([MarshalAs(UnmanagedType.LPStr)] string  sCurrency);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short BAUSoftReset();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short BAUSetEnableDeno([MarshalAs(UnmanagedType.LPStr)] string  sEnableDeno);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int BAUQueryAcceptor([MarshalAs(UnmanagedType.LPStr)] string  sRequest, StringBuilder pResponse, int nMaxLength);

}
