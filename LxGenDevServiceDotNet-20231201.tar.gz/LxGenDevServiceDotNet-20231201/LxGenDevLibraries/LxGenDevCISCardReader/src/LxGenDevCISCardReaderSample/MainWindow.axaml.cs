using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;
using Avalonia.Media.Imaging;
using Avalonia.Interactivity;
using Avalonia.Platform.Storage;
using Avalonia.Threading;
using LxGenDevCISCardReader;

namespace LxGenDevCISCardReaderSample;

public partial class MainWindow : Window
{
    GenDevCISCardReader _cardReader = new GenDevCISCardReader();

    public MainWindow()
    {
        InitializeComponent();

        ComboBoxPorts.ItemsSource = new String[] {"/dev/ttyS0","/dev/ttyS1","/dev/ttyS2","/dev/ttyS3","/dev/ttyS4","/dev/ttyS5", "/dev/ttyUSB0", "/dev/ttyUSB1" };
        ComboBoxPorts.SelectedIndex = 4; 

        ComboBoxAcceptCard.ItemsSource = new String[]{"0 (MS Only)", "1 (EMV Only)" , "2 (EMV First)" , "3 (MS First)" };
        ComboBoxAcceptCard.SelectedIndex = 0;

        ComboBoxAcceptDL.ItemsSource = new String[]{"0 (MS Only)", "1 (EMV Only)" , "2 (EMV First)" , "3 (MS First)" };
        ComboBoxAcceptDL.SelectedIndex = 0;

        TextBoxChipIO.Text = "00A404000E315041592E5359532E444446303100";
        TextBoxCISScan.Text = "/home/hanmega/Documents/Image/ScanTest.jpg";

        Initialize();
    }

    public void Initialize()
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            CheckBoxTraceLog.IsDefault = _cardReader.TraceLog;
        });

        _cardReader.OnDeviceOpened += CISCardReaderOpened;
        _cardReader.OnDeviceClosed +=  CISCardReaderClosed;
        _cardReader.OnInitializeCompleted +=  CISInitializeCompleted; 
        _cardReader.OnAcceptStarted += CISAcceptStarted;  
        _cardReader.OnAcceptCompleted += CISCardReadCompleted;
        _cardReader.OnAcceptCanceled += CISAcceptCanceled;   
        _cardReader.OnCISScanCompleted +=  CISScanCompleted;
        _cardReader.OnEjectCompleted +=  CISEjectCompleted;      
        _cardReader.OnRetractCompleted += CISRetractCompleted;
        _cardReader.OnMediaTaken += CISMediaTaken;
        _cardReader.OnDeviceError += CISDeviceError;
        _cardReader.OnChipResetCompleted += CISChipResetCompleted;
        _cardReader.OnChipResetError += CISChipResetError;
    }

    public void CISCardReaderOpened(Object? sender, String portPath)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Device Opened: {portPath}";
            TextBlockVersion.Text = _cardReader.Version;
            TextBlockMedia.Text = _cardReader.StMedia;
        });

        ClearTrackText();
    }

    private void CISCardReaderClosed(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Closed device";
            TextBlockMedia.Text = _cardReader.StMedia;
        });

        ClearTrackText();
    }

    private void CISInitializeCompleted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Initialize Completed";
            TextBlockMedia.Text = _cardReader.StMedia;
        });

        ClearTrackText();
    }

    private void CISAcceptStarted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Accept Started";
            TextBlockMedia.Text = _cardReader.StMedia;
        });

        ClearTrackText();
    }

    private void CISCardReadCompleted(object? sender, Track track)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"CardReader Completed";
            TextBlockMedia.Text = _cardReader.StMedia;

            TextBoxTrack1.Text = track.Track1;
            TextBoxTrack2.Text = track.Track2;
            TextBoxTrack3.Text = track.Track3;
        });
    }

    private void CISAcceptCanceled(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Accept Canceled";
            TextBlockMedia.Text = _cardReader.StMedia;
        });

        ClearTrackText();
    }

    private void CISScanCompleted(object? sender, ScanImage scanImage)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Scan Completed. Image1 : {scanImage.ScanImg1}, Image2 : {scanImage.ScanImg2} ";
            TextBlockMedia.Text = _cardReader.StMedia;

            // Image Control load from XAML
            var imageControl1 = this.FindControl<Image>("ImageScan_Front");

            // image file load and set Image Control 
            if(scanImage.ScanImg1 != null)
            {
                var image = new Bitmap(scanImage.ScanImg1); // Bitmap argument : Image file path

                if(imageControl1 != null)
                imageControl1.Source = image;
            }

            var imageControl2 = this.FindControl<Image>("ImageScan_Back");  
            if(scanImage.ScanImg2 != null)
            {
                var image = new Bitmap(scanImage.ScanImg2); 

                if(imageControl2 != null)
                imageControl2.Source = image;
            }
        });
    }

    public void CISEjectCompleted(Object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Eject Completed";
            TextBlockMedia.Text = _cardReader.StMedia;
        });
    }

    public void CISRetractCompleted(Object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Retract Completed";
            TextBlockMedia.Text = _cardReader.StMedia;
        });
    }

    public void CISMediaTaken(Object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Media Taken";
            TextBlockMedia.Text = _cardReader.StMedia;
        });
    }

    private void CISDeviceError(object? sender, int e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Device Error: {e}";
            TextBlockMedia.Text = _cardReader.StMedia;
        });
    }

    private void CISChipResetCompleted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"ChipReset Completed";
            TextBlockMedia.Text = _cardReader.StMedia;
        });
    }

    private void CISChipResetError(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"ChipReset Error";
            TextBlockMedia.Text = _cardReader.StMedia;
        });
    }


    public void OnOpenClick(object sender, RoutedEventArgs e)
    {
        try
        {
            _cardReader.PortPath = ComboBoxPorts.SelectedValue?.ToString() ?? "/dev/ttyUSB0";
            _cardReader.OpenDevice();
        }
        catch(Exception ex)
        {
            CISCardReaderError(ex.Message);
        }
    }

    public void OnCloseClick(object sender, RoutedEventArgs e)
    {
        try
        {
            _cardReader.CloseDevice();
        }
        catch(Exception ex)
        {
            CISCardReaderError(ex.Message);
        }
    }

    public void OnInitializeClick(object sender, RoutedEventArgs e)
    {
        try
        {
            _cardReader.InitializeDevice();
        }
        catch(Exception ex)
        {
            CISCardReaderError(ex.Message);
        }
    }

    //
    public void OnAcceptCardClick(object sender, RoutedEventArgs e)
    {
        try
        {
            ClearTrackText();

            _cardReader.EMVOption = (short)(ComboBoxAcceptCard.SelectedIndex);
            _cardReader.AcceptCard();
        }
        catch(Exception ex)
        {
            CISCardReaderError(ex.Message);
        }
    }

    public void OnAcceptDLClick(object sender, RoutedEventArgs e)
    {
        try
        {
            ClearTrackText();

            _cardReader.EMVOption = (short)(ComboBoxAcceptCard.SelectedIndex);
            _cardReader.AcceptDL();
        }
        catch(Exception ex)
        {
            CISCardReaderError(ex.Message);
        }
    }

    //OnChipIOClick
    public void OnChipIOClick(object sender, RoutedEventArgs e)
    {
        if (TextBoxChipIO == null || TextBoxChipIO.Text == null)
            return;

        try
        {
            string value = TextBoxChipIO.Text;
            string respValue;
           
            respValue = _cardReader.ChipIO(value);

            Dispatcher.UIThread.Invoke( () => 
            {
                TextBoxResult.Text = $"ChipIO : " + respValue;
            });
        }
        catch(Exception ex)
        {
            CISCardReaderError(ex.Message);
        }
    }

    public void OnCancelAcceptClick(object sender, RoutedEventArgs e)
    {
        try
        {
            _cardReader.CancelAccept();
        }
        catch(Exception ex)
        {
            CISCardReaderError(ex.Message);
        }
    }

    public void OnCISScanClick(object sender, RoutedEventArgs e)
    {
        try
        {
            if (TextBoxCISScan == null || TextBoxCISScan.Text == null)
                return;

            string fileName = TextBoxCISScan.Text;
            _cardReader.Scan(fileName);
        }
        catch(Exception ex)
        {
            CISCardReaderError(ex.Message);
        }
    }

    public void OnEjectClick(object sender, RoutedEventArgs e)
    {
        try
        {
            _cardReader.Eject();
        }
        catch(Exception ex)
        {
            CISCardReaderError(ex.Message);
        }
    }

    public void OnRetrackClick(object sender, RoutedEventArgs e)
    {
        try
        {
            _cardReader.Retract();
        }
        catch(Exception ex)
        {
            CISCardReaderError(ex.Message);
        }
    }

    public void OnCheckTraceLog(object sender, RoutedEventArgs e)
    {
        _cardReader.TraceLog = CheckBoxTraceLog.IsChecked??false;
    }


    void CISCardReaderError(String errorMsg)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxResult.Text = errorMsg;
        });
    }

    void ClearTrackText()
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxTrack1.Text = "";
            TextBoxTrack2.Text = "";
            TextBoxTrack3.Text = "";
        });
    }

}
