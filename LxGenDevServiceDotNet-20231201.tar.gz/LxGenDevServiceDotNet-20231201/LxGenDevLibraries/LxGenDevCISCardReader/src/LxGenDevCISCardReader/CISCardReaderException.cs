namespace LxGenDevCISCardReader;

public class CISCardReaderException : Exception
{
    public int ErrorCode { get; internal set; }

    internal CISCardReaderException(int errorCode) : base($"Error Code : {errorCode}")
    {
        ErrorCode = errorCode;
    }
}