﻿using System.Diagnostics;
using System.Net;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.VisualBasic.FileIO;
using static LxGenDevCISCardReader.GenDevCISCardReaderLib;


namespace LxGenDevCISCardReader;

public class GenDevCISCardReader
{
    public string PortPath
    {
        get { return GenDevCISCardReaderLib.PortPath; }
        set { GenDevCISCardReaderLib.PortPath = value; }
    }

    public bool TraceLog
    {
        get { return GenDevCISCardReaderLib.TraceLog; }
        set { GenDevCISCardReaderLib.TraceLog = value; }
    }

    public short ForceEjectTime
    {
        get { return GenDevCISCardReaderLib.ForceEjectTime; }
        set { GenDevCISCardReaderLib.ForceEjectTime = value; }
    }

    public short EMVOption
    {
        get { return GenDevCISCardReaderLib.EMVOption; }
        set { GenDevCISCardReaderLib.EMVOption = value; }
    }

    public string StDevice => GenDevCISCardReaderLib.StDevice;

    public string StMedia => GenDevCISCardReaderLib.StMedia;

    public string Version => GenDevCISCardReaderLib.Version;

    public string MediaDetail => GenDevCISCardReaderLib.MediaDetail;


    public GenDevCISCardReader()
    {
        _cisEventDeviceOpenedDelegate = new CISEventDeviceOpenedDelegate(EventDeviceOpened);
        _cisEventDeviceClosedDelegate = new CISEventDeviceClosedDelegate(EventDeviceClosed);
        _cisEventInitializeCompletedDelegate = new CISEventInitializeCompletedDelegate(EventInitializeCompleted);
        _cisEventAcceptStartedDelegate = new CISEventAcceptStartedDelegate(EventAcceptStarted);
        _cisEventAcceptCompleted = new CISEventAcceptCompletedDelegate(EventAcceptCompleted);
        _cisEventAcceptCanceledDelegate = new CISEventAcceptCanceledDelegate(EventAcceptCanceled);
        _cisEventCISScanCompleted = new CISEventCISScanCompleted(EventCISScanCompleted);
        _cisEventEjectCompletedDelegate = new CISEventEjectCompletedDelegate(EventEjectCompleted);
        _cisEventRetractCompleted = new CISEventRetractCompleted(EventRetractCompleted);
        _cisEventMediaTaken = new CISEventMediaTaken(EventMediaTaken);
        _cisEventDeviceError = new CISEventDeviceError(EventDeviceError);
        _cisEventChipResetCompleted = new CISEventChipResetCompleted(EventChipResetCompleted);
        _cisEventChipResetError = new CISEventChipResetError(EventChipResetError);

        CISRegCallbackDeviceOpened(_cisEventDeviceOpenedDelegate);
        CISRegCallbackDeviceClosed(_cisEventDeviceClosedDelegate);
        CISRegCallbackInitializeCompleted(_cisEventInitializeCompletedDelegate);
        CISRegCallbackAcceptStarted(_cisEventAcceptStartedDelegate);
        CISRegCallbackAcceptCompleted(_cisEventAcceptCompleted);
        CISRegCallbackAcceptCanceled(_cisEventAcceptCanceledDelegate);
        CISRegCallbackCISScanCompleted(_cisEventCISScanCompleted);
        CISRegCallbackEjectCompleted(_cisEventEjectCompletedDelegate);
        CISRegCallbackRetractCompleted(_cisEventRetractCompleted);
        CISRegCallbackMediaTaken(_cisEventMediaTaken);
        CISRegCallbackDeviceError(_cisEventDeviceError);
        CISRegCallbackChipResetCompleted(_cisEventChipResetCompleted);
        CISRegCallbackChipResetError(_cisEventChipResetError);
    }

     // Methods
    public void OpenDevice()
    {
        short retval = CISOpenDevice();
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void CloseDevice()
    {
        int retval = CISCloseDevice();
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void InitializeDevice()
    {
        int retval = CISInitializeDevice();
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void AcceptCard()
    {
        int retval = CISAcceptCard();
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void CancelAccept()
    {
        int retval = CISCancelAccept();
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void Scan(string fileName)
    {
        int retval = CISScan(fileName);
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void Eject()
    {
        int retval = CISEject();
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void Retract()
    {
        int retval = CISRetract();
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void AcceptDL()
    {
        int retval = CISAcceptDL();
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public string ChipIO(string data)
    {
        int maxLen = 1024;
        StringBuilder respData = new StringBuilder(maxLen);
        
        int retval = CISChipIO(data, respData, maxLen);
        if (retval < 0)
        {
            throw new CISCardReaderException(retval);
        }

        return respData.ToString();
    }

    /*
    public string GetATRasChipReset()
    {
        int maxLen = 1024;
        StringBuilder respData = new StringBuilder(maxLen);

        int retval = CISGetATRasChipReset(respData, maxLen);
        if (retval < 0)
        {
            throw new CISCardReaderException(retval);
        }

        return respData.ToString();
    }

    public string ICDirection(string icSend)
    {
        int icSendLength = icSend.Length;
        int maxLen = 1024;
        int iIcRecvLen = 0;
        StringBuilder respData = new StringBuilder(maxLen);

        int retval = CISICDirection(icSendLength, icSend, ref iIcRecvLen, respData);
        if (retval < 0)
        {
            throw new CISCardReaderException(retval);
        }

        return respData.ToString();
    }
    */

    // EMV Methods
    public void EMV_parameter_init(int terminalType, string termID, string paramPath)
    {
        int retval = CIS_emvkrnl_parameter_init(terminalType, termID, paramPath );
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void EMV_set_term(int seq_cnt)
    {
        int retval = CIS_emvkrnl_set_term(seq_cnt);
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void EMV_transaction_type_select(int tranType)
    {
        int retval = CIS_emvkrnl_transaction_type_select(tranType);
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void EMV_account_type_select(int accType)
    {
        int retval = CIS_emvkrnl_account_type_select(accType);
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void EMV_application_selection(int keyValue)
    {
        int retval = CIS_emvkrnl_application_selection(keyValue);
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public string EMV_get_candidateList()
    {
        int maxLength = 1024;
        StringBuilder respData = new StringBuilder(maxLength);
        int retval = CIS_emvkrnl_get_candidateList(respData, maxLength);

        if (retval < 0)
        {
            throw new CISCardReaderException(retval);
        }

        return respData.ToString();
    }

    public void EMV_read_application()
    {
        int retval = CIS_emvkrnl_read_application();
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void EMV_offline_data_authentication()
    {
        int retval = CIS_emvkrnl_offline_data_authentication();
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void EMV_processing_restrictions()
    {
        int retval = CIS_emvkrnl_processing_restrictions();
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void EMV_cardholder_verification(ref string pinValue)
    {
        int retval = CIS_emvkrnl_cardholder_verification(pinValue);
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void EMV_terminal_risk_management()
    {
        int retval = CIS_emvkrnl_terminal_risk_management();
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void EMV_terminal_action_analysis()
    {
        int retval = CIS_emvkrnl_terminal_action_analysis();
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void EMV_set_purchase_amount(int type, int amount)
    {
        int retval = CIS_emvkrnl_set_purchase_amount(type, amount);
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void EMV_card_action_analysis()
    {
        int retval = CIS_emvkrnl_card_action_analysis();
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void EMV_online_reversal()
    {
        int retval = CIS_emvkrnl_online_reversal();
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void EMV_online_confirm()
    {
        int retval = CIS_emvkrnl_online_confirm();
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void EMV_online_advice()
    {
        int retval = CIS_emvkrnl_online_advice();
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void EMV_online_reject()
    {
        int retval = CIS_emvkrnl_online_reject();
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void EMV_online_referral()
    {
        int retval = CIS_emvkrnl_online_referral();
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void EMV_emvkrnl_unable_online()
    {
        int retval = CIS_emvkrnl_unable_online();
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void EMV_online_process(string arc, string iad, string issuerscript)
    {
        int retval = CIS_emvkrnl_online_process(arc, iad, issuerscript);
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public void EMV_completion()
    {
        int retval = CIS_emvkrnl_completion();
        if (retval != 0)
        {
            throw new CISCardReaderException(retval);
        }
    }

    public string EMV_read_dataElemet(string tagName)
    {
        int maxLength = 1024;
        StringBuilder respData = new StringBuilder(maxLength);

        int retval = CIS_emvkrnl_read_dataElemet(tagName, respData, maxLength);
        if (retval < 0)
        {
            throw new CISCardReaderException(retval);
        }

        return respData.ToString();
    }






    // Processing callback
    public void EventDeviceOpened(IntPtr pObj, String portPath)
    {
        OnDeviceOpened?.Invoke(null, portPath);
    }

    public void EventDeviceClosed(IntPtr pObj)
    {
        OnDeviceClosed?.Invoke(null, new ());
    }

    public void EventInitializeCompleted(IntPtr pObj)
    {
        OnInitializeCompleted?.Invoke(null, new ());
    }
    public void EventAcceptStarted(IntPtr pObj)
    {
        OnAcceptStarted?.Invoke(null, new ());
    }

    public void EventAcceptCompleted(IntPtr pObj, string track1, string track2, string track3)
    {
        OnAcceptCompleted?.Invoke(null, new Track(track1, track2, track3));
    }
    public void EventAcceptCanceled(IntPtr pObj)
    {
        OnAcceptCanceled?.Invoke(null, new ());
    }

    public void EventCISScanCompleted(IntPtr pObj, string scanImg1, string scanImg2)
    {
        OnCISScanCompleted?.Invoke(null, new ScanImage(scanImg1, scanImg2));
    }

    public void EventEjectCompleted(IntPtr pObj)
    {
        OnEjectCompleted?.Invoke(null, new ());
    }
    public void EventRetractCompleted(IntPtr pObj)
    {
        OnRetractCompleted?.Invoke(null, new ());
    }

    public void EventMediaTaken(IntPtr pObj)
    {
        OnMediaTaken?.Invoke(null, new ());
    }

    private void EventDeviceError(nint pObj, short reason)
    {
        OnDeviceError?.Invoke(null, reason);
    }

    public void EventChipResetCompleted(IntPtr pObj)
    {
        OnChipResetCompleted?.Invoke(null, new ());
    }

    public void EventChipResetError(IntPtr pObj)
    {
        OnChipResetError?.Invoke(null, new ());
    }

    //EVENT
    public event EventHandler<String>? OnDeviceOpened;
    public event EventHandler? OnDeviceClosed;
    public event EventHandler? OnInitializeCompleted;
    public event EventHandler? OnAcceptStarted;
    public event EventHandler<Track>? OnAcceptCompleted;
    public event EventHandler? OnAcceptCanceled;
    public event EventHandler<ScanImage>? OnCISScanCompleted; 
    public event EventHandler? OnEjectCompleted;
    public event EventHandler? OnRetractCompleted;
    public event EventHandler? OnMediaTaken;
    public event EventHandler<int>? OnDeviceError;
    public event EventHandler? OnChipResetCompleted;
    public event EventHandler? OnChipResetError;

    //
    //  Delegate can be deleted by Gabage collector if it pass as marshalling callback function.
    //  It need to keep reference to get callback function works.
    //
    private readonly CISEventDeviceOpenedDelegate _cisEventDeviceOpenedDelegate;
    private readonly CISEventDeviceClosedDelegate _cisEventDeviceClosedDelegate;
    private readonly CISEventInitializeCompletedDelegate _cisEventInitializeCompletedDelegate;
    private readonly CISEventAcceptStartedDelegate _cisEventAcceptStartedDelegate;
    private readonly CISEventAcceptCompletedDelegate _cisEventAcceptCompleted;
    private readonly CISEventAcceptCanceledDelegate _cisEventAcceptCanceledDelegate;
    private readonly CISEventCISScanCompleted _cisEventCISScanCompleted;
    private readonly CISEventEjectCompletedDelegate _cisEventEjectCompletedDelegate;
    private readonly CISEventRetractCompleted _cisEventRetractCompleted;
    private readonly CISEventMediaTaken _cisEventMediaTaken;
    private readonly CISEventDeviceError _cisEventDeviceError;
    private readonly CISEventChipResetCompleted _cisEventChipResetCompleted;
    private readonly CISEventChipResetError _cisEventChipResetError;

}
