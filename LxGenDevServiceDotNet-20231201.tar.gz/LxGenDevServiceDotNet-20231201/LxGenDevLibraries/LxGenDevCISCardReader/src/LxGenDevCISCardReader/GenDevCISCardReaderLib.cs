using System.Runtime.InteropServices;
using System.Text;

namespace LxGenDevCISCardReader;

internal static class GenDevCISCardReaderLib
{
    private const string LibraryName = "LxGenDevCISCardReader.so";

    private delegate int GetStringPropertyDelegate(StringBuilder buffer, int bufferLenth);

    private static String GetStringProperty(GetStringPropertyDelegate getProperty)
    {
        int bufferSize = 1024; // Adjust the buffer size as needed
        StringBuilder buffer = new StringBuilder(bufferSize);
        getProperty(buffer, bufferSize);
        return buffer.ToString();
    }

    /*
    typedef void (*CISEventDeviceOpened)(void* pobj, const char* OpenedPortPath);
    typedef void (*CISEventDeviceClosed)(void* pobj);
    typedef void (*CISEventInitializeCompleted)(void* pobj);
    typedef void (*CISEventAcceptStarted)(void* pobj);
    typedef void (*CISEventAcceptCompleted)(void* pobj, const char* CardTrack1, const char* CardTrack2, const char* CardTrack3);
    typedef void (*CISEventAcceptCanceled)(void* pobj);
    typedef void (*CISEventCISScanCompleted)(void* pobj, const char* ScanImg1, const char* ScanImg2);
    typedef void (*CISEventEjectCompleted)(void* pobj);
    typedef void (*CISEventRetractCompleted)(void* pobj);
    typedef void (*CISEventMediaTaken)(void* pobj);
    typedef void (*CISEventDeviceError)(void* pobj, short Reason);
    typedef void (*CISEventChipResetCompleted)(void* pobj);
    typedef void (*CISEventChipResetError)(void* pobj);

    void CISRegisterCallbackObject(void* pobject);
    void CISRegCallbackDeviceOpened(CISEventDeviceOpened eventfunc);
    void CISRegCallbackDeviceClosed(CISEventDeviceClosed eventfunc);
    void CISRegCallbackInitializeCompleted(CISEventInitializeCompleted eventfunc);
    void CISRegCallbackAcceptStarted(CISEventAcceptStarted eventfunc);
    void CISRegCallbackAcceptCompleted(CISEventAcceptCompleted eventfunc);
    void CISRegCallbackAcceptCanceled(CISEventAcceptCanceled eventfunc);
    void CISRegCallbackCISScanCompleted(CISEventCISScanCompleted eventfunc);
    void CISRegCallbackEjectCompleted(CISEventEjectCompleted eventfunc);
    void CISRegCallbackRetractCompleted(CISEventRetractCompleted eventfunc);
    void CISRegCallbackMediaTaken(CISEventMediaTaken eventfunc);
    void CISRegCallbackDeviceError(CISEventDeviceError eventfunc);
    void CISRegCallbackChipResetCompleted(CISEventChipResetCompleted eventfunc);
    void CISRegCallbackChipResetError(CISEventChipResetError eventfunc);
    */

    //Callback Delegates
    internal delegate void CISEventDeviceOpenedDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String portPath);
    internal delegate void CISEventDeviceClosedDelegate(IntPtr pObj);
    internal delegate void CISEventInitializeCompletedDelegate(IntPtr pObj);
    internal delegate void CISEventAcceptStartedDelegate(IntPtr pObj);
    internal delegate void CISEventAcceptCompletedDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String cardTrack1,[MarshalAs(UnmanagedType.LPStr)] String cardTrack2, [MarshalAs(UnmanagedType.LPStr)] String cardTrack3);    
    internal delegate void CISEventAcceptCanceledDelegate(IntPtr pObj);
    internal delegate void CISEventCISScanCompleted(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String scanImg1, [MarshalAs(UnmanagedType.LPStr)] String scanImg2);
    internal delegate void CISEventEjectCompletedDelegate(IntPtr pObj);
    internal delegate void CISEventRetractCompleted(IntPtr pObj);
    internal delegate void CISEventMediaTaken(IntPtr pObj);
    internal delegate void CISEventDeviceError(IntPtr pObj, short reason);
    internal delegate void CISEventChipResetCompleted(IntPtr pObj);
    internal delegate void CISEventChipResetError(IntPtr pObj);

    //Raw Event
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CISRegCallbackDeviceOpened([MarshalAs(UnmanagedType.FunctionPtr)] CISEventDeviceOpenedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CISRegCallbackDeviceClosed([MarshalAs(UnmanagedType.FunctionPtr)] CISEventDeviceClosedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CISRegCallbackInitializeCompleted([MarshalAs(UnmanagedType.FunctionPtr)] CISEventInitializeCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CISRegCallbackAcceptStarted([MarshalAs(UnmanagedType.FunctionPtr)] CISEventAcceptStartedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CISRegCallbackAcceptCompleted([MarshalAs(UnmanagedType.FunctionPtr)] CISEventAcceptCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CISRegCallbackAcceptCanceled([MarshalAs(UnmanagedType.FunctionPtr)] CISEventAcceptCanceledDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CISRegCallbackCISScanCompleted([MarshalAs(UnmanagedType.FunctionPtr)] CISEventCISScanCompleted func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CISRegCallbackEjectCompleted([MarshalAs(UnmanagedType.FunctionPtr)] CISEventEjectCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CISRegCallbackRetractCompleted([MarshalAs(UnmanagedType.FunctionPtr)] CISEventRetractCompleted func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CISRegCallbackMediaTaken([MarshalAs(UnmanagedType.FunctionPtr)] CISEventMediaTaken func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CISRegCallbackDeviceError([MarshalAs(UnmanagedType.FunctionPtr)] CISEventDeviceError func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CISRegCallbackChipResetCompleted([MarshalAs(UnmanagedType.FunctionPtr)] CISEventChipResetCompleted func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CISRegCallbackChipResetError([MarshalAs(UnmanagedType.FunctionPtr)] CISEventChipResetError func);

    /*
    //Properties
    int CISGetPortPath(char* pPortPath, int nMaxLength);
    void CISSetPortPath(const char* lpszNewValue);
    bool CISGetTraceLog();
    void CISSetTraceLog(bool bNewValue);
    short CISGetForceEjectTime();
    void CISSetForceEjectTime(short nNewValue);
    short CISGetEMVOption();
    void CISSetEMVOption(short nNewValue);
    int CISGetStDevice(char* pStDevice, int nMaxLength);
    int CISGetStMedia(char* pStDevice, int nMaxLength);
    int CISGetVersion(char* pVersion, int nMaxLength);
    int CISGetStMediaDetail(char* pStMediaDetail, int nMaxLength);
    */


    //Properties
    internal static string PortPath
    {
        get { return GetStringProperty(CISGetPortPath); }
        set { CISSetPortPath(value); }
    }

    internal static bool TraceLog
    {
        get { return CISGetTraceLog(); }
        set { CISSetTraceLog(value); }
    }

    internal static short ForceEjectTime
    {
        get { return CISGetForceEjectTime(); }
        set { CISSetForceEjectTime(value); }
    }

    internal static short EMVOption
    {
        get { return CISGetEMVOption(); }
        set { CISSetEMVOption(value); }
    }

    internal static string StDevice
    {
        get {return GetStringProperty(CISGetStDevice);}
    }

    internal static string StMedia
    {
        get {return GetStringProperty(CISGetStMedia);}
    }

    internal static string Version
    {
        get {return GetStringProperty(CISGetVersion);}
    }

    internal static string MediaDetail
    {
        get {return GetStringProperty(CISGetStMediaDetail);}
    }


    // Raw Properties
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CISGetPortPath(StringBuilder pPortPath, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CISSetPortPath([MarshalAs(UnmanagedType.LPStr)] string str);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern bool CISGetTraceLog();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CISSetTraceLog([MarshalAs(UnmanagedType.I1)] bool traceLog);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CISGetForceEjectTime();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CISSetForceEjectTime(short type);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CISGetEMVOption();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CISSetEMVOption(short type);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CISGetStDevice(StringBuilder pStDevice, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CISGetStMedia(StringBuilder pStMedia, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CISGetVersion(StringBuilder pVersion, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CISGetStMediaDetail(StringBuilder pStMediaDetail, int nMaxLength);

    /*
    short CISOpenDevice();
    short CISCloseDevice();
    short CISInitializeDevice();
    short CISAcceptCard();
    short CISCancelAccept();
    short CISScan(const char* FileName);
    short CISEject();
    short CISRetract();
    short CISAcceptDL();
    int CISChipIO(const char* szSendData, char* pRespData, int nMaxLength) ;
    int CISGetATRasChipReset(char* pRespData, int nMaxLength);
    int CISICDirection(int iIcSendLen, unsigned char *szIcSend, int *iIcRecvLen, unsigned char *szIcRecv);
    */

     // Raw Methods
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CISOpenDevice();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CISCloseDevice();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CISInitializeDevice();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CISAcceptCard();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CISCancelAccept();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CISScan([MarshalAs(UnmanagedType.LPStr)] string fileName);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CISEject();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CISRetract();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CISAcceptDL();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CISChipIO([MarshalAs(UnmanagedType.LPStr)] string szSendData, StringBuilder pRespData, int nMaxLength);

    /*
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CISGetATRasChipReset(StringBuilder pRespData, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CISICDirection(int iIcSendLen, [MarshalAs(UnmanagedType.LPStr)] string szIcSend, ref int iIcRecvLen, StringBuilder szIcRecv);
    */

    //EMV Methods
    /*
    short CIS_emvkrnl_parameter_init(int terminalType, const char* termID, const char* paramPath);
    short CIS_emvkrnl_set_term(int seq_cnt);
    short CIS_emvkrnl_transaction_type_select(int tranType);
    short CIS_emvkrnl_account_type_select(int accType);
    short CIS_emvkrnl_application_selection(int keyValue);
    int CIS_emvkrnl_get_candidateList(char* pRespData, int nMaxLength);
    short CIS_emvkrnl_read_application(void);
    short CIS_emvkrnl_offline_data_authentication(void);
    short CIS_emvkrnl_processing_restrictions(void);
    short CIS_emvkrnl_cardholder_verification(const char* pinValue);
    short CIS_emvkrnl_terminal_risk_management(void);
    short CIS_emvkrnl_terminal_action_analysis(void);
    short CIS_emvkrnl_set_purchase_amount(int nType, int nAmount);
    short CIS_emvkrnl_card_action_analysis(void);
    short CIS_emvkrnl_online_reversal(void);
    short CIS_emvkrnl_online_confirm(void);
    short CIS_emvkrnl_online_advice(void);
    short CIS_emvkrnl_online_reject(void);
    short CIS_emvkrnl_online_referral(void);
    short CIS_emvkrnl_unable_online(void);
    short CIS_emvkrnl_online_process(const char* arc, const char* iad, const char* issuerscript);
    short CIS_emvkrnl_completion(void);
    int CIS_emvkrnl_read_dataElemet(const char* tagName, char* pRespData, int nMaxLength);
    */

    // Raw Methods[EMV]
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CIS_emvkrnl_parameter_init(int terminalType, [MarshalAs(UnmanagedType.LPStr)] string termID, [MarshalAs(UnmanagedType.LPStr)] string paramPath);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CIS_emvkrnl_set_term(int seq_cnt);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CIS_emvkrnl_transaction_type_select(int tranType);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CIS_emvkrnl_account_type_select(int accType);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CIS_emvkrnl_application_selection(int keyValue);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CIS_emvkrnl_get_candidateList(StringBuilder pRespData, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CIS_emvkrnl_read_application();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CIS_emvkrnl_offline_data_authentication();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CIS_emvkrnl_processing_restrictions();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CIS_emvkrnl_cardholder_verification([MarshalAs(UnmanagedType.LPStr)] string pinValue);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CIS_emvkrnl_terminal_risk_management();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CIS_emvkrnl_terminal_action_analysis();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CIS_emvkrnl_set_purchase_amount(int nType, int nAmount);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CIS_emvkrnl_card_action_analysis();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CIS_emvkrnl_online_reversal();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CIS_emvkrnl_online_confirm();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CIS_emvkrnl_online_advice();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CIS_emvkrnl_online_reject();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CIS_emvkrnl_online_referral();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CIS_emvkrnl_unable_online();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CIS_emvkrnl_online_process([MarshalAs(UnmanagedType.LPStr)] string arc,[MarshalAs(UnmanagedType.LPStr)] string iad, [MarshalAs(UnmanagedType.LPStr)] string issuerscript);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CIS_emvkrnl_completion();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CIS_emvkrnl_read_dataElemet([MarshalAs(UnmanagedType.LPStr)] string tagName, StringBuilder pRespData, int nMaxLength);

}