namespace LxGenDevCISCardReader;

public class Track
{
    public string? Track1 {get;set;}
    public string? Track2 {get;set;}
    public string? Track3 {get;set;}

    public Track(string track1, string track2, string track3)
    {
        Track1 = track1;
        Track2 = track2;
        Track3 = track3;
    }
}

public class ScanImage
{
    public string? ScanImg1 {get;set;}
    public string? ScanImg2 {get;set;}
  

    public ScanImage(string scanImg1, string scanImg2)
    {
        ScanImg1 = scanImg1;
        ScanImg2 = scanImg2;
    }
}
