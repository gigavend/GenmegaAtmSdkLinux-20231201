namespace LxGenDevReceiptPrinter;

public class ReceiptMargin
{
    public int Head { get; set; }
    public int Tail { get; set;}
}
