﻿using System.Diagnostics;
using System.Net;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.VisualBasic.FileIO;
using static LxGenDevReceiptPrinter.GenDevReceiptPrinterLib;

namespace LxGenDevReceiptPrinter;

public class GenDevReceiptPrinter
{
    private TaskCompletionSource<bool>? _tcsCommand;

    // Events
    public event EventHandler<String>? OnDeviceOpened;
    public event EventHandler? OnDeviceClosed;
    public event EventHandler? OnInitialized;
    public event EventHandler? OnPrinted;
    public event EventHandler? OnCut;
    public event EventHandler<ReceiptPrinterStatus>? OnChangedStatus;
    public event EventHandler<int>? OnDeviceError;
    public event EventHandler<ReceiptMargin>? OnGotVerticalMargin;
    public event EventHandler? OnSetVerticalMargin;

    // Properties
    public string PortPath
    {
        get { return GenDevReceiptPrinterLib.PortPath; }
        set { GenDevReceiptPrinterLib.PortPath = value; }
    }

    public int BaudRate
    {
        get { return GenDevReceiptPrinterLib.BaudRate; }
        set { GenDevReceiptPrinterLib.BaudRate = value; }
    }

    public int ByteSize
    {
        get { return GenDevReceiptPrinterLib.ByteSize; }
        set { GenDevReceiptPrinterLib.ByteSize = value; }
    }

    public int Parity
    {
        get { return GenDevReceiptPrinterLib.Parity; }
        set { GenDevReceiptPrinterLib.Parity = value; }
    }

    public int StopBits
    {
        get { return GenDevReceiptPrinterLib.StopBits; }
        set { GenDevReceiptPrinterLib.StopBits = value; }
    }

    public bool TraceLog
    {
        get { return GenDevReceiptPrinterLib.TraceLog; }
        set { GenDevReceiptPrinterLib.TraceLog = value; }
    }

    public int PollingInterval
    {
        get { return GenDevReceiptPrinterLib.PollingInterval; }
        set { GenDevReceiptPrinterLib.PollingInterval = value; }
    }

    public bool UsbType
    {
        get { return GenDevReceiptPrinterLib.UsbType; }
        set { GenDevReceiptPrinterLib.UsbType = value; }
    }

    public short ProductId
    {
        get { return GenDevReceiptPrinterLib.ProductId; }
        set { GenDevReceiptPrinterLib.ProductId = value; }
    }

    public String Version => GenDevReceiptPrinterLib.Version;
    public String ErrorCode => GenDevReceiptPrinterLib.ErrorCode;
    public String ErrorDesc => GenDevReceiptPrinterLib.ErrorDesc;
    public String StDevice => GenDevReceiptPrinterLib.StDevice;
    public String StMedia => GenDevReceiptPrinterLib.StMedia;
    public String StPaper => GenDevReceiptPrinterLib.StPaper;
    public String StPaperEx => GenDevReceiptPrinterLib.StPaperEx;
    public String StLever => GenDevReceiptPrinterLib.StLever;
    public String StPrinterHead => GenDevReceiptPrinterLib.StPrinterHead;
    public String CRCValue => GenDevReceiptPrinterLib.CRCValue;


    public GenDevReceiptPrinter()
    {
        _rpuEventDeviceOpenedDelegate = new (EventDeviceOpened);
        _rpuEventDeviceClosedDelegate = new (EventDeviceClosed);
        _rpuEventInitializeCompletedDelegate = new (EventInitialized);
        _rpuEventPrintCompletedDelegate = new (EventPrinted);
        _rpuEventPrintAndCutCompletedDelegate = new (EventPrinted);
        _rpuEventPrintImageCompletedDelegate = new (EventPrinted);
        _rpuEventPrintImageAndCutCompletedDelegate = new (EventPrinted);
        _rpuEventCutCompletedDelegate = new (EventCut);
        _rpuEventStatusChangedDelegate = new (EventStatusChanged);
        _rpuEventDeviceErrorDelegate = new (EventDeviceError);
        _rpuEventGetVerticalMarginCompletedDelegate = new (EventGotVerticalMargin);
        _rpuEventSetVerticalMarginCompletedDelegate = new (EventSetVerticalMargin);

        RPURegCallbackDeviceOpened(_rpuEventDeviceOpenedDelegate);
        RPURegCallbackDeviceClosed(_rpuEventDeviceClosedDelegate);
        RPURegCallbackInitializeCompleted(_rpuEventInitializeCompletedDelegate);
        RPURegCallbackPrintCompleted(_rpuEventPrintCompletedDelegate);
        RPURegCallbackCutCompleted(_rpuEventCutCompletedDelegate);
        RPURegCallbackPrintImageCompleted(_rpuEventPrintImageCompletedDelegate);
        RPURegCallbackStatusChanged(_rpuEventStatusChangedDelegate);
        RPURegCallbackDeviceError(_rpuEventDeviceErrorDelegate);
        RPURegCallbackPrintAndCutCompleted(_rpuEventPrintAndCutCompletedDelegate);
        RPURegCallbackPrintImageAndCutCompleted(_rpuEventPrintImageAndCutCompletedDelegate);
        RPURegCallbackGetVerticalMarginCompleted(_rpuEventGetVerticalMarginCompletedDelegate);
        RPURegCallbackSetVerticalMarginCompleted(_rpuEventSetVerticalMarginCompletedDelegate);
    }

    // Methods
    public void OpenDevice()
    {
        short retval = RPUOpenDevice();
        if (retval != 0)
        {
            throw new ReceiptPrinterException(retval);
        }
    }

    public void CloseDevice()
    {
        int retval = RPUCloseDevice();
        if (retval != 0)
        {
            throw new ReceiptPrinterException(retval);
        }
    }

    public void Initialize(bool cutPaper)
    {
        int retval = RPUInitializeDevice(cutPaper);
        if (retval != 0)
        {
            throw new ReceiptPrinterException(retval);
        }
    }

    public void PrintText(string text, bool cutPaper)
    {
        if (_tcsCommand != null)
            throw new ReceiptPrinterException(-3);

        int retval = 0;

        _tcsCommand = new TaskCompletionSource<bool>();

        if (cutPaper)
        {
            retval = RPUPrintAndCut(text, text.Length);
        }
        else 
        {
            retval = RPUPrintData(text, text.Length);
        }

        if (retval != 0)
        {
            _tcsCommand = null;
            throw new ReceiptPrinterException(retval);
        }

        Task.WaitAll(_tcsCommand.Task);
        _tcsCommand = null;
    }

    public void PrintImage(string filename, bool cutPaper, int paddingLeftColumns, int alignment)
    {
        int retval = 0;

        if (_tcsCommand != null)
           throw new ReceiptPrinterException(-3);

        _tcsCommand = new TaskCompletionSource<bool>();

        if (cutPaper)
        {
            retval = RPUPrintImageAndCut(filename, (short) paddingLeftColumns, (short)alignment);
        }
        else
        {
            retval = RPUPrintImage(filename, (short) paddingLeftColumns, (short)alignment);
        }
        if (retval != 0)
        {
            _tcsCommand = null;
            throw new ReceiptPrinterException(retval);
        }
        
        Task.WaitAll(_tcsCommand.Task);
        _tcsCommand = null;
    }

    public void Cut()
    {
        int retval = RPUCut();
        if (retval != 0)
        {
            throw new ReceiptPrinterException(retval);
        }
    }

    public void GetVerticalMargin()
    {
        int retval = RPUGetVerticalMargin();
        if (retval != 0)
        {
            throw new ReceiptPrinterException(retval);
        }
    }

    public void SetVerticalMargin(ReceiptMargin margin)
    {
        int retval= RPUSetVerticalMargin((short)margin.Head, (short)margin.Tail);
        if (retval != 0)
        {
            throw new ReceiptPrinterException(retval);
        }
    }

    // Processing callback
    private void EventSetVerticalMargin(nint pObj)
    {
        OnSetVerticalMargin?.Invoke(null, new());
        if (_tcsCommand != null)
        {
            _tcsCommand.SetResult(true);
        }
    }

    private void EventGotVerticalMargin(nint pObj, short head, short tail)
    {
        OnGotVerticalMargin?.Invoke(null, new ReceiptMargin()
        {
            Head = head,
            Tail = tail
        });
        if (_tcsCommand != null)
        {
            _tcsCommand.SetResult(true);
        }
    }

    private void EventDeviceError(nint pObj, short reason)
    {
        OnDeviceError?.Invoke(null, reason);
        if (_tcsCommand != null)
        {
            _tcsCommand.SetResult(false);
        }
    }

    private void EventStatusChanged(nint pObj, string changedStatus, string prevStatus, string currentStatus)
    {
        OnChangedStatus?.Invoke(null, new ReceiptPrinterStatus(changedStatus,prevStatus,currentStatus));
    }

    private void EventCut(nint pObj)
    {
        OnCut?.Invoke(null, new());
        if (_tcsCommand != null)
        {
            _tcsCommand.SetResult(true);
        }
    }
    private void EventPrinted(nint pObj)
    {
        OnPrinted?.Invoke(null, new());
        if (_tcsCommand != null)
        {
            _tcsCommand.SetResult(true);
        }
    }

    private void EventInitialized(nint pObj)
    {
        OnInitialized?.Invoke(null, new ());
    }

    private void EventDeviceClosed(IntPtr pObj)
    {
        OnDeviceClosed?.Invoke(null, new ());
    }

    void EventDeviceOpened(IntPtr pObj, String portPath)
    {
        OnDeviceOpened?.Invoke(null, portPath);
    }

    //
    //  Delegate can be deleted by Gabage collector if it pass as marshalling callback function.
    //  It need to keep reference to get callback function works.
    //
    private readonly RPUEventDeviceOpenedDelegate _rpuEventDeviceOpenedDelegate;
    private readonly RPUEventDeviceClosedDelegate _rpuEventDeviceClosedDelegate;
    private readonly RPUEventInitializeCompletedDelegate _rpuEventInitializeCompletedDelegate;
    private readonly RPURPUEventPrintCompletedDelegate _rpuEventPrintCompletedDelegate;
    private readonly RPUEventPrintAndCutCompletedDelegate _rpuEventPrintAndCutCompletedDelegate;
    private readonly RPUEventPrintImageCompletedDelegate _rpuEventPrintImageCompletedDelegate;
    private readonly RPUEventPrintImageAndCutCompletedDelegate _rpuEventPrintImageAndCutCompletedDelegate;
    private readonly RPUEventCutCompletedDelegate _rpuEventCutCompletedDelegate;
    private readonly RPUEventStatusChangedDelegate _rpuEventStatusChangedDelegate;
    private readonly RPUEventDeviceErrorDelegate _rpuEventDeviceErrorDelegate;
    private readonly RPUEventGetVerticalMarginCompletedDelegate _rpuEventGetVerticalMarginCompletedDelegate;
    private readonly RPUEventSetVerticalMarginCompletedDelegate _rpuEventSetVerticalMarginCompletedDelegate;
}
