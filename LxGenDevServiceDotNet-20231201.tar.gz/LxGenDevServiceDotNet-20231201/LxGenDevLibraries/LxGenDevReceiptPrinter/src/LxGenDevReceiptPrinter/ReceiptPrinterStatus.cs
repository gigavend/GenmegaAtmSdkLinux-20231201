namespace LxGenDevReceiptPrinter;

public class ReceiptPrinterStatus
{
    public String Status { get; set; }
    public String PreviousStatus { get; set; }
    public String CurrentStatus { get; set;}

    internal  ReceiptPrinterStatus(String status, String prevStatus, String currentStatus)
    {
        Status = status;
        PreviousStatus = prevStatus;
        CurrentStatus = currentStatus;
    }
}
