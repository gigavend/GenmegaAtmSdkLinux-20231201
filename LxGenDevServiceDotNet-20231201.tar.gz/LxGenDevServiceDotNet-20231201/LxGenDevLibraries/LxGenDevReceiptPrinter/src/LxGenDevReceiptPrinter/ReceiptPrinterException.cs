namespace LxGenDevReceiptPrinter;

public class ReceiptPrinterException : Exception
{
    public int ErrorCode { get; internal set; }

    internal ReceiptPrinterException(int errorCode) : base($"Error Code : {errorCode}")
    {
        ErrorCode = errorCode;
    }
}