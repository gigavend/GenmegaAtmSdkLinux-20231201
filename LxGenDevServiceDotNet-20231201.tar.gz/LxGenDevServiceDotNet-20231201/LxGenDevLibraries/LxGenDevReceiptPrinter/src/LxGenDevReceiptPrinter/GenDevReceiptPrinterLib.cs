using System.Runtime.InteropServices;
using System.Text;

namespace LxGenDevReceiptPrinter;

internal static class GenDevReceiptPrinterLib
{
    private const string LibraryName = "LxGenDevReceiptPrinter.so";

    private delegate int GetStringPropertyDelegate(StringBuilder buffer, int bufferLenth);

    // Callback Delegates
    internal delegate void RPUEventDeviceOpenedDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String portPath);
    internal delegate void RPUEventDeviceClosedDelegate(IntPtr pObj);
    internal delegate void RPUEventInitializeCompletedDelegate(IntPtr pObj);
    internal delegate void RPURPUEventPrintCompletedDelegate(IntPtr pObj);
    internal delegate void RPUEventPrintAndCutCompletedDelegate(IntPtr pObj);
    internal delegate void RPUEventPrintImageCompletedDelegate(IntPtr pObj);
    internal delegate void RPUEventPrintImageAndCutCompletedDelegate(IntPtr pObj);
    internal delegate void RPUEventCutCompletedDelegate(IntPtr pObj);
    internal delegate void RPUEventStatusChangedDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String changedStatus, [MarshalAs(UnmanagedType.LPStr)] String prevStatus, [MarshalAs(UnmanagedType.LPStr)] String currentStatus);
    internal delegate void RPUEventDeviceErrorDelegate(IntPtr pObj, short reason);
    internal delegate void RPUEventGetVerticalMarginCompletedDelegate(IntPtr pObj, short head, short tail);
    internal delegate void RPUEventSetVerticalMarginCompletedDelegate(IntPtr pObj);

    private static String GetStringProperty(GetStringPropertyDelegate getProperty)
    {
        int bufferSize = 1024; // Adjust the buffer size as needed
        StringBuilder buffer = new StringBuilder(bufferSize);
        getProperty(buffer, bufferSize);
        return buffer.ToString();
    }

    internal static string PortPath
    {
        get { return GetStringProperty(RPUGetPortPath); }
        set { RPUSetPortPath(value); }
    }

    internal static int BaudRate
    {
        get { return RPUGetBaudRate(); }
        set { RPUSetBaudRate(value); }
    }

    internal static int ByteSize
    {
        get { return RPUGetByteSize(); }
        set { RPUSetByteSize((short)value); }
    }

    internal static int Parity
    {
        get { return RPUGetParity(); }
        set { RPUSetParity((short)value); }
    }

    internal static int StopBits
    {
        get { return RPUGetStopBits(); }
        set { RPUSetStopBits((short)value); }
    }

    internal static bool TraceLog
    {
        get { return RPUGetTraceLog(); }
        set { RPUSetTraceLog(value); }
    }

    internal static int PollingInterval
    {
        get { return RPUGetPollingInterval(); }
        set { RPUSetPollingInterval(value); }
    }

    internal static bool UsbType
    {
        get { return RPUGetUSBType(); }
        set { RPUSetUSBType(value); }
    }

    internal static short ProductId
    {
        get { return RPUGetProductID(); }
        set { RPUSetProductID(value); }
    }

    internal static String Version
    {
        get { return GetStringProperty(RPUGetVersion); }
    }

    internal static String ErrorCode
    {
        get { return GetStringProperty(RPUGetErrorCode); }
    }

    internal static String ErrorDesc
    {
        get { return GetStringProperty(RPUGetErrorDesc); }
    }

    internal static String StDevice
    {
        get { return GetStringProperty(RPUGetStDevice); }
    }

    internal static String StMedia
    {
        get { return GetStringProperty(RPUGetStMedia); }
    }

    internal static String StPaper
    {
        get { return GetStringProperty(RPUGetStPaper); }
    }

    internal static String StPaperEx
    {
        get { return GetStringProperty(RPUGetStPaperEx); }
    }

    internal static String StLever
    {
        get { return GetStringProperty(RPUGetStLever); }
    }

    internal static String StPrinterHead
    {
        get { return GetStringProperty(RPUGetStPrinterHead); }
    }

    internal static String CRCValue
    {
        get { return GetStringProperty(RPUGetCRCValue); }
    }

    // Raw Properties
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int RPUGetPortPath(StringBuilder pPortPath, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void RPUSetPortPath([MarshalAs(UnmanagedType.LPStr)] string str);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int RPUGetBaudRate();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void RPUSetBaudRate(int baudrate);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUGetByteSize();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void RPUSetByteSize(short byteSize);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUGetParity();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void RPUSetParity(short parity);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUGetStopBits();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void RPUSetStopBits(short stopBits);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    [return: MarshalAs(UnmanagedType.I1)]
    internal static extern bool RPUGetTraceLog();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void RPUSetTraceLog([MarshalAs(UnmanagedType.I1)] bool traceLog);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int RPUGetPollingInterval();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void RPUSetPollingInterval(int interval);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    [return: MarshalAs(UnmanagedType.I1)]
    internal static extern bool RPUGetUSBType();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void RPUSetUSBType([MarshalAs(UnmanagedType.I1)] bool usb);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUGetProductID();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void RPUSetProductID(short productId);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int RPUGetVersion(StringBuilder version, int length);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int RPUGetErrorCode(StringBuilder buffer, int length);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int RPUGetErrorDesc(StringBuilder buffer, int length);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int RPUGetStDevice(StringBuilder buffer, int length);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int RPUGetStMedia(StringBuilder buffer, int length);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int RPUGetStPaper(StringBuilder buffer, int length);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int RPUGetStPaperEx(StringBuilder buffer, int length);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int RPUGetStLever(StringBuilder buffer, int length);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int RPUGetStPrinterHead(StringBuilder buffer, int length);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int RPUGetCRCValue(StringBuilder buffer, int length);

    // Raw Methods
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUOpenDevice();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUCloseDevice();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUInitializeDevice([MarshalAs(UnmanagedType.I1)] bool flag);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUPrintData([MarshalAs(UnmanagedType.LPStr)] string data, int lenth);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUCut();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUPrintImage([MarshalAs(UnmanagedType.LPStr)] string filename, short skipColumn, short alignment);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUPrintSRAMImage();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUPrintAndCut([MarshalAs(UnmanagedType.LPStr)] string data, int lenth);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUPrintImageAndCut([MarshalAs(UnmanagedType.LPStr)] string filename, short skipColumn, short alignment);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUPrintSRAMImageAndCut();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUDownloadImage([MarshalAs(UnmanagedType.LPStr)] string filename, short index, int blockSize);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUPrintFlashImage(short index, short skipColumn);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUPrintFlashImageAndCut(short index, short skipColumn);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUPrintFormData(short MaxLine, [MarshalAs(UnmanagedType.LPStr)] string formData);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUPrintFormDataAndCut(short MaxLine, [MarshalAs(UnmanagedType.LPStr)] string formData);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUGetVerticalMargin();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUSetVerticalMargin(short start, short end);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUGetImageEndLine();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUSetImageEndLine(short endLine);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUBatchPrintMode();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short RPUSetCapType([MarshalAs(UnmanagedType.I1)] bool bVal);

    //
    // Register Callback Funtions
    //
    /*
    typedef void (*RPUEventDeviceOpened)(void* pobj, const char* OpenedPortPath);^M
    typedef void (*RPUEventDeviceUSBOpened)(void* pobj, short VendorId, short ProductId);^M
    typedef void (*RPUEventDeviceClosed)(void* pobj);^M
    typedef void (*RPUEventInitializeCompleted)(void* pobj);^M
    typedef void (*RPUEventPrintCompleted)(void* pobj);^M
    typedef void (*RPUEventCutCompleted)(void* pobj);^M
    typedef void (*RPUEventPrintImageCompleted)(void* pobj);^M
    typedef void (*RPUEventStatusChanged)(void* pobj, const char* ChangedStatus, const char* PrevStatus, const char* CurrentStatus);^M
    typedef void (*RPUEventDeviceError)(void* pobj, short Reason);^M
    typedef void (*RPUEventPrintAndCutCompleted)(void* pobj);^M
    typedef void (*RPUEventPrintImageAndCutCompleted)(void* pobj);^M
    typedef void (*RPUEventDownloadImageCompleted)(void* pobj);^M
    typedef void (*RPUEventGetVerticalMarginCompleted)(void* pobj, short nHead, short nTail);^M
    typedef void (*RPUEventSetVerticalMarginCompleted)(void* pobj);^M
    typedef void (*RPUEventGetImageEndLineCompleted)(void* pobj, short nEndLine);^M
    typedef void (*RPUEventSetImageEndLineCompleted)(void* pobj);^M
    typedef void (*RPUEventBatchPrintModeCompleted)(void* pobj);^M
    typedef void (*RPUEventSetCapTypeCompleted)(void* pobj);^M
    typedef void (*RPUEventFWDownloadStart)(void* pobj, int iTotal);^M
    typedef void (*RPUEventFWDownloading)(void* pobj, int iSent);^M
    typedef void (*RPUEventFWDownloadEnd)(void* pobj, int iSent);^M

    void RPURegisterCallbackObject(void* pobject);^M
    void RPURegCallbackDeviceOpened(RPUEventDeviceOpened eventfunc);^M
    void RPURegCallbackDeviceUSBOpened(RPUEventDeviceUSBOpened eventfunc);^M
    void RPURegCallbackDeviceClosed(RPUEventDeviceClosed eventfunc);^M
    void RPURegCallbackInitializeCompleted(RPUEventInitializeCompleted eventfunc);^M
    void RPURegCallbackPrintCompleted(RPUEventPrintCompleted eventfunc);^M
    void RPURegCallbackCutCompleted(RPUEventCutCompleted eventfunc);^M
    void RPURegCallbackPrintImageCompleted(RPUEventPrintImageCompleted eventfunc);^M
    void RPURegCallbackStatusChanged(RPUEventStatusChanged eventfunc);^M
    void RPURegCallbackDeviceError(RPUEventDeviceError eventfunc);^M
    void RPURegCallbackPrintAndCutCompleted(RPUEventPrintAndCutCompleted eventfunc);^M
    void RPURegCallbackPrintImageAndCutCompleted(RPUEventPrintImageAndCutCompleted eventfunc);^M
    void RPURegCallbackDownloadImageCompleted(RPUEventDownloadImageCompleted eventfunc);^M
    void RPURegCallbackGetVerticalMarginCompleted(RPUEventGetVerticalMarginCompleted eventfunc);^M
    void RPURegCallbackSetVerticalMarginCompleted(RPUEventSetVerticalMarginCompleted eventfunc);^M
    void RPURegCallbackGetImageEndLineCompleted(RPUEventGetImageEndLineCompleted eventfunc);^M
    void RPURegCallbackSetImageEndLineCompleted(RPUEventSetImageEndLineCompleted eventfunc);^M
    void RPURegCallbackBatchPrintModeCompleted(RPUEventBatchPrintModeCompleted eventfunc);^M
    void RPURegCallbackSetCapTypeCompleted(RPUEventSetCapTypeCompleted eventfunc);^M
    void RPURegCallbackFWDownloadStart(RPUEventFWDownloadStart eventfunc);^M
    void RPURegCallbackFWDownloading(RPUEventFWDownloading eventfunc);^M
    void RPURegCallbackFWDownloadEnd(RPUEventFWDownloadEnd eventfunc);^M
    */
    
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void RPURegCallbackDeviceOpened([MarshalAs(UnmanagedType.FunctionPtr)] RPUEventDeviceOpenedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void RPURegCallbackDeviceClosed([MarshalAs(UnmanagedType.FunctionPtr)] RPUEventDeviceClosedDelegate func);
    
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void RPURegCallbackInitializeCompleted([MarshalAs(UnmanagedType.FunctionPtr)] RPUEventInitializeCompletedDelegate func);
    
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void RPURegCallbackPrintCompleted([MarshalAs(UnmanagedType.FunctionPtr)] RPURPUEventPrintCompletedDelegate func);
    
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void RPURegCallbackCutCompleted([MarshalAs(UnmanagedType.FunctionPtr)] RPUEventCutCompletedDelegate func);
    
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void RPURegCallbackPrintImageCompleted([MarshalAs(UnmanagedType.FunctionPtr)] RPUEventPrintImageCompletedDelegate func);
    
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void RPURegCallbackStatusChanged([MarshalAs(UnmanagedType.FunctionPtr)] RPUEventStatusChangedDelegate func);
    
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void RPURegCallbackDeviceError([MarshalAs(UnmanagedType.FunctionPtr)] RPUEventDeviceErrorDelegate func);
    
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void RPURegCallbackPrintAndCutCompleted([MarshalAs(UnmanagedType.FunctionPtr)] RPUEventPrintAndCutCompletedDelegate func);
    
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void RPURegCallbackPrintImageAndCutCompleted([MarshalAs(UnmanagedType.FunctionPtr)] RPUEventPrintImageAndCutCompletedDelegate func);
    
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void RPURegCallbackGetVerticalMarginCompleted([MarshalAs(UnmanagedType.FunctionPtr)] RPUEventGetVerticalMarginCompletedDelegate func);
    
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void RPURegCallbackSetVerticalMarginCompleted([MarshalAs(UnmanagedType.FunctionPtr)] RPUEventSetVerticalMarginCompletedDelegate func);
}
