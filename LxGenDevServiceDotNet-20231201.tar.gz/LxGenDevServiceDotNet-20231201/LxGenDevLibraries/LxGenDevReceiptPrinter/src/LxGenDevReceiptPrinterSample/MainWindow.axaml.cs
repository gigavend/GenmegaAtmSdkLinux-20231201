using System;
using System.Linq;
using System.Threading.Tasks;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Platform.Storage;
using Avalonia.Threading;
using LxGenDevReceiptPrinter;

namespace LxGenDevReceiptPrinterSample;

public partial class MainWindow : Window
{
    GenDevReceiptPrinter _printer = new GenDevReceiptPrinter();

    public MainWindow()
    {
        InitializeComponent();

        ComboBoxPorts.ItemsSource = new String[] {"/dev/ttyS0","/dev/ttyS1","/dev/ttyS2","/dev/ttyS3","/dev/ttyS4","/dev/ttyS5", "/dev/ttyUSB0", "/dev/ttyUSB1" };
        ComboBoxPorts.SelectedIndex = 4; // Kiosk default is COM5

        ComboBoxBaudRate.ItemsSource = new int[] { 9600, 38400, 57600,115200, 460800 };
        ComboBoxBaudRate.SelectedIndex = 3; // # inches printer for Kiosk has 115200.

        Initialize();
    }

    public void Initialize()
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            CheckBoxTraceLog.IsDefault = _printer.TraceLog;
        });

        _printer.OnDeviceOpened += ReceiptPrinterOpened;
        _printer.OnDeviceClosed += ReceiptPrinterClosed;
        _printer.OnInitialized += ReceiptPrinterInitialized;
        _printer.OnPrinted += ReceiptPrinterPrinted;
        _printer.OnCut += ReceiptPrinterCut;
        _printer.OnChangedStatus += ReceiptPrinterChangedStatus;
        _printer.OnDeviceError += ReceiptPrinterDeviceError;
        _printer.OnGotVerticalMargin += ReceiptPrinterGotVerticalMargin;
        _printer.OnSetVerticalMargin += ReceiptPrinterSetVerticalMargin;
    }

    public void OnOpenClick(object sender, RoutedEventArgs e)
    {
        try
        {
            _printer.PortPath = ComboBoxPorts.SelectedValue?.ToString() ?? "/dev/ttyS4";
            _printer.BaudRate = int.Parse(ComboBoxBaudRate.SelectedValue?.ToString() ?? "115200");
            _printer.OpenDevice();
        }
        catch(Exception ex)
        {
            PrintError(ex.Message);
        }
    }

    public void OnCloseClick(object sender, RoutedEventArgs e)
    {
        try
        {
            _printer.CloseDevice();
        }
        catch(Exception ex)
        {
            PrintError(ex.Message);
        }
    }

    public void OnInitializeClick(object sender, RoutedEventArgs e)
    {
        try
        {
            _printer.Initialize(CheckBoxTestPrint.IsChecked ?? false);
        }
        catch(Exception ex)
        {
            PrintError(ex.Message);
        }
    }

    public void OnPrintTextClick(object sender, RoutedEventArgs e)
    {
        if (TextBoxPrintText == null || TextBoxPrintText.Text == null)
            return;

        try
        {
            String text = TextBoxPrintText.Text.Trim();
            _printer.PrintText(text, CheckBoxPrintTextCut.IsChecked ?? false);
        }
        catch(Exception ex)
        {
            PrintError(ex.Message);
        }
    }

    public void OnPrintImageClick(object sender, RoutedEventArgs e)
    {
        if (TextBoxImageFilePath == null || TextBoxImageFilePath.Text == null)
            return;

        try
        {
            bool cut = CheckBoxPrintImageCut.IsChecked??true;
            int paddingColumns = int.Parse(TextBoxImagePaddingColumns.Text?? "0");
            int align = ComboBoxImageAlign.SelectedIndex;
            _printer.PrintImage(TextBoxImageFilePath.Text.Trim(), cut, paddingColumns, align);
        }
        catch(Exception ex)
        {
            PrintError(ex.Message);
        }
    }

    public async void OnBrowseImageFileClickAsync(object sender, RoutedEventArgs e)
    {    
        try
        {
            // Get top level from the current control. Alternatively, you can use Window reference instead.
            var topLevel = TopLevel.GetTopLevel(this);
            if (topLevel != null)
            {
                var files = await topLevel.StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
                {
                    Title = "Open Image File",
                    AllowMultiple = false
                });

                if (files.Count >= 1)
                {
                    Dispatcher.UIThread.Invoke( () => 
                    {
                        TextBoxImageFilePath.Text = files[0].TryGetLocalPath();
                    });
                }
            }
        }
        catch(Exception ex)
        {
            PrintError(ex.Message);
        }
    }

    public void OnCutClick(object sender, RoutedEventArgs e)
    {
        try
        {
            _printer.Cut();
        }
        catch(Exception ex)
        {
            PrintError(ex.Message);
        }
    }

    public void OnCheckTraceLog(object sender, RoutedEventArgs e)
    {
        _printer.TraceLog = CheckBoxTraceLog.IsChecked??false;
    }

    public void OnGetVerticalMargin(object sender, RoutedEventArgs e)
    {
        try
        {
            _printer.GetVerticalMargin();

        }
        catch(Exception ex)
        {
            PrintError(ex.Message);
        }
    }

    public void OnSetVerticalMargin(object sender, RoutedEventArgs e)
    {
        if (TextBoxVerticalHeadMargin.Text is null || TextBoxVerticalTailMargin.Text is null)
            return;

        try
        {
            int head = int.Parse(TextBoxVerticalHeadMargin.Text.Trim());
            int tail = int.Parse(TextBoxVerticalTailMargin.Text.Trim());
            _printer.SetVerticalMargin(new ReceiptMargin() { Head = head, Tail = tail });
        }
        catch(Exception ex)
        {
            PrintError(ex.Message);
        }
    }    

    private void UdpateStatusComponents()
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBlockStDevice.Text = _printer.StDevice;
            TextBlockStPaper.Text = _printer.StPaper;
            TextBlockStPaperEx.Text = _printer.StPaperEx;
            TextBlockStMedia.Text = _printer.StMedia;
            TextBlockStLever.Text = _printer.StLever;
            TextBlockStPrintHead.Text = _printer.StPrinterHead;
        });
    }

    private void ReceiptPrinterSetVerticalMargin(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = "OnSetVerticalMargin";
        });
    }

    private void ReceiptPrinterGotVerticalMargin(object? sender, ReceiptMargin e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            //TextBoxEvent.Text = "OnGotVerticalMargin";
            TextBoxVerticalHeadMargin.Text = e.Head.ToString();
            TextBoxVerticalTailMargin.Text = e.Tail.ToString();
        });
    }

    private void ReceiptPrinterDeviceError(object? sender, int e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Device Error: {e}";
            TextBoxError.Text = $"{_printer.ErrorCode} : {_printer.ErrorDesc}";
        });
    }

    private void ReceiptPrinterChangedStatus(object? sender, ReceiptPrinterStatus status)
    {
        UdpateStatusComponents();
    }   

    private void ReceiptPrinterCut(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Cut Completed";
        });
    }

    private void ReceiptPrinterPrinted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Print Completed";
        });
    }

    private void ReceiptPrinterClosed(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Closed device";
        });
        UdpateStatusComponents();
    }

    private void ReceiptPrinterInitialized(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Initialized";
        });
    }

    public void ReceiptPrinterOpened(Object? sender, String portPath)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Device Opened: {portPath}";
            TextBlockVersion.Text = _printer.Version;
        });

        UdpateStatusComponents();

        // Retrieve margin values.
        _printer.GetVerticalMargin();
    }

    void PrintError(String errorMsg)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxError.Text = errorMsg;
        });
    }


}