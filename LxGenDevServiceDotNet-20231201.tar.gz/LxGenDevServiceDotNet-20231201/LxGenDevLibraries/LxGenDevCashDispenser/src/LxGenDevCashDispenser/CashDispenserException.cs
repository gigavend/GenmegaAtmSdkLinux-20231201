namespace LxGenDevCashDispenser;

public class CashDispenserException : Exception
{
    public int ErrorCode { get; internal set; }

    internal CashDispenserException(int errorCode) : base($"Error Code : {errorCode}")
    {
        ErrorCode = errorCode;
    }
}