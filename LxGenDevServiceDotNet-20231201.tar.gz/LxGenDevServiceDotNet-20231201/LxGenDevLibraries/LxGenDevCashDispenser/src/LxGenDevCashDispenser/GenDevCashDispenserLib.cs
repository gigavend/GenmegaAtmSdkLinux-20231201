﻿using System.Runtime.InteropServices;
using System.Text;

namespace LxGenDevCashDispenser;

public class GenDevCashDispenserLib
{
    private const string LibraryName = "libLxGenDevCashDispenser.so";

    private delegate int GetStringPropertyDelegate(StringBuilder buffer, int bufferLenth);

    private static String GetStringProperty(GetStringPropertyDelegate getProperty)
    {
        int bufferSize = 1024; // Adjust the buffer size as needed
        StringBuilder buffer = new StringBuilder(bufferSize);
        getProperty(buffer, bufferSize);
        return buffer.ToString();
    }

    /*
    //Register Callback Event Function
    typedef void (*CDUEventDeviceOpened)(void* pObj, const char* OpenedPortPath);
    typedef void (*CDUEventDeviceClosed)(void* pObj);
    typedef void (*CDUEventInitializeCompleted)(void* pObj);
    typedef void (*CDUEventGetCDUInfoCompleted)(void* pObj, const char* CountryCode, short CassetteNumber,
                                                const char* CDUType, const char* ManufactorType, const char* Version);
    typedef void (*CDUEventSetCDUInfoCompleted)(void* pObj);
    typedef void (*CDUEventStatusChanged)(void* pObj, const char* ChangedStatus, const char* PrevStatus, const char* CurrentStatus);
    typedef void (*CDUEventDispenseProcessing)(void* pObj, short Count1, short Count2, short Count3, short Count4, short Count5, short Count6);
    typedef void (*CDUEventDispenseFailed)(void* pObj, short Reason, const char* DispensedCount,
                                        const char* DispensedInfo1, const char* DispensedInfo2,
                                        const char* DispensedInfo3, const char* DispensedInfo4,
                                        const char* DispensedInfo5, const char* DispensedInfo6);
    typedef void (*CDUEventDispenseCompleted)(void* pObj, const char* DispensedCount,
                                            const char* DispensedInfo1, const char* DispensedInfo2,
                                            const char* DispensedInfo3, const char* DispensedInfo4,
                                            const char* DispensedInfo5, const char* DispensedInfo6);
    typedef void (*CDUEventTestDispenseFailed)(void* pObj, short Reason,
                                            const char* DispensedInfo1, const char* DispensedInfo2,
                                            const char* DispensedInfo3, const char* DispensedInfo4,
                                            const char* DispensedInfo5, const char* DispensedInfo6);
    typedef void (*CDUEventTestDispenseCompleted)(void* pObj,
                                                const char* DispensedInfo1, const char* DispensedInfo2,
                                                const char* DispensedInfo3, const char* DispensedInfo4,
                                                const char* DispensedInfo5, const char* DispensedInfo6);
    typedef void (*CDUEventDeviceError)(void* pObj, short Reason);
    typedef void (*CDUEventPresentCompleted)(void* pObj);
    typedef void (*CDUEventShutterActionCompleted)(void* pObj);
    typedef void (*CDUEventRetractCompleted)(void* pObj);
    typedef void (*CDUEventExitPurgeCompleted)(void* pObj);
    typedef void (*CDUEventDispenseGlobalProcessing)(void* pObj, short Count1, short Count2, short Count3,
                                                    short Count4, short Count5, short Count6);
    typedef void (*CDUEventDispenseGlobalFailed)(void* pObj, short Reason, const char* DispensedCount,
                                                const char* DispensedInfo1, const char* DispensedInfo2,
                                                const char* DispensedInfo3, const char* DispensedInfo4,
                                                const char* DispensedInfo5, const char* DispensedInfo6);
    typedef void (*CDUEventDispenseGlobalCompleted)(void* pObj, const char* DispensedCount,
                                                    const char* DispensedInfo1, const char* DispensedInfo2,
                                                    const char* DispensedInfo3, const char* DispensedInfo4,
                                                    const char* DispensedInfo5, const char* DispensedInfo6);
    typedef void (*CDUEventTestDispenseGlobalFailed)(void* pObj, short Reason,
                                                    const char* DispensedInfo1, const char* DispensedInfo2,
                                                    const char* DispensedInfo3, const char* DispensedInfo4,
                                                    const char* DispensedInfo5, const char* DispensedInfo6);
    typedef void (*CDUEventTestDispenseGlobalCompleted)(void* pObj, const char* DispensedInfo1, const char* DispensedInfo2,
                                                        const char* DispensedInfo3, const char* DispensedInfo4,
                                                        const char* DispensedInfo5, const char* DispensedInfo6);


    void CDURegisterCallbackObject(void* pObject);
    void CDURegCallbackDeviceOpened(CDUEventDeviceOpened eventfunc);
    void CDURegCallbackDeviceClosed(CDUEventDeviceClosed eventfunc);
    void CDURegCallbackInitializeCompleted(CDUEventInitializeCompleted eventfunc);
    void CDURegCallbackGetCDUInfoCompleted(CDUEventGetCDUInfoCompleted eventfunc);
    void CDURegCallbackSetCDUInfoCompleted(CDUEventSetCDUInfoCompleted eventfunc);
    void CDURegCallbackStatusChanged(CDUEventStatusChanged eventfunc);
    void CDURegCallbackDispenseProcessing(CDUEventDispenseProcessing eventfunc);
    void CDURegCallbackDispenseFailed(CDUEventDispenseFailed eventfunc);
    void CDURegCallbackTestDispenseFailed(CDUEventTestDispenseFailed eventfunc);
    void CDURegCallbackTestDispenseCompleted(CDUEventTestDispenseCompleted eventfunc);
    void CDURegCallbackDispenseCompleted(CDUEventDispenseCompleted eventfunc);
    void CDURegCallbackDeviceError(CDUEventDeviceError eventfunc);
    void CDURegCallbackPresentCompleted(CDUEventPresentCompleted eventfunc);
    void CDURegCallbackShutterActionCompleted(CDUEventShutterActionCompleted eventfunc);
    void CDURegCallbackRetractCompleted(CDUEventRetractCompleted eventfunc);
    void CDURegCallbackExitPurgeCompleted(CDUEventExitPurgeCompleted eventfunc);
    void CDURegCallbackDispenseGlobalProcessing(CDUEventDispenseGlobalProcessing eventfunc);
    void CDURegCallbackDispenseGlobalFailed(CDUEventDispenseGlobalFailed eventfunc);
    void CDURegCallbackTestDispenseGlobalFailed(CDUEventTestDispenseGlobalFailed eventfunc);
    void CDURegCallbackTestDispenseGlobalCompleted(CDUEventTestDispenseGlobalCompleted eventfunc);
    void CDURegCallbackDispenseGlobalCompleted(CDUEventDispenseGlobalCompleted eventfunc);

    */

    //Callback Delegates
    internal delegate void CDUEventDeviceOpenedDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String portPath);
    internal delegate void CDUEventDeviceClosedDelegate(IntPtr pObj);
    internal delegate void CDUEventInitializeCompletedDelegate(IntPtr pObj);
    internal delegate void CDUEventGetCDUInfoCompletedDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String CountryCode, 
                                short CassetteNumber, [MarshalAs(UnmanagedType.LPStr)] String CDUType, 
                                [MarshalAs(UnmanagedType.LPStr)] String ManufactorType, [MarshalAs(UnmanagedType.LPStr)] String Version);
    internal delegate void CDUEventSetCDUInfoCompletedDelegate(IntPtr pObj);    
    internal delegate void CDUEventStatusChanged(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String ChangedStatus, 
                            [MarshalAs(UnmanagedType.LPStr)] String PrevStatus, [MarshalAs(UnmanagedType.LPStr)] String CurrentStatus);   
    internal delegate void CDUEventDispenseProcessingDelegate(IntPtr pObj, short Count1, short Count2, short Count3, short Count4, short Count5, short Count6);   
    internal delegate void CDUEventDispenseFailedDelegate(IntPtr pObj, short Reason, [MarshalAs(UnmanagedType.LPStr)] String DispensedCount,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo1, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo2,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo3, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo4,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo5, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo6);

    internal delegate void CDUEventDispenseCompletedDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String DispensedCount,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo1, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo2,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo3, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo4,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo5, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo6);
    internal delegate void CDUEventTestDispenseFailedDelegate(IntPtr pObj, short Reason,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo1, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo2,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo3, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo4,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo5, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo6);
     internal delegate void CDUEventTestDispenseCompletedDelegate(IntPtr pObj, 
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo1, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo2,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo3, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo4,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo5, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo6);    
    internal delegate void CDUEventDeviceErrorDelegate(IntPtr pObj, short Reason);
    internal delegate void CDUEventPresentCompletedDelegate(IntPtr pObj);
    internal delegate void CDUEventShutterActionCompletedDelegate(IntPtr pObj);
    internal delegate void CDUEventRetractCompletedDelegate(IntPtr pObj);

    /*
    internal delegate void CDUEventDispenseExProcessingDelegate(IntPtr pObj,short Count1, short Count2, short Count3, short Count4, short Count5, short Count6);
    internal delegate void CDUEventDispenseExFailedDelegate(IntPtr pObj, short Reason, [MarshalAs(UnmanagedType.LPStr)] String DispensedCount,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo1, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo2,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo3, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo4,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo5, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo6);
    internal delegate void CDUEventDispenseExCompletedDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String DispensedCount,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo1, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo2,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo3, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo4,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo5, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo6);
    internal delegate void CDUEventTestDispenseExFailedDelegate(IntPtr pObj, short Reason,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo1, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo2,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo3, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo4,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo5, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo6);

    internal delegate void CDUEventTestDispenseExCompletedDelegate(IntPtr pObjconst, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo1, 
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo2, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo3, 
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo4, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo5,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo6);
    
    internal delegate void CDUEventDenominationDispenseFailedDelegate(IntPtr pObj, short Reason, [MarshalAs(UnmanagedType.LPStr)] String DispensedCount,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo1, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo2,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo3, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo4,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo5, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo6);   
    internal delegate void CDUEventDenominationDispenseCompletedDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String DispensedCount,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo1, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo2,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo3, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo4,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo5, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo6);
    */


    internal delegate void CDUEventExitPurgeCompletedDelegate(IntPtr pObj);
    internal delegate void CDUEventDispenseGlobalProcessingDelegate(IntPtr pObj, short Count1, short Count2, short Count3, short Count4, short Count5, short Count6);
    internal delegate void CDUEventDispenseGlobalFailedDelegate(IntPtr pObj, short Reason,  [MarshalAs(UnmanagedType.LPStr)] String DispensedCount,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo1,  [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo2,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo3,  [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo4,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo5,  [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo6);
    internal delegate void CDUEventDispenseGlobalCompletedDelegate(IntPtr pObj,[MarshalAs(UnmanagedType.LPStr)] String DispensedCount,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo1, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo2,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo3, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo4,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo5, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo6);
    internal delegate void CDUEventTestDispenseGlobalFailedDelegate(IntPtr pObj,short Reason,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo1, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo2,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo3, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo4,
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo5, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo6);
    internal delegate void CDUEventTestDispenseGlobalCompletedDelegate(IntPtr pObj,[MarshalAs(UnmanagedType.LPStr)] String  DispensedInfo1, 
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo2, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo3, 
                            [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo4, [MarshalAs(UnmanagedType.LPStr)] String DispensedInfo5, 
                            [MarshalAs(UnmanagedType.LPStr)] String  DispensedInfo6);

    //Raw Event
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackDeviceOpened([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventDeviceOpenedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackDeviceClosed([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventDeviceClosedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackInitializeCompleted([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventInitializeCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackGetCDUInfoCompleted([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventGetCDUInfoCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackSetCDUInfoCompleted([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventSetCDUInfoCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackStatusChanged([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventStatusChanged func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackDispenseProcessing([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventDispenseProcessingDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackDispenseFailed([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventDispenseFailedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackTestDispenseFailed([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventTestDispenseFailedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackTestDispenseCompleted([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventTestDispenseCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackDispenseCompleted([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventDispenseCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackDeviceError([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventDeviceErrorDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackPresentCompleted([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventPresentCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackShutterActionCompleted([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventShutterActionCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackRetractCompleted([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventRetractCompletedDelegate func);


    /*
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackDispenseExProcessing([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventDispenseExProcessingDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackDispenseExFailed([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventDispenseExFailedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackTestDispenseExFailed([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventTestDispenseExFailedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackTestDispenseExCompleted([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventTestDispenseExCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackDispenseExCompleted([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventDispenseExCompletedDelegate func);
    
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackDenominationDispenseFailed([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventDenominationDispenseFailedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackDenominationDispenseCompleted([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventDenominationDispenseCompletedDelegate func);
    */


    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackExitPurgeCompleted([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventExitPurgeCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackDispenseGlobalProcessing([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventDispenseGlobalProcessingDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackDispenseGlobalFailed([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventDispenseGlobalFailedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackTestDispenseGlobalFailed([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventTestDispenseGlobalFailedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackTestDispenseGlobalCompleted([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventTestDispenseGlobalCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDURegCallbackDispenseGlobalCompleted([MarshalAs(UnmanagedType.FunctionPtr)] CDUEventDispenseGlobalCompletedDelegate func);


    /*
    //Properties
    int CDUGetPortPath(OUT char* pPortPath, IN int nMaxLength);
    void CDUSetPortPath(IN const char* lpszNewValue);
    int CDUGetBaudRate();
    void CDUSetBaudRate(IN int nNewValue);
    short CDUGetParity();
    void CDUSetParity(IN short nNewValue);
    short CDUGetStopBits();
    void CDUSetStopBits(IN short nNewValue);
    short CDUGetByteSize();
    void CDUSetByteSize(IN short nNewValue);
    long CDUGetPollingInterval();
    void CDUSetPollingInterval(IN long nNewValue);
    bool CDUGetTraceLog();
    void CDUSetTraceLog(IN bool bNewValue);
    int CDUGetCountryCode(OUT char* pCountryCode, IN int nMaxLength);
    short CDUGetCassetteNumber();
    int CDUGetCDUType(OUT char* pCDUType, IN int nMaxLength);
    int CDUGetVersion(OUT char* pVersion, IN int nMaxLength);
    bool CDUGetEnableDispenseProcessingEvent();
    void CDUSetEnableDispenseProcessingEvent(IN bool bNewValue);
    int CDUGetManufactorType(OUT char* pManufactorType, IN int nMaxLength);
    int CDUGetStDevice(OUT char* pDevice, IN int nMaxLength);
    int CDUGetStTransporter(OUT char* pTransporter, IN int nMaxLength);
    int CDUGetStCassette(OUT char* pCassette, IN int nMaxLength);
    int CDUGetStCstOutlet(OUT char* pCstOutlet, IN int nMaxLength);
    int CDUGetErrorCode(OUT char* pErrorCode, IN int nMaxLength);
    bool CDUGetbXPCduShutter();
    void CDUSetbXPCduShutter(IN const bool value);
    int CDUGetStExitSensor(OUT char* pExitSensor, IN int nMaxLength);
    */

    internal static string PortPath
    {
        get { return GetStringProperty(CDUGetPortPath); }
        set { CDUSetPortPath(value); }
    }

    internal static int BaudRate
    {
        get { return CDUGetBaudRate(); }
        set { CDUSetBaudRate(value); }
    }

    internal static int ByteSize
    {
        get { return CDUGetByteSize(); }
        set { CDUSetByteSize((short)value); }
    }

    internal static int Parity
    {
        get { return CDUGetParity(); }
        set { CDUSetParity((short)value); }
    }

    internal static int StopBits
    {
        get { return CDUGetStopBits(); }
        set { CDUSetStopBits((short)value); }
    }

    internal static long PollingInterval
    {
        get { return CDUGetPollingInterval(); }
        set { CDUSetPollingInterval(value); }
    }

    internal static bool TraceLog
    {
        get { return CDUGetTraceLog(); }
        set { CDUSetTraceLog(value); }
    }

    internal static String CountryCode
    {
        get { return GetStringProperty(CDUGetCountryCode); }
    }

    internal static short CassetteNumber
    {
        get { return CDUGetCassetteNumber(); }
    }

    internal static String CDUType
    {
        get { return GetStringProperty(CDUGetCountryCode); }
    }

    internal static String Version
    {
        get { return GetStringProperty(CDUGetVersion); }
    }

    internal static bool EnableDispenseProcessingEvent
    {
        get { return CDUGetEnableDispenseProcessingEvent(); }
        set { CDUSetEnableDispenseProcessingEvent(value); }
    }

    internal static String ManufactorType
    {
        get { return GetStringProperty(CDUGetManufactorType); }
    }

    internal static String StDevice
    {
        get { return GetStringProperty(CDUGetStDevice); }
    }

    internal static String StTransporter
    {
        get { return GetStringProperty(CDUGetStTransporter); }
    }

    internal static String StCassette
    {
        get { return GetStringProperty(CDUGetStCassette); }
    }

    /*
    internal static String LastDispensedCount
    {
        get { return GetStringProperty(CDUGetLastDispensedCount); }
    }

    internal static String LastDispensedInfo1
    {
        get { return GetStringProperty(CDUGetLastDispensedInfo1); }
    }

    internal static String LastDispensedInfo2
    {
        get { return GetStringProperty(CDUGetLastDispensedInfo2); }
    }

    internal static String LastDispensedInfo3
    {
        get { return GetStringProperty(CDUGetLastDispensedInfo3); }
    }

    internal static String LastDispensedInfo4
    {
        get { return GetStringProperty(CDUGetLastDispensedInfo4); }
    }

    internal static String LastDispensedInfo5
    {
        get { return GetStringProperty(CDUGetLastDispensedInfo5); }
    }

    internal static String LastDispensedInfo6
    {
        get { return GetStringProperty(CDUGetLastDispensedInfo6); }
    }
    */

    internal static String StCstOutlet
    {
        get { return GetStringProperty(CDUGetStCstOutlet); }
    }

    
    internal static String ErrorCode
    {
        get { return GetStringProperty(CDUGetErrorCode); }
    }

    /*
    internal static String StCassetteID1
    {
        get { return GetStringProperty(CDUGetStCassetteID1); }
    }

    internal static String StCassetteID2
    {
        get { return GetStringProperty(CDUGetStCassetteID2); }
    }

    internal static String StCassetteID3
    {
        get { return GetStringProperty(CDUGetStCassetteID3); }
    }

    internal static String StCassetteID4
    {
        get { return GetStringProperty(CDUGetStCassetteID4); }
    }

    internal static String StCassetteID5
    {
        get { return GetStringProperty(CDUGetStCassetteID5); }
    }

    internal static String StCassetteID6
    {
        get { return GetStringProperty(CDUGetStCassetteID6); }
    }
    */

    internal static bool XPCduShutter
    {
        get { return CDUGetbXPCduShutter(); }
        set { CDUSetbXPCduShutter(value); }
    }

    internal static String StExitSensor
    {
        get { return GetStringProperty(CDUGetStExitSensor); }
    }

    // Raw Properties
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetPortPath(StringBuilder pPortPath, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDUSetPortPath([MarshalAs(UnmanagedType.LPStr)] string str);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetBaudRate();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDUSetBaudRate(int baudrate);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CDUGetByteSize();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDUSetByteSize(short byteSize);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CDUGetParity();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDUSetParity(short parity);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CDUGetStopBits();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDUSetStopBits(short stopBits);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CDUGetPollingInterval();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDUSetPollingInterval(long interval);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern bool CDUGetTraceLog();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDUSetTraceLog([MarshalAs(UnmanagedType.I1)] bool traceLog);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetCountryCode(StringBuilder pCountryCode, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CDUGetCassetteNumber();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetCDUType(StringBuilder pCDUType, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetVersion(StringBuilder pVersion, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern bool CDUGetEnableDispenseProcessingEvent();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDUSetEnableDispenseProcessingEvent([MarshalAs(UnmanagedType.I1)] bool bNewValue);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetManufactorType(StringBuilder pManufactorType, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetStDevice(StringBuilder pDevice, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetStTransporter(StringBuilder pTransporter, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetStCassette(StringBuilder pCassette, int nMaxLength);

    /*
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetLastDispensedCount(StringBuilder pLastDispensedCount, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetLastDispensedInfo1(StringBuilder pLastDispensedInfo1, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetLastDispensedInfo2(StringBuilder pLastDispensedInfo2, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetLastDispensedInfo3(StringBuilder pLastDispensedInfo3, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetLastDispensedInfo4(StringBuilder pLastDispensedInfo4, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetLastDispensedInfo5(StringBuilder pLastDispensedInfo5, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetLastDispensedInfo6(StringBuilder pLastDispensedInfo6, int nMaxLength);
    */

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetStCstOutlet(StringBuilder pCstOutlet, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetErrorCode(StringBuilder pErrorCode, int nMaxLength);

    /*
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetStCassetteID1(StringBuilder pCassetteID1, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetStCassetteID2(StringBuilder pCassetteID2, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetStCassetteID3(StringBuilder pCassetteID3, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetStCassetteID4(StringBuilder pCassetteID4, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetStCassetteID5(StringBuilder pCassetteID5, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetStCassetteID6(StringBuilder pCassetteID6, int nMaxLength);
    */

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern bool CDUGetbXPCduShutter();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void CDUSetbXPCduShutter([MarshalAs(UnmanagedType.I1)] bool value);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int CDUGetStExitSensor(StringBuilder pExitSensor, int nMaxLength);

    /*
    //Methods
    short CDUOpenDevice(IN const char* LicenseKey);
    short CDUCloseDevice();
    short CDUInitializeDevice(IN bool Force);
    short CDUGetCDUInformation();
    short CDUSetCDUInformation(IN const char* CountryCode, IN short CassetteNumber, IN const char* CDUType);
    short CDUPresent();
    short CDUShutterAction(IN bool bOpen);
    short CDURetract();
    short CDUTestDispense(IN short ReqCount1, IN short ReqCount2, IN short ReqCount3, IN short ReqCount4, IN short ReqCount5, IN short ReqCount6);
    short CDUDispense(IN short ReqCount1, IN short ReqCount2, IN short ReqCount3, IN short ReqCount4, IN short ReqCount5, IN short ReqCount6);
    short CDUExitPurge();
    short CDUTestDispenseGlobal(IN const short reqcount1, IN const short notelength1,
            IN const short reqcount2, IN const short notelength2,
            IN const short reqcount3, IN const short notelength3,
            IN const short reqcount4, IN const short notelength4,
            IN const short reqcount5, IN const short notelength5,
            IN const short reqcount6, IN const short notelength6);
    short CDUDispenseGlobal(IN const short reqcount1, IN const short notelength1,
            IN const short reqcount2, IN const short notelength2,
            IN const short reqcount3, IN const short notelength3,
            IN const short reqcount4, IN const short notelength4,
            IN const short reqcount5, IN const short notelength5,
            IN const short reqcount6, IN const short notelength6);
    */

     // Raw Methods
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CDUOpenDevice([MarshalAs(UnmanagedType.LPStr)] string LicenseKey);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CDUCloseDevice();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CDUInitializeDevice([MarshalAs(UnmanagedType.I1)] bool Force);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CDUGetCDUInformation();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CDUSetCDUInformation([MarshalAs(UnmanagedType.LPStr)] string CountryCode, short CassetteCount, [MarshalAs(UnmanagedType.LPStr)] string CDUType);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CDUTestDispense(short ReqCount1, short ReqCount2, short ReqCount3, short ReqCount4, short ReqCount5, short ReqCount6);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CDUDispense(short ReqCount1, short ReqCount2, short ReqCount3, short ReqCount4, short ReqCount5, short ReqCount6);

    /*
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CDUClearDispensedInfo();
    */

    
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CDUPresent();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CDUShutterAction([MarshalAs(UnmanagedType.I1)] bool Force);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CDURetract();

    /*
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CDUTestDispenseEx(short ReqCount1, short ReqCount2, short ReqCount3, short ReqCount4, short ReqCount5, short ReqCount6);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CDUDispenseEx(short ReqCount1, short ReqCount2, short ReqCount3, short ReqCount4, short ReqCount5, short ReqCount6);
    */

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CDUAssignCstDenomination([MarshalAs(UnmanagedType.LPStr)] string Currency1, short Denomination1, 
                            [MarshalAs(UnmanagedType.LPStr)] string Currency2,  short Denomination2,
		                    [MarshalAs(UnmanagedType.LPStr)] string Currency3,  short Denomination3, 
                            [MarshalAs(UnmanagedType.LPStr)] string Currency4,  short Denomination4,
		                    [MarshalAs(UnmanagedType.LPStr)] string Currency5,  short Denomination5, 
                            [MarshalAs(UnmanagedType.LPStr)] string Currency6,  short Denomination6);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CDUDenominationDispense([MarshalAs(UnmanagedType.I1)] bool bPresent, string Currency1,  short Denomination1,  short ReqCount1,
		string Currency2,  short Denomination2,  short ReqCount2,
		string Currency3,  short Denomination3,  short ReqCount3,
		string Currency4,  short Denomination4,  short ReqCount4,
		string Currency5,  short Denomination5,  short ReqCount5,
		string Currency6,  short Denomination6,  short ReqCount6);


    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CDUExitPurge();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CDUSetDenomRecognize([MarshalAs(UnmanagedType.I1)] bool enable);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CDUTestDispenseGlobal(short reqcount1, short notelength1,
		 short reqcount2,  short notelength2,
		 short reqcount3,  short notelength3,
		 short reqcount4,  short notelength4,
		 short reqcount5,  short notelength5,
		 short reqcount6,  short notelength6);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short CDUDispenseGlobal(short reqcount1, short notelength1,
		 short reqcount2,  short notelength2,
		 short reqcount3,  short notelength3,
		 short reqcount4,  short notelength4,
		 short reqcount5,  short notelength5,
		 short reqcount6,  short notelength6);
   
}


