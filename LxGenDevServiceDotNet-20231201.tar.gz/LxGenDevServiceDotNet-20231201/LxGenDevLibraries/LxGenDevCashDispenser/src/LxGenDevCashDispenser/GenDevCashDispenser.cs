using System.Diagnostics;
using System.Net;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.VisualBasic.FileIO;

using static LxGenDevCashDispenser.GenDevCashDispenserLib;

namespace LxGenDevCashDispenser;

public class GenDevCashDispenser
{
      // Properties
    public string PortPath
    {
        get { return GenDevCashDispenserLib.PortPath; }
        set { GenDevCashDispenserLib.PortPath = value; }
    }

    public int BaudRate
    {
        get { return GenDevCashDispenserLib.BaudRate; }
        set { GenDevCashDispenserLib.BaudRate = value; }
    }

    public int ByteSize
    {
        get { return GenDevCashDispenserLib.ByteSize; }
        set { GenDevCashDispenserLib.ByteSize = value; }
    }

    public int Parity
    {
        get { return GenDevCashDispenserLib.Parity; }
        set { GenDevCashDispenserLib.Parity = value; }
    }

    public int StopBits
    {
        get { return GenDevCashDispenserLib.StopBits; }
        set { GenDevCashDispenserLib.StopBits = value; }
    }

    public long PollingInterval
    {
        get { return GenDevCashDispenserLib.PollingInterval; }
        set { GenDevCashDispenserLib.PollingInterval = value; }
    }

    public bool TraceLog
    {
        get { return GenDevCashDispenserLib.TraceLog; }
        set { GenDevCashDispenserLib.TraceLog = value; }
    }

    public string CountryCode => GenDevCashDispenserLib.CountryCode; 
    public short CassetteNumber => GenDevCashDispenserLib.CassetteNumber;
    public string CDUType => GenDevCashDispenserLib.CDUType; 
    public string Version => GenDevCashDispenserLib.Version; 
    
    public bool EnableDispenseProcessingEvent
    {
        get { return GenDevCashDispenserLib.EnableDispenseProcessingEvent; }
        set { GenDevCashDispenserLib.EnableDispenseProcessingEvent = value; }
    }

    public string ManufactorType => GenDevCashDispenserLib.ManufactorType; 
    public string StDevice => GenDevCashDispenserLib.StDevice; 
    public string StTransporter => GenDevCashDispenserLib.StTransporter; 
    public string StCassette => GenDevCashDispenserLib.StCassette; 

    /*
    public string LastDispensedCount => GenDevCashDispenserLib.LastDispensedCount; 
    public string LastDispensedInfo1 => GenDevCashDispenserLib.LastDispensedInfo1; 
    public string LastDispensedInfo2 => GenDevCashDispenserLib.LastDispensedInfo2; 
    public string LastDispensedInfo3 => GenDevCashDispenserLib.LastDispensedInfo3; 
    public string LastDispensedInfo4 => GenDevCashDispenserLib.LastDispensedInfo4; 
    public string LastDispensedInfo5 => GenDevCashDispenserLib.LastDispensedInfo5; 
    public string LastDispensedInfo6 => GenDevCashDispenserLib.LastDispensedInfo6; 
    */

    public string StCstOutlet => GenDevCashDispenserLib.StCstOutlet; 
    public string ErrorCode => GenDevCashDispenserLib.ErrorCode; 

    /*
    public string StCassetteID1 => GenDevCashDispenserLib.StCassetteID1; 
    public string StCassetteID2 => GenDevCashDispenserLib.StCassetteID2; 
    public string StCassetteID3 => GenDevCashDispenserLib.StCassetteID3; 
    public string StCassetteID4 => GenDevCashDispenserLib.StCassetteID4; 
    public string StCassetteID5 => GenDevCashDispenserLib.StCassetteID5; 
    public string StCassetteID6 => GenDevCashDispenserLib.StCassetteID6; 
    */

    public bool XPCduShutter
    {
        get { return GenDevCashDispenserLib.XPCduShutter; }
        set { GenDevCashDispenserLib.XPCduShutter = value; }
    }
    public string StExitSensor => GenDevCashDispenserLib.StExitSensor; 

    public GenDevCashDispenser()
    {
        _cduEventDeviceOpenedDelegate = new CDUEventDeviceOpenedDelegate(EventDeviceOpened);
        _cduEventDeviceClosedDelegate = new CDUEventDeviceClosedDelegate(EventDeviceClosed);
        _cduEventInitializeCompletedDelegate = new CDUEventInitializeCompletedDelegate(EventInitializeCompleted);
        _cduUEventGetCDUInfoCompletedDelegate = new CDUEventGetCDUInfoCompletedDelegate(EventGetCDUInfoCompleted);
        _cduEventSetCDUInfoCompletedDelegate = new CDUEventSetCDUInfoCompletedDelegate(EventSetCDUInfoCompleted);
        _cduEventStatusChangedDelegate = new CDUEventStatusChanged(EventStatusChanged);


        _cduEventDispenseProcessingDelegate = new CDUEventDispenseProcessingDelegate(EventDispenseProcessing);
        _cduEventDispenseFailedDelegate = new CDUEventDispenseFailedDelegate(EventDispenseFailed);
        _cduEventDispenseCompletedDelegate = new CDUEventDispenseCompletedDelegate(EventDispenseCompleted);
        _cduEventTestDispenseFailedDelegate = new CDUEventTestDispenseFailedDelegate(EventTestDispenseFailed);
        _cduEventTestDispenseCompletedDelegate = new CDUEventTestDispenseCompletedDelegate(EventTestDispenseCompleted);


        _cduEventDeviceErrorDelegate = new CDUEventDeviceErrorDelegate(EventDeviceError);
        _cduEventPresentCompletedDelegate = new CDUEventPresentCompletedDelegate(EventPresentCompleted);
        _cduEventShutterActionCompletedDelegate = new CDUEventShutterActionCompletedDelegate(EventShutterActionCompleted);
        _cduEventRetractCompletedDelegate = new CDUEventRetractCompletedDelegate(EventRetractCompleted);

        /*
        _cduEventDispenseExProcessingDelegate = new CDUEventDispenseExProcessingDelegate(EventDispenseExProcessing);
        _cduEventDispenseExFailedDelegate = new CDUEventDispenseExFailedDelegate(EventDispenseExFailed);
        _cduEventDispenseExCompletedDelegate = new CDUEventDispenseExCompletedDelegate(EventDispenseExCompleted);
        _cduEventTestDispenseExFailedDelegate = new CDUEventTestDispenseExFailedDelegate(EventTestDispenseExFailed);
        _cduEventTestDispenseExCompletedDelegate = new CDUEventTestDispenseExCompletedDelegate(EventTestDispenseExCompleted);
        _cduEventDenominationDispenseFailedDelegate = new CDUEventDenominationDispenseFailedDelegate(EventDenominationDispenseFailed);
        _cduEventDenominationDispenseCompletedDelegate = new CDUEventDenominationDispenseCompletedDelegate(CDUEventDenominationDispenseCompleted);
        */


        _cduEventExitPurgeCompletedDelegate = new CDUEventExitPurgeCompletedDelegate(EventExitPurgeCompleted);
        _cduEventDispenseGlobalProcessingDelegate = new CDUEventDispenseGlobalProcessingDelegate(EventDispenseGlobalProcessing);
        _cduEventDispenseGlobalFailedDelegate = new CDUEventDispenseGlobalFailedDelegate(EventDispenseGlobalFailed);
        _cduEventDispenseGlobalCompletedDelegate = new CDUEventDispenseGlobalCompletedDelegate(EventDispenseGlobalCompleted);
        _cduEventTestDispenseGlobalFailedDelegate = new CDUEventTestDispenseGlobalFailedDelegate(EventTestDispenseGlobalFailed);
        _cduEventTestDispenseGlobalCompletedDelegate = new CDUEventTestDispenseGlobalCompletedDelegate(EventTestDispenseGlobalCompleted);

        CDURegCallbackDeviceOpened(_cduEventDeviceOpenedDelegate);
        CDURegCallbackDeviceClosed(_cduEventDeviceClosedDelegate);
        CDURegCallbackInitializeCompleted(_cduEventInitializeCompletedDelegate);
        CDURegCallbackGetCDUInfoCompleted(_cduUEventGetCDUInfoCompletedDelegate);                       
        CDURegCallbackSetCDUInfoCompleted(_cduEventSetCDUInfoCompletedDelegate);                       
        CDURegCallbackStatusChanged(_cduEventStatusChangedDelegate);                                   
        CDURegCallbackDispenseProcessing(_cduEventDispenseProcessingDelegate );                         
        CDURegCallbackDispenseFailed(_cduEventDispenseFailedDelegate );                                 
        CDURegCallbackTestDispenseFailed(_cduEventTestDispenseFailedDelegate );                         
        CDURegCallbackTestDispenseCompleted(_cduEventTestDispenseCompletedDelegate );                   
        CDURegCallbackDispenseCompleted(_cduEventDispenseCompletedDelegate );                           
        CDURegCallbackDeviceError(_cduEventDeviceErrorDelegate );                                       
        CDURegCallbackPresentCompleted(_cduEventPresentCompletedDelegate );                             
        CDURegCallbackShutterActionCompleted(_cduEventShutterActionCompletedDelegate );                 
        CDURegCallbackRetractCompleted(_cduEventRetractCompletedDelegate );     

        /*
        CDURegCallbackDispenseExProcessing(_cduEventDispenseExProcessingDelegate );                     
        CDURegCallbackDispenseExFailed(_cduEventDispenseExFailedDelegate );                             
        CDURegCallbackTestDispenseExFailed(_cduEventTestDispenseExFailedDelegate );                     
        CDURegCallbackTestDispenseExCompleted(_cduEventTestDispenseExCompletedDelegate );               
        CDURegCallbackDispenseExCompleted(_cduEventDispenseExCompletedDelegate );    
        CDURegCallbackDenominationDispenseFailed(_cduEventDenominationDispenseFailedDelegate );         
        CDURegCallbackDenominationDispenseCompleted(_cduEventDenominationDispenseCompletedDelegate );   
        */

        CDURegCallbackExitPurgeCompleted(_cduEventExitPurgeCompletedDelegate );                         
        CDURegCallbackDispenseGlobalProcessing(_cduEventDispenseGlobalProcessingDelegate );             
        CDURegCallbackDispenseGlobalFailed(_cduEventDispenseGlobalFailedDelegate );                     
        CDURegCallbackTestDispenseGlobalFailed(_cduEventTestDispenseGlobalFailedDelegate );             
        CDURegCallbackTestDispenseGlobalCompleted(_cduEventTestDispenseGlobalCompletedDelegate );       
        CDURegCallbackDispenseGlobalCompleted(_cduEventDispenseGlobalCompletedDelegate );               
    }

    // Methods
    public void OpenDevice(string LicenseKey)
    {
        short retval = CDUOpenDevice(LicenseKey);
        if (retval != 0)
        {
            throw new CashDispenserException(retval);
        }
    }

    public void CloseDevice()
    {
        int retval = CDUCloseDevice();
        if (retval != 0)
        {
            throw new CashDispenserException(retval);
        }
    }

    public void Initialize(bool Force)
    {
        int retval = CDUInitializeDevice(Force);
        if (retval != 0)
        {
            throw new CashDispenserException(retval);
        }
    }

    public void GetCDUInformation()
    {
        int retval = CDUGetCDUInformation();
        if (retval != 0)
        {
            throw new CashDispenserException(retval);
        }
    }


    public void SetCDUInformation(string CountryCode, short CassetteCount, string CDUType)
    {
        int retval = CDUSetCDUInformation(CountryCode, CassetteCount, CDUType);
        if (retval != 0)
        {
            throw new CashDispenserException(retval);
        }
    }

    public void TestDispense(short ReqCount1,  short ReqCount2,  short ReqCount3,  short ReqCount4, short ReqCount5,  short ReqCount6)
    {
        int retval = CDUTestDispense(ReqCount1, ReqCount1, ReqCount3, ReqCount4, ReqCount5, ReqCount6);
        if (retval != 0)
        {
            throw new CashDispenserException(retval);
        }
    }

    public void Dispense(short ReqCount1,  short ReqCount2,  short ReqCount3,  short ReqCount4, short ReqCount5,  short ReqCount6)
    {
        int retval = CDUDispense(ReqCount1, ReqCount1, ReqCount3, ReqCount4 , ReqCount5, ReqCount6);
        if (retval != 0)
        {
            throw new CashDispenserException(retval);
        }
    }

    /*
    public void ClearDispensedInfo()
    {
        int retval = CDUClearDispensedInfo();
        if (retval != 0)
        {
            throw new CashDispenserException(retval);
        }
    }
    */

    public void Present()
    {
        int retval = CDUPresent();
        if (retval != 0)
        {
            throw new CashDispenserException(retval);
        }
    }


     public void ShutterAction(bool Open)
    {
        int retval = CDUShutterAction(Open);
        if (retval != 0)
        {
            throw new CashDispenserException(retval);
        }
    }

    public void Retract()
    {
        int retval = CDURetract();
        if (retval != 0)
        {
            throw new CashDispenserException(retval);
        }
    }

    /*
    public void TestDispenseEx(short ReqCount1,  short ReqCount2,  short ReqCount3,  short ReqCount4, short ReqCount5,  short ReqCount6)
    {
        int retval = CDUTestDispenseEx(ReqCount1, ReqCount1, ReqCount3, ReqCount4,  ReqCount5 , ReqCount6);
        if (retval != 0)
        {
            throw new CashDispenserException(retval);
        }
    }

    public void DispenseEx(short ReqCount1,  short ReqCount2,  short ReqCount3,  short ReqCount4, short ReqCount5,  short ReqCount6)
    {
        int retval = CDUDispenseEx(ReqCount1, ReqCount1, ReqCount3, ReqCount4,  ReqCount5 , ReqCount6);
        if (retval != 0)
        {
            throw new CashDispenserException(retval);
        }
    }
    */

    public void AssignCstDenomination(string Currency1,  short Denomination1, string Currency2,  short Denomination2,
		            string Currency3, short Denomination3, string Currency4,  short Denomination4,
		            string Currency5, short Denomination5, string Currency6,  short Denomination6)
    {
        int retval = CDUAssignCstDenomination(Currency1, Denomination1, Currency2, Denomination2, Currency3, Denomination3, 
                                              Currency4, Denomination4, Currency5, Denomination5, Currency6, Denomination6);
        if (retval != 0)
        {
            throw new CashDispenserException(retval);
        }
    }

    public void DenominationDispense( bool Present, string Currency1,  short Denomination1, short ReqCount1,
		            string Currency2,  short Denomination2,  short ReqCount2,
		            string Currency3,  short Denomination3,  short ReqCount3,
		            string Currency4,  short Denomination4,  short ReqCount4,
		            string Currency5,  short Denomination5,  short ReqCount5,
		            string Currency6,  short Denomination6,  short ReqCount6)
    {
        int retval = CDUDenominationDispense( Present, Currency1, Denomination1, ReqCount1,
		             Currency2, Denomination2, ReqCount2,
		             Currency3, Denomination3, ReqCount3,
		             Currency4, Denomination4, ReqCount4,
		             Currency5, Denomination5, ReqCount5,
		             Currency6, Denomination6, ReqCount6);
        if (retval != 0)
        {
            throw new CashDispenserException(retval);
        }
    }

    public void ExitPurge()
    {
        int retval = CDUExitPurge();
        if (retval != 0)
        {
            throw new CashDispenserException(retval);
        }
    }

    public void SetDenomRecognize(bool Enable)
    {
        int retval = CDUSetDenomRecognize(Enable);
        if (retval != 0)
        {
            throw new CashDispenserException(retval);
        }
    }

    public void TestDispenseGlobal(short reqcount1, short notelength1,
                            short reqcount2,  short notelength2,
                            short reqcount3,  short notelength3,
                            short reqcount4,  short notelength4,
                            short reqcount5,  short notelength5,
                            short reqcount6,  short notelength6)
    {
        int retval = CDUTestDispenseGlobal( reqcount1,  notelength1,
		        reqcount2,  notelength2, reqcount3,  notelength3,
		        reqcount4,  notelength4, reqcount5,  notelength5,
		        reqcount6,  notelength6);
        if (retval != 0)
        {
            throw new CashDispenserException(retval);
        }
    }

    public void DispenseGlobal(short reqcount1, short notelength1,
		 short reqcount2,  short notelength2,
		 short reqcount3,  short notelength3,
		 short reqcount4,  short notelength4,
		 short reqcount5,  short notelength5,
		 short reqcount6,  short notelength6)
    {
        int retval = CDUDispenseGlobal( reqcount1,  notelength1,
		  reqcount2,  notelength2, reqcount3,  notelength3,
		  reqcount4,  notelength4, reqcount5,  notelength5,
		  reqcount6,  notelength6);
        if (retval != 0)
        {
            throw new CashDispenserException(retval);
        }
    }


    // Events
    public event EventHandler<String>? OnDeviceOpened;
    public event EventHandler? OnDeviceClosed;
    public event EventHandler? OnInitialized;
    public event EventHandler<CDUInfo>? OnGetCDUInfoCompleted;
    public event EventHandler? OnSetCDUInfoCompleted;
    public event EventHandler<Status>? OnStatusChanged;
    public event EventHandler<DispenseCount>? OnDispenseProcessing;
    public event EventHandler<DispenseFailed>? OnDispenseFailed;
    public event EventHandler<DispenseCompleted>? OnDispenseCompleted;
    public event EventHandler<TestDispenseFailed>? OnTestDispenseFailed;
    public event EventHandler<TestDispenseCompleted>? OnTestDispenseCompleted;
    public event EventHandler<short>? OnDeviceError;
    public event EventHandler? OnPresentCompleted;
    public event EventHandler? OnShutterActionCompleted;
    public event EventHandler? OnRetractCompleted;

    /*
    public event EventHandler<DispenseExCount>? OnDispenseExProcessing;
    public event EventHandler<DispenseExFailed>? OnDispenseExFailed;
    public event EventHandler<DispenseExCompleted>? OnDispenseExCompleted;
    public event EventHandler<TestDispenseExFailed>? OnTestDispenseExFailed;
    public event EventHandler<TestDispenseExCompleted>? OnTestDispenseExCompleted;
    public event EventHandler<DenominationDispenseFailed>? OnDenominationDispenseFailed;
    public event EventHandler<DenominationDispenseCompleted>? OnDenominationDispenseCompleted;
    */

    public event EventHandler? OnExitPurgeCompleted;
    public event EventHandler<DispenseCount>? OnDispenseGlobalProcessing;
    public event EventHandler<DispenseGlobalFailed>? OnDispenseGlobalFailed;
    public event EventHandler<DispenseGlobalCompleted>? OnDispenseGlobalCompleted;
    public event EventHandler<TestDispenseGlobalFailed>? OnTestDispenseGlobalFailed;
    public event EventHandler<TestDispenseGlobalCompleted>? OnTestDispenseGlobalCompleted;

    // Processing callback
    private void EventDeviceOpened(IntPtr pObj, String portPath)
    {
        OnDeviceOpened?.Invoke(null, portPath);
    }

    private void EventDeviceClosed(IntPtr pObj)
    {
        OnDeviceClosed?.Invoke(null, new ());
    }

    private void EventInitializeCompleted(IntPtr pObj)
    {
        OnInitialized?.Invoke(null, new ());
    }

    private void EventGetCDUInfoCompleted(IntPtr pObj,String CountryCode, short CassetteNumber, String CDUType, String ManufactorType, String Version)
    {
        OnGetCDUInfoCompleted?.Invoke(null, new CDUInfo(CountryCode, CassetteNumber, CDUType, ManufactorType, Version));
    }

    private void EventSetCDUInfoCompleted(IntPtr pObj)
    {
        OnSetCDUInfoCompleted?.Invoke(null, new ());
    }

    private void EventStatusChanged(IntPtr pObj,String ChangedStatus, String PrevStatus, String CurrentStatus)
    {
        OnStatusChanged?.Invoke(null, new Status(ChangedStatus,PrevStatus, CurrentStatus));
    }

    private void EventDispenseProcessing(IntPtr pObj,short Count1, short Count2, short Count3, short Count4, short Count5, short Count6)
    {
        OnDispenseProcessing?.Invoke(null, new DispenseCount(Count1, Count2, Count3, Count4, Count5, Count6));
    }

    private void EventDispenseFailed(IntPtr pObj, short Reason, String DispensedCount,
                                       String DispensedInfo1, String DispensedInfo2,
                                       String DispensedInfo3, String DispensedInfo4,
                                       String DispensedInfo5, String DispensedInfo6)
    {
        OnDispenseFailed?.Invoke(null, new DispenseFailed(Reason, DispensedCount, DispensedInfo1, DispensedInfo2, DispensedInfo3, DispensedInfo4, DispensedInfo5, DispensedInfo6));
    }

     private void EventDispenseCompleted(IntPtr pObj, String DispensedCount,
                                       String DispensedInfo1, String DispensedInfo2,
                                       String DispensedInfo3, String DispensedInfo4,
                                       String DispensedInfo5, String DispensedInfo6)
    {
        OnDispenseCompleted?.Invoke(null, new DispenseCompleted(DispensedCount, DispensedInfo1, DispensedInfo2, DispensedInfo3, DispensedInfo4, DispensedInfo5, DispensedInfo6));
    }

    private void EventTestDispenseFailed(IntPtr pObj, short Reason,
                                       String DispensedInfo1, String DispensedInfo2,
                                       String DispensedInfo3, String DispensedInfo4,
                                       String DispensedInfo5, String DispensedInfo6)
    {
        OnTestDispenseFailed?.Invoke(null, new TestDispenseFailed(Reason, DispensedInfo1, DispensedInfo2, DispensedInfo3, DispensedInfo4, DispensedInfo5, DispensedInfo6));
    }

    private void EventTestDispenseCompleted(IntPtr pObj, String DispensedInfo1, String DispensedInfo2, String DispensedInfo3, 
                                            String DispensedInfo4,String DispensedInfo5, String DispensedInfo6)
    {
        OnTestDispenseCompleted?.Invoke(null, new TestDispenseCompleted(DispensedInfo1, DispensedInfo2, DispensedInfo3, DispensedInfo4, DispensedInfo5, DispensedInfo6));
    }

    private void EventDeviceError(IntPtr pObj, short Reason)
    {
        OnDeviceError?.Invoke(null, Reason);
    }

    private void EventPresentCompleted(IntPtr pObj)
    {
        OnPresentCompleted?.Invoke(null,new());
    }

    private void EventShutterActionCompleted(IntPtr pObj)
    {
        OnShutterActionCompleted?.Invoke(null,new());
    }

    private void EventRetractCompleted(IntPtr pObj)
    {
        OnRetractCompleted?.Invoke(null,new());
    }


    /*
    private void EventDispenseExProcessing(IntPtr pObj, short Count1, short Count2, short Count3,
                                             short Count4, short Count5, short Count6)
    {
        OnDispenseExProcessing?.Invoke(null,new DispenseExCount(Count1, Count2, Count3, Count4, Count5, Count6));
    }

    private void EventDispenseExFailed(IntPtr pObj, short Reason, String DispensedCount,
                                         String DispensedInfo1, String DispensedInfo2,
                                         String DispensedInfo3, String DispensedInfo4,
                                         String DispensedInfo5, String DispensedInfo6)
    {
        OnDispenseExFailed?.Invoke(null,new DispenseExFailed(Reason, DispensedCount, DispensedInfo1, DispensedInfo2, DispensedInfo3, DispensedInfo4, DispensedInfo5, DispensedInfo6));
    }

    private void EventDispenseExCompleted(IntPtr pObj, String DispensedCount,
                                         String DispensedInfo1, String DispensedInfo2,
                                         String DispensedInfo3, String DispensedInfo4,
                                         String DispensedInfo5, String DispensedInfo6)
    {
        OnDispenseExCompleted?.Invoke(null,new DispenseExCompleted(DispensedCount, DispensedInfo1, DispensedInfo2, DispensedInfo3, DispensedInfo4, DispensedInfo5, DispensedInfo6));
    }

    private void EventTestDispenseExFailed(IntPtr pObj,short Reason,
                                             String DispensedInfo1, String DispensedInfo2,
                                             String DispensedInfo3, String DispensedInfo4,
                                             String DispensedInfo5, String DispensedInfo6)
    {
        OnTestDispenseExFailed?.Invoke(null,new TestDispenseExFailed(Reason, DispensedInfo1, DispensedInfo2, DispensedInfo3, DispensedInfo4, DispensedInfo5,DispensedInfo6));
    }

     private void EventTestDispenseExCompleted(IntPtr pObj,String DispensedInfo1, String DispensedInfo2,
                                                String DispensedInfo3, String DispensedInfo4,
                                                String DispensedInfo5, String DispensedInfo6)
    {
        OnTestDispenseExCompleted?.Invoke(null, new TestDispenseExCompleted(DispensedInfo1, DispensedInfo2, DispensedInfo3, DispensedInfo4, DispensedInfo5,DispensedInfo6));
    }
    
    private void EventDenominationDispenseFailed(IntPtr pObj, short Reason, String DispensedCount,
                                         String DispensedInfo1, String DispensedInfo2,
                                         String DispensedInfo3, String DispensedInfo4,
                                         String DispensedInfo5, String DispensedInfo6)
    {
        OnDenominationDispenseFailed?.Invoke(null,new DenominationDispenseFailed(Reason, DispensedCount, DispensedInfo1, DispensedInfo2, DispensedInfo3, DispensedInfo4, DispensedInfo5, DispensedInfo6));
    }

    private void CDUEventDenominationDispenseCompleted(IntPtr pObj,String DispensedCount,
                                         String DispensedInfo1, String DispensedInfo2,
                                         String DispensedInfo3, String DispensedInfo4,
                                         String DispensedInfo5, String DispensedInfo6)
    {
        OnDenominationDispenseCompleted?.Invoke(null,new DenominationDispenseCompleted(DispensedCount, DispensedInfo1, DispensedInfo2, DispensedInfo3, DispensedInfo4, DispensedInfo5, DispensedInfo6));
    }
    */



    private void EventExitPurgeCompleted(IntPtr pObj)
    {
        OnExitPurgeCompleted?.Invoke(null,new());
    }

    private void EventDispenseGlobalProcessing(IntPtr pObj, short Count1, short Count2, short Count3,
                                                 short Count4, short Count5, short Count6)
    {
        OnDispenseGlobalProcessing?.Invoke(null,new DispenseCount(Count1, Count2, Count3, Count4, Count5, Count6));
    }

    private void EventDispenseGlobalFailed(IntPtr pObj,short Reason, String DispensedCount,
                                         String DispensedInfo1, String DispensedInfo2,
                                         String DispensedInfo3, String DispensedInfo4,
                                         String DispensedInfo5, String DispensedInfo6)
    {
        OnDispenseGlobalFailed?.Invoke(null, new DispenseGlobalFailed(Reason, DispensedCount, DispensedInfo1, DispensedInfo2, DispensedInfo3, DispensedInfo4, DispensedInfo5, DispensedInfo6));
    }

     private void EventDispenseGlobalCompleted(IntPtr pObj,String DispensedCount,
                                         String DispensedInfo1, String DispensedInfo2,
                                         String DispensedInfo3, String DispensedInfo4,
                                         String DispensedInfo5, String DispensedInfo6)
    {
        OnDispenseGlobalCompleted?.Invoke(null, new DispenseGlobalCompleted(DispensedCount, DispensedInfo1, DispensedInfo2, DispensedInfo3, DispensedInfo4, DispensedInfo5, DispensedInfo6));
    }

    private void EventTestDispenseGlobalFailed(IntPtr pObj, short Reason,
                                         String DispensedInfo1, String DispensedInfo2,
                                         String DispensedInfo3, String DispensedInfo4,
                                         String DispensedInfo5, String DispensedInfo6)
    {
        OnTestDispenseGlobalFailed?.Invoke(null, new TestDispenseGlobalFailed(Reason, DispensedInfo1, DispensedInfo2, DispensedInfo3, DispensedInfo4, DispensedInfo5, DispensedInfo6));
    }

    private void EventTestDispenseGlobalCompleted(IntPtr pObj,String DispensedInfo1, String DispensedInfo2,
                                                    String DispensedInfo3, String DispensedInfo4,
                                                    String DispensedInfo5, String DispensedInfo6)
    {
        OnTestDispenseGlobalCompleted?.Invoke(null, new TestDispenseGlobalCompleted(DispensedInfo1, DispensedInfo2,DispensedInfo2,DispensedInfo2,DispensedInfo2,DispensedInfo2));
    }
   

    //  Delegate can be deleted by Gabage collector if it pass as marshalling callback function.
    //  It need to keep reference to get callback function works.
    private readonly CDUEventDeviceOpenedDelegate _cduEventDeviceOpenedDelegate;
    private readonly CDUEventDeviceClosedDelegate _cduEventDeviceClosedDelegate;
    private readonly CDUEventInitializeCompletedDelegate _cduEventInitializeCompletedDelegate;
    private readonly CDUEventGetCDUInfoCompletedDelegate _cduUEventGetCDUInfoCompletedDelegate;
    private readonly CDUEventSetCDUInfoCompletedDelegate _cduEventSetCDUInfoCompletedDelegate;
    private readonly CDUEventStatusChanged _cduEventStatusChangedDelegate;
    private readonly CDUEventDispenseProcessingDelegate _cduEventDispenseProcessingDelegate;
    private readonly CDUEventDispenseFailedDelegate _cduEventDispenseFailedDelegate;
    private readonly CDUEventDispenseCompletedDelegate _cduEventDispenseCompletedDelegate;
    private readonly CDUEventTestDispenseFailedDelegate _cduEventTestDispenseFailedDelegate;
    private readonly CDUEventTestDispenseCompletedDelegate _cduEventTestDispenseCompletedDelegate;
    private readonly CDUEventDeviceErrorDelegate _cduEventDeviceErrorDelegate;
    private readonly CDUEventPresentCompletedDelegate _cduEventPresentCompletedDelegate;
    private readonly CDUEventShutterActionCompletedDelegate _cduEventShutterActionCompletedDelegate;
    private readonly CDUEventRetractCompletedDelegate _cduEventRetractCompletedDelegate;

    /*
    private readonly CDUEventDispenseExProcessingDelegate _cduEventDispenseExProcessingDelegate;
    private readonly CDUEventDispenseExFailedDelegate _cduEventDispenseExFailedDelegate;
    private readonly CDUEventDispenseExCompletedDelegate _cduEventDispenseExCompletedDelegate;
    private readonly CDUEventTestDispenseExFailedDelegate  _cduEventTestDispenseExFailedDelegate;
    private readonly CDUEventTestDispenseExCompletedDelegate _cduEventTestDispenseExCompletedDelegate;
    private readonly CDUEventDenominationDispenseFailedDelegate _cduEventDenominationDispenseFailedDelegate;
    private readonly CDUEventDenominationDispenseCompletedDelegate _cduEventDenominationDispenseCompletedDelegate;
    */

    private readonly CDUEventExitPurgeCompletedDelegate _cduEventExitPurgeCompletedDelegate;
    private readonly CDUEventDispenseGlobalProcessingDelegate _cduEventDispenseGlobalProcessingDelegate;
    private readonly CDUEventDispenseGlobalFailedDelegate _cduEventDispenseGlobalFailedDelegate;
    private readonly CDUEventDispenseGlobalCompletedDelegate _cduEventDispenseGlobalCompletedDelegate;
    private readonly CDUEventTestDispenseGlobalFailedDelegate _cduEventTestDispenseGlobalFailedDelegate;
    private readonly CDUEventTestDispenseGlobalCompletedDelegate _cduEventTestDispenseGlobalCompletedDelegate;    
}