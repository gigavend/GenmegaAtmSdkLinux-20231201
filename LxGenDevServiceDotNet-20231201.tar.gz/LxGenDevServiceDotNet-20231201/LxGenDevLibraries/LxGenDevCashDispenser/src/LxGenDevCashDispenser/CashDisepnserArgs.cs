
namespace LxGenDevCashDispenser;

public class CDUInfo
{
    public string? CountryCode {get;set;}
    public short CassetteNumber {get;set;}
    public string? CDUType{get;set;}
    public string? ManufactorType{get;set;}
    public string? Version{get;set;}

    public CDUInfo(string countryCode, short cassetteNumber, string cduType,  string manufactorType, string version)
    {
        CountryCode = countryCode;
        CassetteNumber = cassetteNumber;
        CDUType = cduType;
        ManufactorType = manufactorType;
        Version = version;
    }
}

public class Status
{
    public string? ChangedStatus {get;set;}
    public string? PrevStatus {get;set;}
    public string? CurrentStatus {get;set;}

    public Status(string changedStatus, string prevStatus, string currentStatus)
    {
        ChangedStatus = changedStatus;
        PrevStatus = prevStatus;
        CurrentStatus = currentStatus;
    }
}

public class DispenseCount
{
    public short Count1 {get;set;}
    public short Count2 {get;set;}
    public short Count3 {get;set;}
    public short Count4 {get;set;}
    public short Count5 {get;set;}
    public short Count6 {get;set;}

    public DispenseCount(short count1, short count2, short count3, short count4, short count5, short count6)
    {
        Count1 = count1;
        Count2 = count2;
        Count3 = count3;
        Count4 = count4;
        Count5 = count5;
        Count6 = count6;
    }
}

/*
public class DispenseExCount
{
    public short Count1 {get;set;}
    public short Count2 {get;set;}
    public short Count3 {get;set;}
    public short Count4 {get;set;}
    public short Count5 {get;set;}
    public short Count6 {get;set;}

    public DispenseExCount(short count1, short count2, short count3, short count4, short count5, short count6)
    {
        Count1 = count1;
        Count2 = count2;
        Count3 = count3;
        Count4 = count4;
        Count5 = count5;
        Count6 = count6;
    }
}
*/

public class DispenseFailed
{
    public short Reason {get;set;}
    public string? DispensedCount {get;set;}
    public string? DispensedInfo1 {get;set;}
    public string? DispensedInfo2 {get;set;}
    public string? DispensedInfo3 {get;set;}
    public string? DispensedInfo4 {get;set;}
    public string? DispensedInfo5 {get;set;}
    public string? DispensedInfo6 {get;set;}


    public DispenseFailed(short reason, string dispensedCount, string dispensedInfo1,  
                string dispensedInfo2,  string dispensedInfo3,  string dispensedInfo4,
                string dispensedInfo5, string dispensedInfo6)
    {
        Reason = reason;
        DispensedCount = dispensedCount;
        DispensedInfo1 = dispensedInfo1;
        DispensedInfo2 = dispensedInfo2;
        DispensedInfo3 = dispensedInfo3;
        DispensedInfo4 = dispensedInfo4;
        DispensedInfo5 = dispensedInfo5;
        DispensedInfo6 = dispensedInfo6;
    }
}


/*
public class DispenseExFailed
{
    public short Reason {get;set;}
    public string? DispensedCount {get;set;}
    public string? DispensedInfo1 {get;set;}
    public string? DispensedInfo2 {get;set;}
    public string? DispensedInfo3 {get;set;}
    public string? DispensedInfo4 {get;set;}
    public string? DispensedInfo5 {get;set;}
    public string? DispensedInfo6 {get;set;}

    public DispenseExFailed(short reason, string dispensedCount, string dispensedInfo1,  
                string dispensedInfo2,  string dispensedInfo3, string dispensedInfo4,
                string dispensedInfo5, string dispensedInfo6)
    {
        Reason = reason;
        DispensedCount = dispensedCount;
        DispensedInfo1 = dispensedInfo1;
        DispensedInfo2 = dispensedInfo2;
        DispensedInfo3 = dispensedInfo3;
        DispensedInfo4 = dispensedInfo4;
        DispensedInfo5 = dispensedInfo5;
        DispensedInfo6 = dispensedInfo6;
    }
}
*/

public class TestDispenseFailed
{
    public short Reason {get;set;}
    public string? DispensedInfo1 {get;set;}
    public string? DispensedInfo2 {get;set;}
    public string? DispensedInfo3 {get;set;}
    public string? DispensedInfo4 {get;set;}
    public string? DispensedInfo5 {get;set;}
    public string? DispensedInfo6 {get;set;}


    public TestDispenseFailed(short reason, string dispensedInfo1, string dispensedInfo2, string dispensedInfo3, string dispensedInfo4,
                                string dispensedInfo5, string dispensedInfo6)
    {
        Reason = reason;
        DispensedInfo1 = dispensedInfo1;
        DispensedInfo2 = dispensedInfo2;
        DispensedInfo3 = dispensedInfo3;
        DispensedInfo4 = dispensedInfo4;
        DispensedInfo5 = dispensedInfo5;
        DispensedInfo6 = dispensedInfo6;
    }
}


/*
public class TestDispenseExFailed
{
    public short Reason {get;set;}
    public string? DispensedInfo1 {get;set;}
    public string? DispensedInfo2 {get;set;}
    public string? DispensedInfo3 {get;set;}
    public string? DispensedInfo4 {get;set;}
    public string? DispensedInfo5 {get;set;}
    public string? DispensedInfo6 {get;set;}


    public TestDispenseExFailed(short reason, string dispensedInfo1, string dispensedInfo2, string dispensedInfo3, string dispensedInfo4,
                                string dispensedInfo5, string dispensedInfo6)
    {
        Reason = reason;
        DispensedInfo1 = dispensedInfo1;
        DispensedInfo2 = dispensedInfo2;
        DispensedInfo3 = dispensedInfo3;
        DispensedInfo4 = dispensedInfo4;
        DispensedInfo5 = dispensedInfo5;
        DispensedInfo6 = dispensedInfo6;
    }
}
*/

public class DenominationDispenseFailed
{
    public short Reason {get;set;}
    public string? DispensedCount {get;set;}
    public string? DispensedInfo1 {get;set;}
    public string? DispensedInfo2 {get;set;}
    public string? DispensedInfo3 {get;set;}
    public string? DispensedInfo4 {get;set;}
    public string? DispensedInfo5 {get;set;}
    public string? DispensedInfo6 {get;set;}

    public DenominationDispenseFailed(short reason, string dispensedCount, string dispensedInfo1,  
                string dispensedInfo2,  string dispensedInfo3, string dispensedInfo4,
                string dispensedInfo5, string dispensedInfo6)
    {
        Reason = reason;
        DispensedCount = dispensedCount;
        DispensedInfo1 = dispensedInfo1;
        DispensedInfo2 = dispensedInfo2;
        DispensedInfo3 = dispensedInfo3;
        DispensedInfo4 = dispensedInfo4;
        DispensedInfo5 = dispensedInfo5;
        DispensedInfo6 = dispensedInfo6;
    }
}

public class DispenseGlobalFailed
{
    public short Reason {get;set;}
    public string? DispensedCount {get;set;}
    public string? DispensedInfo1 {get;set;}
    public string? DispensedInfo2 {get;set;}
    public string? DispensedInfo3 {get;set;}
    public string? DispensedInfo4 {get;set;}
    public string? DispensedInfo5 {get;set;}
    public string? DispensedInfo6 {get;set;}

    public DispenseGlobalFailed(short reason, string dispensedCount, string dispensedInfo1,  
                string dispensedInfo2,  string dispensedInfo3, string dispensedInfo4,
                string dispensedInfo5, string dispensedInfo6)
    {
        Reason = reason;
        DispensedCount = dispensedCount;
        DispensedInfo1 = dispensedInfo1;
        DispensedInfo2 = dispensedInfo2;
        DispensedInfo3 = dispensedInfo3;
        DispensedInfo4 = dispensedInfo4;
        DispensedInfo5 = dispensedInfo5;
        DispensedInfo6 = dispensedInfo6;
    }
}

public class TestDispenseGlobalFailed
{
    public short Reason {get;set;}
    public string? DispensedInfo1 {get;set;}
    public string? DispensedInfo2 {get;set;}
    public string? DispensedInfo3 {get;set;}
    public string? DispensedInfo4 {get;set;}
    public string? DispensedInfo5 {get;set;}
    public string? DispensedInfo6 {get;set;}

    public TestDispenseGlobalFailed(short reason, string dispensedInfo1,  
                string dispensedInfo2, string dispensedInfo3, string dispensedInfo4,
                string dispensedInfo5, string dispensedInfo6)
    {
        Reason = reason;
        DispensedInfo1 = dispensedInfo1;
        DispensedInfo2 = dispensedInfo2;
        DispensedInfo3 = dispensedInfo3;
        DispensedInfo4 = dispensedInfo4;
        DispensedInfo5 = dispensedInfo5;
        DispensedInfo6 = dispensedInfo6;
    }
}

public class DispenseCompleted
{
    public string? DispensedCount {get;set;}
    public string? DispensedInfo1 {get;set;}
    public string? DispensedInfo2 {get;set;}
    public string? DispensedInfo3 {get;set;}
    public string? DispensedInfo4 {get;set;}
    public string? DispensedInfo5 {get;set;}
    public string? DispensedInfo6 {get;set;}

    public DispenseCompleted(string dispensedCount, string dispensedInfo1,  
                             string dispensedInfo2, string dispensedInfo3, string dispensedInfo4,
                             string dispensedInfo5, string dispensedInfo6)
    {
        DispensedCount = dispensedCount;
        DispensedInfo1 = dispensedInfo1;
        DispensedInfo2 = dispensedInfo2;
        DispensedInfo3 = dispensedInfo3;
        DispensedInfo4 = dispensedInfo4;
        DispensedInfo5 = dispensedInfo5;
        DispensedInfo6 = dispensedInfo6;
    }
}

public class TestDispenseCompleted
{
    public string? DispensedInfo1 {get;set;}
    public string? DispensedInfo2 {get;set;}
    public string? DispensedInfo3 {get;set;}
    public string? DispensedInfo4 {get;set;}
    public string? DispensedInfo5 {get;set;}
    public string? DispensedInfo6 {get;set;}

    public TestDispenseCompleted(string dispensedInfo1, string dispensedInfo2,  
                                 string dispensedInfo3, string dispensedInfo4,
                                 string dispensedInfo5, string dispensedInfo6)
    {
        DispensedInfo1 = dispensedInfo1;
        DispensedInfo2 = dispensedInfo2;
        DispensedInfo3 = dispensedInfo3;
        DispensedInfo4 = dispensedInfo4;
        DispensedInfo5 = dispensedInfo5;
        DispensedInfo6 = dispensedInfo6;
    }
}

/*
public class DispenseExCompleted
{
    public string? DispensedCount {get;set;}
    public string? DispensedInfo1 {get;set;}
    public string? DispensedInfo2 {get;set;}
    public string? DispensedInfo3 {get;set;}
    public string? DispensedInfo4 {get;set;}
    public string? DispensedInfo5 {get;set;}
    public string? DispensedInfo6 {get;set;}

    public DispenseExCompleted(string dispensedCount, string dispensedInfo1,  
                string dispensedInfo2, string dispensedInfo3, string dispensedInfo4,
                string dispensedInfo5, string dispensedInfo6)
    {
        DispensedCount = dispensedCount;
        DispensedInfo1 = dispensedInfo1;
        DispensedInfo2 = dispensedInfo2;
        DispensedInfo3 = dispensedInfo3;
        DispensedInfo4 = dispensedInfo4;
        DispensedInfo5 = dispensedInfo5;
        DispensedInfo6 = dispensedInfo6;
    }
}

public class TestDispenseExCompleted
{
    public string? DispensedInfo1 {get;set;}
    public string? DispensedInfo2 {get;set;}
    public string? DispensedInfo3 {get;set;}
    public string? DispensedInfo4 {get;set;}
    public string? DispensedInfo5 {get;set;}
    public string? DispensedInfo6 {get;set;}

    public TestDispenseExCompleted(string dispensedInfo1, string dispensedInfo2, 
                string dispensedInfo3, string dispensedInfo4,
                string dispensedInfo5, string dispensedInfo6)
    {
        DispensedInfo1 = dispensedInfo1;
        DispensedInfo2 = dispensedInfo2;
        DispensedInfo3 = dispensedInfo3;
        DispensedInfo4 = dispensedInfo4;
        DispensedInfo5 = dispensedInfo5;
        DispensedInfo6 = dispensedInfo6;
    }
}
*/


public class DenominationDispenseCompleted
{
    public string? DispensedCount {get;set;}
    public string? DispensedInfo1 {get;set;}
    public string? DispensedInfo2 {get;set;}
    public string? DispensedInfo3 {get;set;}
    public string? DispensedInfo4 {get;set;}
    public string? DispensedInfo5 {get;set;}
    public string? DispensedInfo6 {get;set;}

    public DenominationDispenseCompleted(string dispensedCount, string dispensedInfo1,  
                string dispensedInfo2, string dispensedInfo3, string dispensedInfo4,
                string dispensedInfo5, string dispensedInfo6)
    {
        DispensedCount = dispensedCount;
        DispensedInfo1 = dispensedInfo1;
        DispensedInfo2 = dispensedInfo2;
        DispensedInfo3 = dispensedInfo3;
        DispensedInfo4 = dispensedInfo4;
        DispensedInfo5 = dispensedInfo5;
        DispensedInfo6 = dispensedInfo6;
    }
}

public class DispenseGlobalCompleted
{
    public string? DispensedCount {get;set;}
    public string? DispensedInfo1 {get;set;}
    public string? DispensedInfo2 {get;set;}
    public string? DispensedInfo3 {get;set;}
    public string? DispensedInfo4 {get;set;}
    public string? DispensedInfo5 {get;set;}
    public string? DispensedInfo6 {get;set;}

    public DispenseGlobalCompleted(string dispensedCount, string dispensedInfo1,  
                string dispensedInfo2, string dispensedInfo3, string dispensedInfo4,
                string dispensedInfo5, string dispensedInfo6)
    {
        DispensedCount = dispensedCount;
        DispensedInfo1 = dispensedInfo1;
        DispensedInfo2 = dispensedInfo2;
        DispensedInfo3 = dispensedInfo3;
        DispensedInfo4 = dispensedInfo4;
        DispensedInfo5 = dispensedInfo5;
        DispensedInfo6 = dispensedInfo6;
    }
}

public class TestDispenseGlobalCompleted
{
    public string? DispensedInfo1 {get;set;}
    public string? DispensedInfo2 {get;set;}
    public string? DispensedInfo3 {get;set;}
    public string? DispensedInfo4 {get;set;}
    public string? DispensedInfo5 {get;set;}
    public string? DispensedInfo6 {get;set;}

    public TestDispenseGlobalCompleted(string dispensedInfo1,  string dispensedInfo2, string dispensedInfo3, 
                                    string dispensedInfo4,string dispensedInfo5, string dispensedInfo6)
    {
        DispensedInfo1 = dispensedInfo1;
        DispensedInfo2 = dispensedInfo2;
        DispensedInfo3 = dispensedInfo3;
        DispensedInfo4 = dispensedInfo4;
        DispensedInfo5 = dispensedInfo5;
        DispensedInfo6 = dispensedInfo6;
    }
}