using System;
using System.Linq;
using System.Threading.Tasks;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Platform.Storage;
using Avalonia.Threading;
using LxGenDevCashDispenser;

namespace LxGenDevCashDispenserSample;

public partial class MainWindow : Window
{
    GenDevCashDispenser _cashDispenser = new GenDevCashDispenser();
    public MainWindow()
    {
        InitializeComponent();

        ComboBoxPorts.ItemsSource = new String[] {"/dev/ttyS0","/dev/ttyS1","/dev/ttyS2","/dev/ttyS3","/dev/ttyS4","/dev/ttyS5", "/dev/ttyUSB0", "/dev/ttyUSB1" };
        ComboBoxPorts.SelectedIndex = 4; 

        TextSetCountryCode.Text = "U";
        TextSetCstCount.Text = "1";

        TextDispense1.Text = "4";
        TextDispense2.Text = "4";
        TextDispense3.Text = "4";
        TextDispense4.Text = "4";
        TextDispense5.Text = "4";
        TextDispense6.Text = "4";

    
        TextGlobalReqCnt1.Text = "4";
        TextGlobalReqCnt2.Text = "0";
        TextGlobalReqCnt3.Text = "0";
        TextGlobalReqCnt4.Text = "0";
        TextGlobalReqCnt5.Text = "0";
        TextGlobalReqCnt6.Text = "0";

        TextGlobalNoteLength1.Text = "66";
        TextGlobalNoteLength2.Text = "66";
        TextGlobalNoteLength3.Text = "66";
        TextGlobalNoteLength4.Text = "66";
        TextGlobalNoteLength5.Text = "66";
        TextGlobalNoteLength6.Text = "66";

        GetProperty();
        GetStatusInfo();

        Initialize();
    }

    public void Initialize()
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            CheckBoxTraceLog.IsChecked = _cashDispenser.TraceLog;
        });

        _cashDispenser.OnDeviceOpened += CDUOpened;
        _cashDispenser.OnDeviceClosed += CDUClosed;
        _cashDispenser.OnInitialized += CDUInitialized;
        _cashDispenser.OnPresentCompleted += CDUPresentCompleted;    
        _cashDispenser.OnShutterActionCompleted += CDUShutterActionCompleted;   
        _cashDispenser.OnExitPurgeCompleted +=  CDUExitPurgeCompleted;   
        _cashDispenser.OnRetractCompleted += CDURetractCompleted;   
        _cashDispenser.OnGetCDUInfoCompleted +=  GetCDUInfoCompleted;
        _cashDispenser.OnSetCDUInfoCompleted += SetCDUInfoCompleted;
        _cashDispenser.OnDispenseFailed +=  CDUDispenseFailed;
        _cashDispenser.OnDispenseCompleted += CDUDispenseCompleted;
        _cashDispenser.OnDispenseProcessing +=  CDUDispenseProcessing;
        _cashDispenser.OnTestDispenseCompleted +=  CDUTestDispenseCompleted;
        _cashDispenser.OnTestDispenseFailed +=  CDUTestDispenseFailed;
        _cashDispenser.OnStatusChanged += CDUStatusChanged;  
        _cashDispenser.OnDeviceError += CDUDeviceError;
        _cashDispenser.OnDispenseGlobalFailed += CDUDispenseGlobalFailed;    
        _cashDispenser.OnDispenseGlobalCompleted += CDUDispenseGlobalCompleted;
        _cashDispenser.OnDispenseGlobalProcessing +=  CDUDispenseGlobalProcessing;  
        _cashDispenser.OnTestDispenseGlobalCompleted +=  CDUDTestDispenseGlobalCompleted;  
        _cashDispenser.OnTestDispenseGlobalFailed += CDUTestDispenseGlobalFailed; 
    }

    public void CDUOpened(Object? sender, String portPath)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Device Opened: {portPath}";
        });

        GetProperty();
        GetStatusInfo();
    }

    private void CDUClosed(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Closed device";
        });

        GetStatusInfo();
    }

    private void CDUInitialized(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Device Initialized";
        });
    }

    private void CDUPresentCompleted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Device Presented";
        });
    }

    private void CDUShutterActionCompleted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Device ShutterAction Completed";
        });
    }

    //
    private void CDUExitPurgeCompleted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Device ExitPurge Completed";
        });
    }


     private void CDURetractCompleted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Device Retract Completed";
        });
    }



    private void GetCDUInfoCompleted(object? sender, CDUInfo e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"GetCDUInformation Completed";

            TextCountryCode.Text = e.CountryCode;
            TextCstCount.Text = e.CassetteNumber.ToString();
            TextCDUType.Text = e.CDUType;
        });

        GetProperty();
    }

    private void SetCDUInfoCompleted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"SetCDUInformation Completed";
        });

        GetProperty();
    }

    
    private void CDUDispenseFailed(object? sender, DispenseFailed e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Dispense Failed : {e.Reason}, DispensedCount : {e.DispensedCount}, Cst1 : {e.DispensedInfo1}, Cst2 : {e.DispensedInfo2}, Cst3 : {e.DispensedInfo3}, Cst4 : {e.DispensedInfo4}, Cst5 : {e.DispensedInfo5}, Cst6 : {e.DispensedInfo6}";
            TextBoxResult.Text = _cashDispenser.ErrorCode;
        });

        GetProperty();
    }

 
    
    private void CDUDispenseCompleted(object? sender, DispenseCompleted e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Dispense Completed. DispensedCount : {e.DispensedCount}, Cst1 : {e.DispensedInfo1}, Cst2 : {e.DispensedInfo2}, Cst3 : {e.DispensedInfo3}, Cst4 : {e.DispensedInfo4}, Cst5 : {e.DispensedInfo5}, Cst6 : {e.DispensedInfo6}";
        });

        GetProperty();
    }

    
   
    private void CDUDispenseProcessing(object? sender, DispenseCount e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Dispense Processing. Cst1 : {e.Count1}, Cst2 : {e.Count2}, Cst3 : {e.Count3}, Cst4 : {e.Count4} , Cst5 : {e.Count5}, Cst6 : {e.Count6}";
           
        });
        GetProperty();
    }

    
    
    private void CDUTestDispenseCompleted(object? sender, TestDispenseCompleted e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"TestDispense Completed. Cst1 : {e.DispensedInfo1}, Cst2 : {e.DispensedInfo2}, Cst3 : {e.DispensedInfo3}, Cst4 : {e.DispensedInfo4}, Cst5 : {e.DispensedInfo5}, Cst6 : {e.DispensedInfo6}";
        
        });
        GetProperty();
    }

   
    

    private void CDUTestDispenseFailed(object? sender, TestDispenseFailed e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"TestDispense Failed : {e.Reason}, Cst1 : {e.DispensedInfo1}, Cst2 : {e.DispensedInfo2}, Cst3 : {e.DispensedInfo3}, Cst4 : {e.DispensedInfo4}, Cst5 : {e.DispensedInfo5}, Cst6 : {e.DispensedInfo6}";
            TextBoxResult.Text = _cashDispenser.ErrorCode;

        });
        GetProperty();
    }

  

    private void CDUStatusChanged(object? sender, Status e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            //TextBoxEvent.Text = $"Status Changed";

        });

        GetProperty();
    }

    
    private void CDUDeviceError(object? sender, short e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Device Error: {e}";
            TextBoxResult.Text = _cashDispenser.ErrorCode;


        });

        GetProperty();
        GetStatusInfo();
    }

    private void CDUDenominationDispenseFailed(object? sender, DenominationDispenseFailed e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"DenominationDispense Failed: {e.Reason}, Cst1 : {e.DispensedInfo1}, Cst2 : {e.DispensedInfo2}, Cst3 : {e.DispensedInfo3}, Cst4 : {e.DispensedInfo4}, Cst5 : {e.DispensedInfo6}, Cst6 : {e.DispensedInfo6}";
            TextBoxResult.Text = _cashDispenser.ErrorCode;


        });

        GetProperty();
    }

    
    private void CDUDenominationDispenseCompleted(object? sender, DenominationDispenseCompleted e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"DenominationDispense Completed, Cst1 : {e.DispensedInfo1}, Cst2 : {e.DispensedInfo2}, Cst3 : {e.DispensedInfo3}, Cst4 : {e.DispensedInfo4}, Cst5 : {e.DispensedInfo6}, Cst6 : {e.DispensedInfo6}";
           

        });

        GetProperty();
    }


    private void CDUDispenseGlobalFailed(object? sender, DispenseGlobalFailed e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"DispenseGlobal Failed: {e.Reason}, Cst1 : {e.DispensedInfo1}, Cst2 : {e.DispensedInfo2}, Cst3 : {e.DispensedInfo3}, Cst4 : {e.DispensedInfo4}, Cst5 : {e.DispensedInfo6}, Cst6 : {e.DispensedInfo6}";
            TextBoxResult.Text = _cashDispenser.ErrorCode;
           

        });

        GetProperty();
    }

    
    private void CDUDispenseGlobalCompleted(object? sender, DispenseGlobalCompleted e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"DispenseGlobal Completed, Cst1 : {e.DispensedInfo1}, Cst2 : {e.DispensedInfo2}, Cst3 : {e.DispensedInfo3}, Cst4 : {e.DispensedInfo4}, Cst5 : {e.DispensedInfo6}, Cst6 : {e.DispensedInfo6}";
           

        });

        GetProperty();
    }

    
    private void CDUDispenseGlobalProcessing(object? sender, DispenseCount e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"DispenseGlobal Processing. Cst1 : {e.Count1}, Cst2 : {e.Count2}, Cst3 : {e.Count3}, Cst4 : {e.Count4}, Cst5 : {e.Count5}, Cst6 : {e.Count6}";
        });

        GetProperty();
    }

    
    private void CDUDTestDispenseGlobalCompleted(object? sender, TestDispenseGlobalCompleted e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"TestDispenseGlobal Completed. Cst1 : {e.DispensedInfo1}, Cst2 : {e.DispensedInfo2}, Cst3 : {e.DispensedInfo3}, Cst4 : {e.DispensedInfo4}, Cst5 : {e.DispensedInfo5}, Cst6 : {e.DispensedInfo6}";
           

        });

        GetProperty();
    }

    
    private void CDUTestDispenseGlobalFailed(object? sender, TestDispenseGlobalFailed e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"DispenseGlobal Failed: {e.Reason}, Cst1 : {e.DispensedInfo1}, Cst2 : {e.DispensedInfo2}, Cst3 : {e.DispensedInfo3}, Cst4 : {e.DispensedInfo4}, Cst5 : {e.DispensedInfo6}, Cst6 : {e.DispensedInfo6}";
            TextBoxResult.Text = _cashDispenser.ErrorCode;
           

        });

        GetProperty();
    }


    public void GetProperty()
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxVersion.Text = _cashDispenser.Version;
            TextBoxCountryCode.Text = _cashDispenser.CountryCode;
            TextBoxCStNumber.Text = _cashDispenser.CassetteNumber.ToString();
            TextBoxCDUType.Text = _cashDispenser.CDUType;
            TextBoxManuFactorType.Text = _cashDispenser.ManufactorType;

            /*
            TextBoxLastDispenseCnt.Text = _cashDispenser.LastDispensedCount;
            TextBoxLastDispensedInfo1.Text =_cashDispenser.LastDispensedInfo1;
            TextBoxLastDispensedInfo2.Text =_cashDispenser.LastDispensedInfo2;
            TextBoxLastDispensedInfo3.Text =_cashDispenser.LastDispensedInfo3;
            TextBoxLastDispensedInfo4.Text =_cashDispenser.LastDispensedInfo4;
            TextBoxLastDispensedInfo5.Text =_cashDispenser.LastDispensedInfo5;
            TextBoxLastDispensedInfo6.Text =_cashDispenser.LastDispensedInfo6;

            TextBoxCassetteId1.Text = _cashDispenser.StCassetteID1;
            TextBoxCassetteId2.Text = _cashDispenser.StCassetteID2;
            TextBoxCassetteId3.Text = _cashDispenser.StCassetteID3;
            TextBoxCassetteId4.Text = _cashDispenser.StCassetteID4;
            TextBoxCassetteId5.Text = _cashDispenser.StCassetteID5;
            TextBoxCassetteId6.Text = _cashDispenser.StCassetteID6;
            */

            CheckBoxTraceLog.IsChecked = _cashDispenser.TraceLog;
            CheckBoxEnableDispenseProcessEvent.IsChecked = _cashDispenser.EnableDispenseProcessingEvent;
            CheckBoxXPCUDShutter.IsChecked = _cashDispenser.XPCduShutter;
        });
    }

    public void GetStatusInfo()
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxStDevice.Text = _cashDispenser.StDevice;
            TextBoxTransporter.Text = _cashDispenser.StTransporter;
            TextBoxStExitSensor.Text = _cashDispenser.StExitSensor;
            TextBoxCassette.Text = _cashDispenser.StCassette;
            TextBoxStOutlet.Text = _cashDispenser.StCstOutlet;
        });
       
    }

    public void OnGetPropertyClick(object sender, RoutedEventArgs e)
    {
        try
        {
            GetProperty();
        }
        catch(Exception ex)
        {
            CashDispenserError(ex.Message);
        }
    }

    public void OnOpenClick(object sender, RoutedEventArgs e)
    {
        try
        {
            CashDispenserEventErrorClear();

            string LicenseKey = "";
            LicenseKey = TextBoxLicenseKey.Text ?? "";

            _cashDispenser.PortPath = ComboBoxPorts.SelectedValue?.ToString() ?? "/dev/ttyUSB0";
            _cashDispenser.OpenDevice(LicenseKey);
        }
        catch(Exception ex)
        {
            CashDispenserError(ex.Message);
        }
    }

    public void OnCloseClick(object sender, RoutedEventArgs e)
    {
        try
        {
            CashDispenserEventErrorClear();
            
            _cashDispenser.CloseDevice();
        }
        catch(Exception ex)
        {
            CashDispenserError(ex.Message);
        }
    }

     
    public void OnInitializeClick(object sender, RoutedEventArgs e)
    {
        try
        {
            CashDispenserEventErrorClear();

            bool force = CheckBoxInitializeForce.IsChecked ?? false;
            _cashDispenser.Initialize(force);
        }
        catch(Exception ex)
        {
            CashDispenserError(ex.Message);
        }
    }

    public void OnGetCDUInfoClick(object sender, RoutedEventArgs e)
    {
        try
        {
            CashDispenserEventErrorClear();

            _cashDispenser.GetCDUInformation();
        }
        catch(Exception ex)
        {
            CashDispenserError(ex.Message);
        }
    }

    
    public void OnSetCDUInfoClick(object sender, RoutedEventArgs e)
    {
        try
        {
            CashDispenserEventErrorClear();

            if(TextSetCountryCode.Text == null || TextSetCstCount.Text == null || TextBoxCDUType.Text == null)
                return;

            string CountryCode = TextSetCountryCode.Text;
            short CassetteCount = (short)int.Parse(TextSetCstCount.Text);
            string CDUType = TextBoxCDUType.Text;

            _cashDispenser.SetCDUInformation(CountryCode, CassetteCount, CDUType);
        }
        catch(Exception ex)
        {
            CashDispenserError(ex.Message);
        }
    }

    //
    public void OnDispenseClick(object sender, RoutedEventArgs e)
    {
        try
        {
            CashDispenserEventErrorClear();

            if(TextDispense1.Text == null || TextDispense2.Text == null || TextDispense3.Text == null || TextDispense4.Text == null || TextDispense5.Text == null || TextDispense6.Text == null)
                return;

            short ReqCount1 = (short)int.Parse(TextDispense1.Text);
            short ReqCount2 = (short)int.Parse(TextDispense2.Text);
            short ReqCount3 = (short)int.Parse(TextDispense3.Text);
            short ReqCount4 = (short)int.Parse(TextDispense4.Text);
            short ReqCount5 = (short)int.Parse(TextDispense5.Text);
            short ReqCount6 = (short)int.Parse(TextDispense6.Text);

            _cashDispenser.Dispense(ReqCount1, ReqCount2, ReqCount3, ReqCount4, ReqCount5, ReqCount6);
        }
        catch(Exception ex)
        {
            CashDispenserError(ex.Message);
        }
    }

    public void OnTestDispenseClick(object sender, RoutedEventArgs e)
    {
        try
        {
            CashDispenserEventErrorClear();

            if(TextDispense1.Text == null || TextDispense2.Text == null || TextDispense3.Text == null || TextDispense4.Text == null || TextDispense5.Text == null || TextDispense6.Text == null)
                return;

            short ReqCount1 = (short)int.Parse(TextDispense1.Text);
            short ReqCount2 = (short)int.Parse(TextDispense2.Text);
            short ReqCount3 = (short)int.Parse(TextDispense3.Text);
            short ReqCount4 = (short)int.Parse(TextDispense4.Text);
            short ReqCount5 = (short)int.Parse(TextDispense5.Text);
            short ReqCount6 = (short)int.Parse(TextDispense6.Text);

            _cashDispenser.TestDispense(ReqCount1, ReqCount2, ReqCount3, ReqCount4, ReqCount5, ReqCount6);
        }
        catch(Exception ex)
        {
            CashDispenserError(ex.Message);
        }
    }

    public void OnShutterActionClick(object sender, RoutedEventArgs e)
    {
        try
        {
            CashDispenserEventErrorClear();

            bool open = CheckBoxShutterOpen.IsChecked ?? false;
            _cashDispenser.ShutterAction(open);
        }
        catch(Exception ex)
        {
            CashDispenserError(ex.Message);
        }
    }

    public void OnPresentClick(object sender, RoutedEventArgs e)
    {
        try
        {
            CashDispenserEventErrorClear();

            _cashDispenser.Present();
        }
        catch(Exception ex)
        {
            CashDispenserError(ex.Message);
        }
    }

    public void OnRetractClick(object sender, RoutedEventArgs e)
    {
        try
        {
            CashDispenserEventErrorClear();

            _cashDispenser.Retract();
        }
        catch(Exception ex)
        {
            CashDispenserError(ex.Message);
        }
    }

   
    public void OnDispenseGlobalClick(object sender, RoutedEventArgs e)
    {
        try
        {
            CashDispenserEventErrorClear();

            short ReqCount1 = (short)int.Parse(TextGlobalReqCnt1.Text ?? "0"); 
            short ReqCount2 = (short)int.Parse(TextGlobalReqCnt2.Text ?? "0"); 
            short ReqCount3 = (short)int.Parse(TextGlobalReqCnt3.Text ?? "0"); 
            short ReqCount4 = (short)int.Parse(TextGlobalReqCnt4.Text ?? "0"); 
            short ReqCount5 = (short)int.Parse(TextGlobalReqCnt5.Text ?? "0"); 
            short ReqCount6 = (short)int.Parse(TextGlobalReqCnt6.Text ?? "0"); 

            short NoteLength1 = (short)int.Parse(TextGlobalNoteLength1.Text ?? "0"); 
            short NoteLength2 = (short)int.Parse(TextGlobalNoteLength2.Text ?? "0"); 
            short NoteLength3 = (short)int.Parse(TextGlobalNoteLength3.Text ?? "0"); 
            short NoteLength4 = (short)int.Parse(TextGlobalNoteLength4.Text ?? "0"); 
            short NoteLength5 = (short)int.Parse(TextGlobalNoteLength5.Text ?? "0"); 
            short NoteLength6 = (short)int.Parse(TextGlobalNoteLength6.Text ?? "0"); 

            _cashDispenser.DispenseGlobal(ReqCount1, NoteLength1, ReqCount2, NoteLength2, ReqCount3, NoteLength3,
                                        ReqCount4, NoteLength4, ReqCount5, NoteLength5, ReqCount6, NoteLength6 );
        }
        catch(Exception ex)
        {
            CashDispenserError(ex.Message);
        }
    }

     public void OnTestDispenseGlobalClick(object sender, RoutedEventArgs e)
    {
        try
        {
            CashDispenserEventErrorClear();

            short ReqCount1 = (short)int.Parse(TextGlobalReqCnt1.Text ?? "0"); 
            short ReqCount2 = (short)int.Parse(TextGlobalReqCnt2.Text ?? "0"); 
            short ReqCount3 = (short)int.Parse(TextGlobalReqCnt3.Text ?? "0"); 
            short ReqCount4 = (short)int.Parse(TextGlobalReqCnt4.Text ?? "0"); 
            short ReqCount5 = (short)int.Parse(TextGlobalReqCnt5.Text ?? "0"); 
            short ReqCount6 = (short)int.Parse(TextGlobalReqCnt6.Text ?? "0"); 

            short NoteLength1 = (short)int.Parse(TextGlobalNoteLength1.Text ?? "0"); 
            short NoteLength2 = (short)int.Parse(TextGlobalNoteLength2.Text ?? "0"); 
            short NoteLength3 = (short)int.Parse(TextGlobalNoteLength3.Text ?? "0"); 
            short NoteLength4 = (short)int.Parse(TextGlobalNoteLength4.Text ?? "0"); 
            short NoteLength5 = (short)int.Parse(TextGlobalNoteLength5.Text ?? "0"); 
            short NoteLength6 = (short)int.Parse(TextGlobalNoteLength6.Text ?? "0"); 

            _cashDispenser.TestDispenseGlobal(ReqCount1, NoteLength1, ReqCount2, NoteLength2, ReqCount3, NoteLength3,
                                        ReqCount4, NoteLength4, ReqCount5, NoteLength5, ReqCount6, NoteLength6 );
        }
        catch(Exception ex)
        {
            CashDispenserError(ex.Message);
        }
    }


    public void OnCheckTraceLog(object sender, RoutedEventArgs e)
    {
        _cashDispenser.TraceLog = CheckBoxTraceLog.IsChecked??false;
    }

    public void OnCheckEnableDispenseProcessEvent(object sender, RoutedEventArgs e)
    {
        _cashDispenser.EnableDispenseProcessingEvent = CheckBoxEnableDispenseProcessEvent.IsChecked??false;
    }

    public void OnCheckXPCUDShutter(object sender, RoutedEventArgs e)
    {
        _cashDispenser.XPCduShutter = CheckBoxXPCUDShutter.IsChecked??false;
    }

    void CashDispenserError(String errorMsg)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxResult.Text = errorMsg;
        });
    }

    void CashDispenserEventErrorClear()
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxResult.Text = "";
            TextBoxEvent.Text = "";
        });
    }

    
}
