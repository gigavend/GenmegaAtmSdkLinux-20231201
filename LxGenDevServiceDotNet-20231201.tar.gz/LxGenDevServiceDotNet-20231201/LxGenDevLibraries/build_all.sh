#!/bin/bash

dotnet publish LxGenDevAppManager/src/LxGenDevAppManager /p:PublishProfile=FolderProfile
dotnet publish LxGenDevBarcodeScanner/src/LxGenDevBarcodeScanner /p:PublishProfile=FolderProfile
dotnet publish LxGenDevBillAcceptor/src/LxGenDevBillAcceptor /p:PublishProfile=FolderProfile
dotnet publish LxGenDevCardReader/src/LxGenDevCardReader /p:PublishProfile=FolderProfile
dotnet publish LxGenDevCashDispenser/src/LxGenDevCashDispenser /p:PublishProfile=FolderProfile
dotnet publish LxGenDevCISCardReader/src/LxGenDevCISCardReader /p:PublishProfile=FolderProfile
dotnet publish LxGenDevEncryptingPinPad/src/LxGenDevEncryptingPinPad /p:PublishProfile=FolderProfile
dotnet publish LxGenDevIndicator/src/LxGenDevIndicator /p:PublishProfile=FolderProfile
dotnet publish LxGenDevReceiptPrinter/src/LxGenDevReceiptPrinter /p:PublishProfile=FolderProfile

