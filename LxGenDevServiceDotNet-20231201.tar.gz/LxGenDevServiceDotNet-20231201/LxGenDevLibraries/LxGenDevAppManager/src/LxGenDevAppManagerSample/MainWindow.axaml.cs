using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Platform.Storage;
using Avalonia.Threading;
using Avalonia.VisualTree;
using LxGenDevAppManager;

namespace LxGenDevAppManagerSample;

public partial class MainWindow : Window
{
    GenDevAppManager _appManager = new GenDevAppManager();

    public MainWindow()
    {
        InitializeComponent();

        radioAtmAP.IsChecked = true;
    }

    public void Initialize()
    {
        _appManager.OnChangedActiveApp +=  OnChangedActiveApp;
        _appManager.OnInitializedApp +=  OnInitializedApp;

    }

    private void OnChangedActiveApp(object? sender, ChangedActiveApp e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"AppMgrEventChangedActiveApp";
        });
    }

    private void OnInitializedApp(object? sender, InitializedApp e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"AppMgrEventChangedActiveApp";
        });
    }


     public void OnOKClick(object sender, RoutedEventArgs e)
    {
        try
        {
            bool isSelectSample = radioSample.IsChecked ?? false;


        }
        catch(Exception ex)
        {
            AppMgrError(ex.Message);
        }
    }

    void AppMgrError(String errorMsg)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxResult.Text = errorMsg;
        });
    }

    void AppMgrEventErrorClear()
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxResult.Text = "";
            TextBoxEvent.Text = "";
        });
    }
}
