﻿using System.Runtime.InteropServices;
using System.Text;

namespace LxGenDevAppManager;


internal static class GenDevAppManagerLib
{
    private const string LibraryName = "libLxGenDevAppManager.so";

    private delegate int GetStringPropertyDelegate(StringBuilder buffer, int bufferLenth);

    private static String GetStringProperty(GetStringPropertyDelegate getProperty)
    {
        int bufferSize = 1024; // Adjust the buffer size as needed
        StringBuilder buffer = new StringBuilder(bufferSize);
        getProperty(buffer, bufferSize);
        return buffer.ToString();
    }

    private delegate bool GetBool(string appId);


    /*
    //Events
    typedef void (*AppMgrEventChangedActiveApp)(void* pObj, bool bActive, const char* szAppid, const char* szMode, const char* szPreviousActiveAppid);
    typedef void (*AppMgrEventInitializedApp)(void* pObj, bool bSucceeded, const char* szAppid);

    void APPMGR_RegCallbackChangedActiveApp(AppMgrEventChangedActiveApp eventfunc);
    void APPMGR_RegCallbackInitializedApp(AppMgrEventInitializedApp eventfunc);
    */

    //Callback Delegates
    internal delegate void AppMgrEventChangedActiveAppDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.I1)] bool active, [MarshalAs(UnmanagedType.LPStr)] String appId, [MarshalAs(UnmanagedType.LPStr)] String mode, [MarshalAs(UnmanagedType.LPStr)] String spreviousActiveAppid);
    internal delegate void AppMgrEventInitializedAppDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.I1)] bool succeeded, [MarshalAs(UnmanagedType.LPStr)] String appId);

    //Raw Event
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void APPMGR_RegCallbackChangedActiveApp([MarshalAs(UnmanagedType.FunctionPtr)] AppMgrEventChangedActiveAppDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void APPMGR_RegCallbackInitializedApp([MarshalAs(UnmanagedType.FunctionPtr)] AppMgrEventInitializedAppDelegate func);


    /*
    //Properties
    void APPMGR_SetCduLicenseKey(IN const char* licensekey);
    int	APPMGR_GetCduLicenseKey(OUT char* pCduLicenseKey, IN int nMaxLength);
    */

    internal static string CduLicenseKey
    {
        get { return GetStringProperty(APPMGR_GetCduLicenseKey); }
        set { APPMGR_SetCduLicenseKey(value); }
    }
   

    //Raw Properties
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void APPMGR_SetCduLicenseKey([MarshalAs(UnmanagedType.LPStr)] string licensekey);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int APPMGR_GetCduLicenseKey(StringBuilder cduLicenseKey, int nMaxLength);


    //Methods
    /*
    bool APPMGR_RegisterApp(IN const char* appid, IN const char* appname);
    bool APPMGR_UnregisterApp(IN const char* appid);
    int	APPMGR_GetActivateAppid(OUT char* pActivateAppId, IN int nMaxLength);
    int APPMGR_GetRegisterAppCount();
    bool APPMGR_GetRegisterAppInfoByIndex(IN int idx, OUT char* appid, OUT char* appname);

    bool APPMGR_ActivateApp(IN const char* appid, IN const char* mode);
    void APPMGR_NotifyInactiveApp(IN const char* appid, IN const char* mode);
    void APPMGR_NotifyInitializedApp(IN bool succeeded, IN const char* appid);
    void APPMGR_SetAppResult(IN const char* appid, IN const char* retcode);
    int	APPMGR_GetAppResult(IN const char* appid, OUT char* pAppResult, IN int nMaxLength);
    */

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern bool APPMGR_RegisterApp([MarshalAs(UnmanagedType.LPStr)] string appid, [MarshalAs(UnmanagedType.LPStr)] string appName);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern bool APPMGR_UnregisterApp([MarshalAs(UnmanagedType.LPStr)] string appid);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int APPMGR_GetActivateAppid(StringBuilder pActivateAppId, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int APPMGR_GetRegisterAppCount();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern bool APPMGR_GetRegisterAppInfoByIndex(int idx, StringBuilder appid, StringBuilder appname);



    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern bool APPMGR_ActivateApp([MarshalAs(UnmanagedType.LPStr)] string appid, [MarshalAs(UnmanagedType.LPStr)] string mode);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void APPMGR_NotifyInactiveApp([MarshalAs(UnmanagedType.LPStr)] string appid, [MarshalAs(UnmanagedType.LPStr)] string mode);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void APPMGR_NotifyInitializedApp([MarshalAs(UnmanagedType.I1)] bool succeeded, [MarshalAs(UnmanagedType.LPStr)] string appid);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void APPMGR_SetAppResult([MarshalAs(UnmanagedType.LPStr)] string appid, [MarshalAs(UnmanagedType.LPStr)] string retcode);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int APPMGR_GetAppResult([MarshalAs(UnmanagedType.LPStr)] string  appid, StringBuilder appResult, int nMaxLength);

}
