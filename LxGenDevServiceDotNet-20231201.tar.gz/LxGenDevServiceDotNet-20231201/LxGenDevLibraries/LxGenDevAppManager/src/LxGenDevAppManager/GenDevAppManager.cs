﻿using System.Diagnostics;
using System.Net;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.VisualBasic.FileIO;
using static LxGenDevAppManager.GenDevAppManagerLib;

namespace LxGenDevAppManager;


public class GenDevAppManager
{

    public GenDevAppManager()
    {
         _appMgrEventChangedActiveAppDelegate = new AppMgrEventChangedActiveAppDelegate(EventAppMgrEventChangedActiveApp);
         _appMgrEventInitializedAppDelegate = new AppMgrEventInitializedAppDelegate(EventAppMgrEventInitializedApp);

        APPMGR_RegCallbackChangedActiveApp(_appMgrEventChangedActiveAppDelegate);
        APPMGR_RegCallbackInitializedApp(_appMgrEventInitializedAppDelegate);
    }

    // Methods
    public bool RegisterApp(string appId, string appName)
    {
        bool retval = APPMGR_RegisterApp(appId, appName);
        return retval;
    }

    public bool UnregisterApp(string appId)
    {
        bool retval = APPMGR_UnregisterApp(appId);
        return retval;
    }

    public string GetActivateAppId(string appId)
    {
        int maxLen = 1024;
        StringBuilder respData = new StringBuilder(maxLen);
        
        int retval = APPMGR_GetActivateAppid(respData, maxLen);
        if (retval < 0)
        {
            throw new AppMgrException(retval);
        }

        return respData.ToString();
    }

    public int GetRegisterAppCount()
    {
        int retval = APPMGR_GetRegisterAppCount();
        return retval;
    }

    public AppInfo? GetRegisterAppInfoByIndex(int index)
    {
        int maxLen = 1024;
        StringBuilder appId = new StringBuilder(maxLen);
        StringBuilder appName = new StringBuilder(maxLen);

        bool retval = APPMGR_GetRegisterAppInfoByIndex(index, appId, appName);

        if(retval == false)
            return null;

        return new AppInfo(appId.ToString(), appName.ToString());
    }

    public bool ActivateApp(string appId, string mode)
    {
        bool retval = APPMGR_ActivateApp(appId, mode);
        return retval;
    }

    public void NotifyInactiveApp(string appId, string mode)
    {
        APPMGR_NotifyInactiveApp(appId, mode);
    }

    public void NotifyInitializedApp(bool succeeded, string mode)
    {
        APPMGR_NotifyInitializedApp(succeeded, mode);
    }

    public void SetAppResult(string appId, string retcode)
    {
        APPMGR_SetAppResult(appId, retcode);
    }

    public string GetAppResult(string appId)
    {
        int maxLen = 1024;
        StringBuilder respData = new StringBuilder(maxLen);
        
        int retval = APPMGR_GetAppResult(appId, respData, maxLen);
        if (retval < 0)
        {
            throw new AppMgrException(retval);
        }

        return respData.ToString();
    }

     // Events
    public event EventHandler<ChangedActiveApp>? OnChangedActiveApp;
    public event EventHandler<InitializedApp>? OnInitializedApp;


    // Processing callback
    private void EventAppMgrEventChangedActiveApp(IntPtr pObj, bool active, string appId, string mode, string previousActiveAppid)
    {
        OnChangedActiveApp?.Invoke(null, new ChangedActiveApp(active, appId, mode, previousActiveAppid));
    }

    private void EventAppMgrEventInitializedApp(IntPtr pObj, bool succeed, string appId)
    {
        OnInitializedApp?.Invoke(null, new InitializedApp(succeed, appId));
    }


     // Delegate can be deleted by Gabage collector if it pass as marshalling callback function.
     // It need to keep reference to get callback function works.
     private readonly AppMgrEventChangedActiveAppDelegate _appMgrEventChangedActiveAppDelegate;
     private readonly AppMgrEventInitializedAppDelegate _appMgrEventInitializedAppDelegate;
}
