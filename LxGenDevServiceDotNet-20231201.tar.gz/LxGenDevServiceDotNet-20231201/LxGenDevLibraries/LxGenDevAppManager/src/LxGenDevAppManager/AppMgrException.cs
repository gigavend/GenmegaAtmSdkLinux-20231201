
namespace LxGenDevAppManager;

public class AppMgrException : Exception
{
    public int ErrorCode { get; internal set; }

    internal AppMgrException(int errorCode) : base($"Error Code : {errorCode}")
    {
        ErrorCode = errorCode;
    }
}
