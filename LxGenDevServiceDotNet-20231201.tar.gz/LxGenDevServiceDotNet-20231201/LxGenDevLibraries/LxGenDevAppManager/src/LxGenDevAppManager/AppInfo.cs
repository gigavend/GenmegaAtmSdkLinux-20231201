public class AppInfo
{
    public string AppId {get; set;}
    public string AppName {get; set;}

    internal AppInfo(string appId, string appName)
    {
        AppId = appId;
        AppName = appName;
    }
}