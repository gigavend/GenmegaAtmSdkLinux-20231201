namespace LxGenDevAppManager;

public class ChangedActiveApp
{
    public bool Active {get;set;}
    public string AppId {get;set;}
    public string Mode {get;set;}
    public string PreviousActiveAppId {get;set;}

    public ChangedActiveApp(bool active, string appId, string mode , string previousActiveAppId)
    {
        Active = active;
        AppId = appId;
        Mode = mode;
        PreviousActiveAppId = previousActiveAppId;
    }
}

public class InitializedApp
{
    public bool Succeeded {get;set;}
    public string AppId {get;set;}
  
    public InitializedApp(bool succeeded, string appid)
    {
        Succeeded = succeeded;
        AppId = appid;
    }
}