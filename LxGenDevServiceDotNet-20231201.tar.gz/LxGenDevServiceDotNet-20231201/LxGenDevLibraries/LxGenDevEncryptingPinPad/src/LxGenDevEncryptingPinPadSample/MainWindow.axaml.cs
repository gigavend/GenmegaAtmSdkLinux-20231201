using System;
using System.Linq;
using System.Threading.Tasks;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Platform.Storage;
using Avalonia.Threading;
using LxGenDevEncryptingPinPad;


namespace LxGenDevEncryptingPinPadSample;
public partial class MainWindow : Window
{
    GenDevEncryptingPinPad _eppPinPad = new GenDevEncryptingPinPad();

    public MainWindow()
    {
        InitializeComponent();

        ComboBoxPorts.ItemsSource = new String[] {"/dev/ttyS0","/dev/ttyS1","/dev/ttyS2","/dev/ttyS3","/dev/ttyS4","/dev/ttyS5", "/dev/ttyUSB0", "/dev/ttyUSB1" };
        ComboBoxPorts.SelectedIndex = 4; 

        ComboBoxDownloadKeyMode.ItemsSource = new String[] {"0" , "1", "2", "3", "4", "5", "6", "7"};
        ComboBoxDownloadKeyMode.SelectedIndex = 0;

        ComboBoxConfirmKeyMode.ItemsSource = new String[] {"0" , "1", "2", "3", "4", "5", "6", "7"};
        ComboBoxConfirmKeyMode.SelectedIndex = 0;

        ComboBoxGetActiveKeyMode.ItemsSource = new String[] {"0" , "1", "2", "3", "4", "5", "6", "7"};
        ComboBoxGetActiveKeyMode.SelectedIndex = 0;

        
        ComboBoxGetKeyStatusKeyMode.ItemsSource = new String[] {"0" , "1", "2", "3", "4", "5", "6", "7"};
        ComboBoxGetKeyStatusKeyMode.SelectedIndex = 0;

        ComboBoxSetKeyModeKeyMode.ItemsSource = new String[] {"0" , "1", "2", "3", "4", "5", "6", "7"};
        ComboBoxSetKeyModeKeyMode.SelectedIndex = 0;

        ComboBoxSetActiveKeyIndex.ItemsSource = new String[] {"0" , "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15"};
        ComboBoxSetActiveKeyIndex.SelectedIndex = 0;

        TextBoxKey1.Text = "81A414AF8A333BA0";
        TextBoxKey2.Text = "81A414AF8A333BA0";
        TextBoxKey3.Text = "81A414AF8A333BA0";
        TextBoxMacKey.Text = "81A414AF8A333BA0";
        TextBoxAccountNo.Text = "345674244616";
        TextBoxLeastLen.Text = "4";
        TextEncryptMac.Text = "0304005030303702BC";

        CheckBoxEnterKey.IsChecked = true;
        CheckBoxInputCtlEnable.IsChecked = false;

        Initialize();
    }

    public void Initialize()
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            CheckBoxTraceLog.IsDefault = _eppPinPad.TraceLog;
        });

        _eppPinPad.OnDeviceOpened += EPPOpened;
        _eppPinPad.OnDeviceClosed += EPPClosed;
        _eppPinPad.OnInitialized += EPPInitialized; 
        _eppPinPad.OnKeyPressed += EPPKeyPressed;
        _eppPinPad.OnKeyReleased += EPPKReleased;
        _eppPinPad.OnInputControlCompleted += EPPInputControlCompleted;  
        _eppPinPad.OnEncryptCanceled += EPPEncryptCanceled;
        _eppPinPad.OnEncryptStarted +=  EPPEncryptCStarted;
        _eppPinPad.OnGetKeyModeCompleted += EPPGetKeyModeCompleted;
        _eppPinPad.OnSetKeyModeCompleted += EPPSetKeyModeCompleted;
        _eppPinPad.OnSetActiveKeyCompleted += EPPSetActiveKeyCompleted; 
        _eppPinPad.OnDeviceError += EPPDeviceError;
        _eppPinPad.OnClearDataCompleted += EPPClearDataCompleted;
        _eppPinPad.OnConfirmKeyCompleted += EPPConfirmKeyCompleted;
        _eppPinPad.OnDownloadKeyCompleted +=  EPPDownloadKeyCompleted;
        _eppPinPad.OnGetKeyStatusCompleted +=  EPPGetKeyStatusCompleted; 
        _eppPinPad.OnGetActiveKeyCompleted +=  EPPGetActiveKeyCompleted;
        _eppPinPad.OnEncryptCompleted += EPPEncryptCompleted;  
       
    }

    public void EPPOpened(Object? sender, String portPath)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Device Opened: {portPath}";
            TextBlockVersion.Text = _eppPinPad.Version;
            TextBlockSerial.Text = _eppPinPad.SerialNumber;

            _eppPinPad.GetKeyMode();
        });
    }

    private void EPPClosed(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Closed device";
        });
    }

    private void EPPInitialized(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Initialize Completed";
        });
    }

    private void EPPKeyPressed(object? sender, string key)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"KEY PRESSED : {key}";
        });
    }

    private void EPPKReleased(object? sender, string key)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"KEY RELEASE : {key}";
        });
    }

    private void EPPInputControlCompleted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"InputControl Completed";
        });
    }

    private void EPPEncryptCanceled(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Encrypt Canceled";
        });
    }

     private void EPPEncryptCStarted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Encrypt Started";
        });
    }

    private void EPPGetKeyModeCompleted(object? sender, short keyMode)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"GetKeyMode Completed. keyMode : {keyMode}";

            ComboBoxGetActiveKeyMode.SelectedIndex = (int)keyMode;
            ComboBoxGetKeyStatusKeyMode.SelectedIndex = (int)keyMode;
        });
    }

    private void EPPSetKeyModeCompleted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"SetKeyMode Completed";
        });
    }

    private void EPPSetActiveKeyCompleted(object? sender, SetActiveKeyResult e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"SetActiveKey Completed. KeyIndex : {e.KeyIndex} , KeyCheck : {e.KeyCheck} , SerialPartA : {e.SerialPartA} , SerialPartB : {e.SerialPartB}";
        });
    }

    private void EPPDeviceError(object? sender, short e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Device Error: {e}";
        });
    }

    private void EPPClearDataCompleted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"ClearData Completed";
        });
    }


    private void EPPConfirmKeyCompleted(object? sender, CheckSum e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"ConfirmKey Completed. KeyCheck1 : {e.KeyCheck1}, KeyCheck2 : {e.KeyCheck2}, KeyCheck3 : {e.KeyCheck3}, MacCheck : {e.MacCheck}";
        });
    }
   
    private void EPPDownloadKeyCompleted(object? sender, CheckSum e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"DownloadKey Completed. KeyCheck1 : {e.KeyCheck1}, KeyCheck2 : {e.KeyCheck2}, KeyCheck3 : {e.KeyCheck3}, MacCheck : {e.MacCheck}";
        });
    }

    
    private void EPPGetKeyStatusCompleted(object? sender, KeyStatus e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"CheckSum : {e.CheckSum}, KeyStatus : {e.InjectStatus}";

            string[] CheckSum;
            string[] InjectStatus;
            
            if(e.CheckSum != null)
            {
                CheckSum = e.CheckSum.Split(',');

                if(CheckSum.Length == 16)
                {
                    
                    TestBlockCheckSum_0.Text = CheckSum[0];
                    TestBlockCheckSum_1.Text = CheckSum[1];
                    TestBlockCheckSum_2.Text = CheckSum[2];
                    TestBlockCheckSum_3.Text = CheckSum[3];
                    TestBlockCheckSum_4.Text = CheckSum[4];
                    TestBlockCheckSum_5.Text = CheckSum[5];
                    TestBlockCheckSum_6.Text = CheckSum[6];
                    TestBlockCheckSum_7.Text = CheckSum[7];
                    TestBlockCheckSum_8.Text = CheckSum[8];
                    TestBlockCheckSum_9.Text = CheckSum[9];
                    TestBlockCheckSum_10.Text = CheckSum[10];
                    TestBlockCheckSum_11.Text = CheckSum[11];
                    TestBlockCheckSum_12.Text = CheckSum[12];
                    TestBlockCheckSum_13.Text = CheckSum[13];
                    TestBlockCheckSum_14.Text = CheckSum[14];
                    TestBlockCheckSum_15.Text = CheckSum[15];
                    
                }
            }

            if(e.InjectStatus != null)
            {
                InjectStatus = e.InjectStatus.Split(',');

                if(InjectStatus.Length == 16)
                {
                    TestBlockKeyStatus_0.Text = InjectStatus[0];
                    TestBlockKeyStatus_1.Text = InjectStatus[1];
                    TestBlockKeyStatus_2.Text = InjectStatus[2];
                    TestBlockKeyStatus_3.Text = InjectStatus[3];
                    TestBlockKeyStatus_4.Text = InjectStatus[4];
                    TestBlockKeyStatus_5.Text = InjectStatus[5];
                    TestBlockKeyStatus_6.Text = InjectStatus[6];
                    TestBlockKeyStatus_7.Text = InjectStatus[7];
                    TestBlockKeyStatus_8.Text = InjectStatus[8];
                    TestBlockKeyStatus_9.Text = InjectStatus[9];
                    TestBlockKeyStatus_10.Text = InjectStatus[10];
                    TestBlockKeyStatus_11.Text = InjectStatus[11];
                    TestBlockKeyStatus_12.Text = InjectStatus[12];
                    TestBlockKeyStatus_13.Text = InjectStatus[13];
                    TestBlockKeyStatus_14.Text = InjectStatus[14];
                    TestBlockKeyStatus_15.Text = InjectStatus[15];
                }
            }
        });     
    }

    private void EPPGetActiveKeyCompleted(object? sender, GetActiveKeyResult e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"KeyIndex : {e.KeyIndex}, KeyCheck : {e.KeyCheck}, MacIndex : {e.MacIndex}, MacCheck : {e.MacCheck}, SerialPartA : {e.SerialPartA}, SerialPartB : {e.SerialPartB}";
        });
    }

    public void EPPEncryptCompleted(Object? sender, String encryptedPIN)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Encrypt Completed. EncryptedPIN : {encryptedPIN}";
        });
    }

    public void InjectKeyCompleted(Object? sender, String keyCheck)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"InjectKey Completed. CheckSum : {keyCheck}";
        });
    }

    private void EPPInjectKeyStarted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"InjectKey Started";
        });
    }

    private void EPPSetSecureModeCompleted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Set SecureMode Completed";
        });
    }

    private void EPPSetSecureModeStarted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Set SecureMode Started";
        });
    }

    public void EPPGetStatusCompleted(Object? sender, String status)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"GetStatus Completed. Status : {status}";
        });
    }

    private void EPPChangePasswordCompleted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"ChangePassword Completed";
        });
    }

    private void EPPChangePasswordStarted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"ChangePassword Started";
        });
    }

    private void EPPDownloadTRKeyCompleted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Download TRKey Completed";
        });
    }

    private void EPPAuthorizedMovingCompleted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Authorized Moving Completed";
        });
    }

    private void EPPAuthorizedFixingCompleted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Authorized Fixing Completed";
        });
    }
   


    public void OnCheckTraceLog(object sender, RoutedEventArgs e)
    {
        _eppPinPad.TraceLog = CheckBoxTraceLog.IsChecked??false;
    }


    public void OnOpenClick(object sender, RoutedEventArgs e)
    {
        try
        {
            EncryptingPinPadEventErrorClear();
            _eppPinPad.PortPath = ComboBoxPorts.SelectedValue?.ToString() ?? "/dev/ttyUSB0";
            _eppPinPad.OpenDevice();
        }
        catch(Exception ex)
        {
            EncryptingPinPadError(ex.Message);
        }
    }

    public void OnCloseClick(object sender, RoutedEventArgs e)
    {
        try
        {
            EncryptingPinPadEventErrorClear();
            _eppPinPad.CloseDevice();
        }
        catch(Exception ex)
        {
            EncryptingPinPadError(ex.Message);
        }
    }

    public void OnInitializeClick(object sender, RoutedEventArgs e)
    {
        try
        {
            EncryptingPinPadEventErrorClear();
            _eppPinPad.Initialize();
        }
        catch(Exception ex)
        {
            EncryptingPinPadError(ex.Message);
        }
    }

    
    public void OnClearAllDataClick(object sender, RoutedEventArgs e)
    {
        try
        {
            EncryptingPinPadEventErrorClear();
            _eppPinPad.ClearAllData();
        }
        catch(Exception ex)
        {
            EncryptingPinPadError(ex.Message);
        }
    }

    public void OnDonwloadKeyClick(object sender, RoutedEventArgs e)
    {
        try
        {
            EncryptingPinPadEventErrorClear();
            short keyMode = (short)ComboBoxDownloadKeyMode.SelectedIndex;
            string key1,key2,key3;
            string macKey;

            key1 = TextBoxKey1.Text ?? "";
            key2 = TextBoxKey2.Text ?? "";
            key3 = TextBoxKey3.Text ?? "";
            macKey = TextBoxMacKey.Text ?? "";

            _eppPinPad.EPPDownlaodKey(keyMode, key1, key2, key3, macKey);

        }
        catch(Exception ex)
        {
            EncryptingPinPadError(ex.Message);
        }
    }


    public void OnConfirmKeyValueClick(object sender, RoutedEventArgs e)
    {
        try
        {
            EncryptingPinPadEventErrorClear();
            short keyMode = (short)ComboBoxConfirmKeyMode.SelectedIndex;
            _eppPinPad.ConfirmKeyValue(keyMode);

        }
        catch(Exception ex)
        {
            EncryptingPinPadError(ex.Message);
        }
    }

    public void OnEncryptPinClick(object sender, RoutedEventArgs e)
    {
        try
        {
            EncryptingPinPadEventErrorClear();

            if(TextBoxLeastLen.Text == null || TextBoxAccountNo.Text == null)
                return;

            short LeastLen = (short)int.Parse(TextBoxLeastLen.Text);
            string Account = TextBoxAccountNo.Text;
            bool bEnterKey = CheckBoxEnterKey.IsChecked ?? false;
            
            _eppPinPad.EncryptPIN(Account, LeastLen,bEnterKey);

        }
        catch(Exception ex)
        {
            EncryptingPinPadError(ex.Message);
        }
    }


    public void OnEncryptByMacClick(object sender, RoutedEventArgs e)
    {
        try
        {
            EncryptingPinPadEventErrorClear();

            if(TextEncryptMac.Text == null )
                return;


            string data = TextEncryptMac.Text;
            int length = data.Length;
            
            _eppPinPad.EncryptByMac(data, length);

        }
        catch(Exception ex)
        {
            EncryptingPinPadError(ex.Message);
        }
    }

    public void OnGetActiveKeyClick(object sender, RoutedEventArgs e)
    {
        try
        {
            EncryptingPinPadEventErrorClear();

            short keyMode = (short)ComboBoxGetActiveKeyMode.SelectedIndex;
            _eppPinPad.GetActiveKey(keyMode);

        }
        catch(Exception ex)
        {
            EncryptingPinPadError(ex.Message);
        }
    }


    public void OnGetKeyStatusClick(object sender, RoutedEventArgs e)
    {
        try
        {
            EncryptingPinPadEventErrorClear();

            short keyMode = (short)ComboBoxGetKeyStatusKeyMode.SelectedIndex;
            _eppPinPad.GetKeyStatus(keyMode);

        }
        catch(Exception ex)
        {
            EncryptingPinPadError(ex.Message);
        }
    }

    
    public void OnGetKeyModeClick(object sender, RoutedEventArgs e)
    {
        try
        {
            EncryptingPinPadEventErrorClear();

            _eppPinPad.GetKeyMode();
        }
        catch(Exception ex)
        {
            EncryptingPinPadError(ex.Message);
        }
    }

    
    public void OnCancelEncryptPinClick(object sender, RoutedEventArgs e)
    {
        try
        {
            EncryptingPinPadEventErrorClear();

            _eppPinPad.CancelEncryptPIN();
        }
        catch(Exception ex)
        {
            EncryptingPinPadError(ex.Message);
        }
    }

    public void OnEndEncryptPinClick(object sender, RoutedEventArgs e)
    {
        try
        {
            EncryptingPinPadEventErrorClear();

            _eppPinPad.EndEncryptPIN();
        }
        catch(Exception ex)
        {
            EncryptingPinPadError(ex.Message);
        }
    }

    public void OnSetKeyModeClick(object sender, RoutedEventArgs e)
    {
        try
        {
            EncryptingPinPadEventErrorClear();

            short keyMode = (short)ComboBoxSetKeyModeKeyMode.SelectedIndex;
            _eppPinPad.SetKeyMode(keyMode);

        }
        catch(Exception ex)
        {
            EncryptingPinPadError(ex.Message);
        }
    }

    public void OnSetActiveKeyClick(object sender, RoutedEventArgs e)
    {
        try
        {
            EncryptingPinPadEventErrorClear();

            short keyIndex = (short)ComboBoxSetActiveKeyIndex.SelectedIndex;
            _eppPinPad.SetActiveKey(keyIndex);
        }
        catch(Exception ex)
        {
            EncryptingPinPadError(ex.Message);
        }
    }

    public void OnInputControlClick(object sender, RoutedEventArgs e)
    {
        try
        {
            EncryptingPinPadEventErrorClear();

            bool bEnable = CheckBoxInputCtlEnable.IsChecked ?? false;
            _eppPinPad.InputControl(bEnable);
        }
        catch(Exception ex)
        {
            EncryptingPinPadError(ex.Message);
        }
    }

    public void OnKeyManagementlick(object sender, RoutedEventArgs e)
    {
        try
        {
            EncryptingPinPadEventErrorClear();
            
            _eppPinPad.CallKeyManagementApp();
        }
        catch(Exception ex)
        {
            EncryptingPinPadError(ex.Message);
        }
    }


    void EncryptingPinPadError(String errorMsg)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxResult.Text = errorMsg;
        });
    }

    void EncryptingPinPadEventErrorClear()
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxResult.Text = "";
            TextBoxEvent.Text = "";
        });
    }
}
