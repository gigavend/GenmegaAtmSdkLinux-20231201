namespace LxGenDevEncryptingPinPad;

public class CheckSum
{
    public string? KeyCheck1 {get;set;}
    public string? KeyCheck2 {get;set;}
    public string? KeyCheck3 {get;set;}
    public string? MacCheck  {get;set;}

    public CheckSum(string keyCheck1, string keyCheck2, string keyCheck3, string macCheck)
    {
        KeyCheck1 = keyCheck1;
        KeyCheck2 = keyCheck2;
        KeyCheck3 = keyCheck3;
        MacCheck = macCheck;
    }
}

public class KeyStatus
{
    public string? CheckSum {get;set;}
    public string? InjectStatus {get;set;}
    
    public KeyStatus(string checkSum, string injectStatus)
    {
        CheckSum = checkSum;
        InjectStatus = injectStatus;
    }
}

public class GetActiveKeyResult
{
    public short KeyIndex {get;set;}
    public short MacIndex {get;set;}
    public string? KeyCheck {get;set;}
    public string? MacCheck {get;set;}
    public string? SerialPartA {get;set;}
    public string? SerialPartB {get;set;}

    public GetActiveKeyResult(short keyIndex, short macIndex , string keyCheck, string macCheck, string serialPartA, string serialPartB)
    {
        KeyIndex = keyIndex;
        MacIndex = macIndex;
        KeyCheck = keyCheck;
        MacCheck = macCheck;
        SerialPartA = serialPartA;
        SerialPartB = serialPartB;
    }
}

public class SetActiveKeyResult
{
    public short KeyIndex {get;set;}
    public string? KeyCheck {get;set;}
    public string? SerialPartA {get;set;}
    public string? SerialPartB {get;set;}

    public SetActiveKeyResult(short keyIndex , string keyCheck, string serialPartA, string serialPartB)
    {
        KeyIndex = keyIndex;
        KeyCheck = keyCheck;
        SerialPartA = serialPartA;
        SerialPartB = serialPartB;
    }

}