﻿using System.Diagnostics;
using System.Net;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.VisualBasic.FileIO;
using static LxGenDevEncryptingPinPad.GenDevEncryptingPinPadLib;

namespace LxGenDevEncryptingPinPad;

public class GenDevEncryptingPinPad
{
    // Properties
    public string PortPath
    {
        get { return GenDevEncryptingPinPadLib.PortPath; }
        set { GenDevEncryptingPinPadLib.PortPath = value; }
    }

    public int BaudRate
    {
        get { return GenDevEncryptingPinPadLib.BaudRate; }
        set { GenDevEncryptingPinPadLib.BaudRate = value; }
    }

    public int ByteSize
    {
        get { return GenDevEncryptingPinPadLib.ByteSize; }
        set { GenDevEncryptingPinPadLib.ByteSize = value; }
    }

    public int Parity
    {
        get { return GenDevEncryptingPinPadLib.Parity; }
        set { GenDevEncryptingPinPadLib.Parity = value; }
    }

    public int StopBits
    {
        get { return GenDevEncryptingPinPadLib.StopBits; }
        set { GenDevEncryptingPinPadLib.StopBits = value; }
    }

    public bool TraceLog
    {
        get { return GenDevEncryptingPinPadLib.TraceLog; }
        set { GenDevEncryptingPinPadLib.TraceLog = value; }
    }

    public String Version => GenDevEncryptingPinPadLib.Version;
    public String PCIVersion => GenDevEncryptingPinPadLib.PCIVersion;
    public String SerialNumber => GenDevEncryptingPinPadLib.SerialNumber;


    public GenDevEncryptingPinPad()
    {
        _eppEventDeviceOpenedDelegate = new EPPEventDeviceOpenedDelegate(EventDeviceOpened);
        _eppEventDeviceClosedDelegate = new EPPEventDeviceClosedDelegate(EventDeviceClosed);
        _eppEventInitializeCompletedDelegate = new EPPEventInitializeCompletedDelegate(EventInitializeCompleted);
        _eppEventKeyPressedDelegate = new EPPEventKeyPressedDelegate(EventKeyPressed);
        _eppEventKeyReleasedDelegate = new EPPEventKeyReleasedDelegate(EventKeyReleased);
        _eppEventEncryptCompletedDelegate = new EPPEventEncryptCompletedDelegate(EventEncryptCompleted);
        _eppEventClearDataCompletedDelegate = new EPPEventClearDataCompletedDelegate(EventClearDataCompleted);
        _eppEventDownloadKeyCompletedDelegate = new EPPEventDownloadKeyCompletedDelegate(EventDownloadKeyCompleted);
        _eppPEventConfirmKeyCompletedDelegate = new EEPPEventConfirmKeyCompletedDelegate(EventConfirmKeyCompleted);
        _eppEventEncryptCanceledDelegate = new EPPEventEncryptCanceledDelegate(EventEncryptCanceled);
        _eppEventEncryptStartedDelegate = new EPPEventEncryptStartedDelegate(EventEncryptStarted);
        _eppEventGetKeyStatusCompletedDelegate = new EPPEventGetKeyStatusCompletedDelegate(EventGetKeyStatusCompleted);
        _eppEventGetActiveKeyCompletedDelegate = new EPPEventGetActiveKeyCompletedDelegate(EventGetActiveKeyCompleted);
        _eppEventGetKeyModeCompletedDelegate = new EPPEventGetKeyModeCompletedDelegate(EventGetKeyModeCompleted);
        _eppEventDeviceErrorDelegate = new EPPEventDeviceErrorDelegate(EventDeviceError);
        _eppEventSetKeyModeCompletedDelegate = new EPPEventSetKeyModeCompletedDelegate(EventSetKeyModeCompleted);
        _eppEventSetActiveKeyCompletedDelegate = new EPPEventSetActiveKeyCompletedDelegate(EventSetKeyModeCompleted);
        _eppEventInputControlCompletedDelegate = new EPPEventInputControlCompletedDelegate(EventInputControlCompleted);

         /*
        _eppEventInjectKeyCompletedDelegate = new EPPEventInjectKeyCompletedDelegate(EPPEventInjectKeyCompleted);
        _eppEventInjectKeyStartedDelegate = new EPPEventInjectKeyStartedDelegate(EventInjectKeyStarted);
        _eppEventSetSecureModeCompletedDelegate = new EPPEventSetSecureModeCompletedDelegate(EventSetSecureModeCompleted);
        _eppEventSetSecureModeStartedDelegate = new EPPEventSetSecureModeStartedDelegate(EventSetSecureModeStarted);
        _eppEventGetStatusCompleteddDelegate = new EPPEventGetStatusCompleteddDelegate(EPPEventGetStatusCompleted);
        _eppEventChangePasswordCompletedDelegate = new EPPEventChangePasswordCompletedDelegate(EventChangePasswordCompleted);
        _eppEventChangePasswordStartedDelegate = new EPPEventChangePasswordStartedDelegate(EventChangePasswordStarted);
        _eppEventDownloadTRKeyCompletedDelegate = new EPPEventDownloadTRKeyCompletedDelegate(EventDownloadTRKeyCompleted);
        _eppEventAuthorizedMovingCompletedDelegate = new EPPEventAuthorizedMovingCompletedDelegate(EventAuthorizedMovingCompleted);
        _eppEventAuthorizedFixingCompletedDelegate = new EPPEventAuthorizedFixingCompletedDelegate(EventAuthorizedFixingCompleted);
        */

        EPPRegCallbackDeviceOpened(_eppEventDeviceOpenedDelegate);
        EPPRegCallbackDeviceClosed(_eppEventDeviceClosedDelegate);
        EPPRegCallbackInitializeCompleted(_eppEventInitializeCompletedDelegate);
        EPPRegCallbackKeyPressed(_eppEventKeyPressedDelegate);
        EPPRegCallbackKeyReleased(_eppEventKeyReleasedDelegate);
        EPPRegCallbackEncryptCompleted(_eppEventEncryptCompletedDelegate);
        EPPRegCallbackClearDataCompleted(_eppEventClearDataCompletedDelegate);
        EPPRegCallbackDownloadKeyCompleted(_eppEventDownloadKeyCompletedDelegate);
        EPPRegCallbackConfirmKeyCompleted(_eppPEventConfirmKeyCompletedDelegate);
        EPPRegCallbackEncryptCanceled(_eppEventEncryptCanceledDelegate);
        EPPRegCallbackEncryptStarted(_eppEventEncryptStartedDelegate);
        EPPRegCallbackGetKeyStatusCompleted(_eppEventGetKeyStatusCompletedDelegate);
        EPPRegCallbackGetActiveKeyCompleted(_eppEventGetActiveKeyCompletedDelegate);
        EPPRegCallbackGetKeyModeCompleted(_eppEventGetKeyModeCompletedDelegate);
        EPPRegCallbackDeviceError(_eppEventDeviceErrorDelegate);
        EPPRegCallbackSetKeyModeCompleted(_eppEventSetKeyModeCompletedDelegate);
        EPPRegCallbackSetActiveKeyCompleted(_eppEventSetActiveKeyCompletedDelegate);
        EPPRegCallbackInputControlCompleted(_eppEventInputControlCompletedDelegate);
    }

     // Methods
    public void OpenDevice()
    {
        short retval = EPPOpenDevice();
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }

    public void CloseDevice()
    {
        int retval = EPPCloseDevice();
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }

    public void Initialize()
    {
        int retval = EPPInitializeDevice();
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }

    public void EncryptPIN(string AccountNo, short LeastLen, bool EnterKey)
    {
        int retval = EPPEncryptPIN(AccountNo, LeastLen, EnterKey);
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }

    public void ClearAllData()
    {
        int retval = EPPClearAllData();
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }

   
    public void EncryptByMac(string AccountNo, long Len)
    {
        int retval = EPPEncryptByMac(AccountNo, Len);
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }

    public void EPPDownlaodKey(short KeyMode, string Key1, string Key2, string Key3, string MacKey)
    {
        int retval = EPPDownloadKey(KeyMode, Key1, Key2, Key3, MacKey);
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }

    public void ConfirmKeyValue(short KeyMode)
    {
        int retval = EPPConfirmKeyValue(KeyMode);
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }

    public void GetKeyStatus(short KeyMode)
    {
        int retval = EPPGetKeyStatus(KeyMode);
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }

    public void GetActiveKey(short KeyMode)
    {
        int retval = EPPGetActiveKey(KeyMode);
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }

    public void GetKeyMode()
    {
        int retval = EPPGetKeyMode();
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }

    public void CancelEncryptPIN()
    {
        int retval = EPPCancelEncryptPIN();
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }

    public void SetKeyMode(short KeyMode)
    {
        int retval = EPPSetKeyMode(KeyMode);
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }

    public void SetActiveKey(short KeyIndex)
    {
        int retval = EPPSetActiveKey(KeyIndex);
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }

    public void EndEncryptPIN()
    {
        int retval = EPPEndEncryptPIN();
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }

    public void CallKeyManagementApp()
    {
        int retval = EPPCallKeyManagementApp();
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }

    public void InputControl(bool Enable)
    {
        int retval = EPPInputControl(Enable);
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }

    /*
    public void InjectKey(short KeyMode, short KeyIndex, short InputPart, short InputType)
    {
        int retval = EPPInjectKey(KeyMode, KeyIndex, InputPart, InputType);
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }

    public void CheckSensitivePwd(short Part)
    {
        int retval = EPPCheckSensitivePwd(Part);
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }

    public void GetStatus()
    {
        int retval = EPPGetStatus();
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }

    public void ChangeSensitivePwd(short Part, short InputType)
    {
        int retval = EPPChangeSensitivePwd(Part, InputType);
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }

    public void DownloadTRKey(short InputPart, string TRKey)
    {
        int retval = EPPDownloadTRKey(InputPart, TRKey);
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }

    public void AuthorizedMoving(string Pwd, string UserID)
    {
        int retval = EPPAuthorizedMoving(Pwd, UserID);
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }

    public void AuthorizedFixing(string Pwd, string UserID)
    {
        int retval = EPPAuthorizedFixing(Pwd, UserID);
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }

    public void DownloadNPKey(string Key1, string Key2, string Key3)
    {
        int retval = EPPDownloadNPKey(Key1, Key2, Key3);
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }
    public void OpenPort()
    {
        int retval = EPPOpenPort();
        if (retval != 0)
        {
            throw new EncryptingPadException(retval);
        }
    }
    */

    // Events
    public event EventHandler<String>? OnDeviceOpened;
    public event EventHandler? OnDeviceClosed;
    public event EventHandler? OnInitialized;
    public event EventHandler<String>? OnKeyPressed;
    public event EventHandler<String>? OnKeyReleased;
    public event EventHandler<String>? OnEncryptCompleted;
    public event EventHandler? OnClearDataCompleted;
    public event EventHandler<CheckSum>? OnDownloadKeyCompleted;
    public event EventHandler<CheckSum>? OnConfirmKeyCompleted;
    public event EventHandler? OnEncryptCanceled;
    public event EventHandler? OnEncryptStarted;
    public event EventHandler<KeyStatus>? OnGetKeyStatusCompleted;
    public event EventHandler<GetActiveKeyResult>? OnGetActiveKeyCompleted;
    public event EventHandler<short>? OnGetKeyModeCompleted;
    public event EventHandler<short>? OnDeviceError;
    public event EventHandler? OnSetKeyModeCompleted;
    public event EventHandler<SetActiveKeyResult>? OnSetActiveKeyCompleted;
    public event EventHandler? OnInputControlCompleted;

    /*
    public event EventHandler<String>? OnInjectKeyCompleted;
    public event EventHandler? OnInjectKeyStarted;
    public event EventHandler? OnSetSecureModeCompleted;
    public event EventHandler? OnSetSecureModeStarted;
    public event EventHandler<String>? OnGetStatusCompleted;
    public event EventHandler? OnChangePasswordCompleted;
    public event EventHandler? OnChangePasswordStarted;
    public event EventHandler? OnDownloadTRKeyCompleted;
    public event EventHandler? OnAuthorizedMovingCompleted;
    public event EventHandler? OnAuthorizedFixingCompleted;
    */


    // Processing callback
    private void EventDeviceOpened(IntPtr pObj, String portPath)
    {
        OnDeviceOpened?.Invoke(null, portPath);
    }

    private void EventDeviceClosed(IntPtr pObj)
    {
        OnDeviceClosed?.Invoke(null, new ());
    }

    private void EventInitializeCompleted(IntPtr pObj)
    {
        OnInitialized?.Invoke(null, new ());
    }

    private void EventKeyPressed(IntPtr pObj, String key)
    {
        OnKeyPressed?.Invoke(null, key);
    }

    private void EventKeyReleased(IntPtr pObj, String key)
    {
        OnKeyReleased?.Invoke(null, key);
    }

    private void EventEncryptCompleted(IntPtr pObj, String encryptedPIN)
    {
        OnEncryptCompleted?.Invoke(null, encryptedPIN);
    }

    private void EventClearDataCompleted(IntPtr pObj)
    {
        OnClearDataCompleted?.Invoke(null, new ());
    }

    private void EventDownloadKeyCompleted(IntPtr pObj, String keyCheck1, String keyCheck2, String keyCheck3, String macCheck)
    {
        OnDownloadKeyCompleted?.Invoke(null, new CheckSum(keyCheck1, keyCheck2, keyCheck3, macCheck));
    }

    private void EventConfirmKeyCompleted(IntPtr pObj, String keyCheck1, String keyCheck2, String keyCheck3, String macCheck)
    {
        OnConfirmKeyCompleted?.Invoke(null, new CheckSum(keyCheck1, keyCheck2, keyCheck3, macCheck));
    }

    private void EventEncryptCanceled(IntPtr pObj)
    {
        OnEncryptCanceled?.Invoke(null, new ());
    }

    private void EventEncryptStarted(IntPtr pObj)
    {
        OnEncryptStarted?.Invoke(null, new ());
    }

    private void EventGetKeyStatusCompleted(IntPtr pObj, String checkSum, String keyInjectStatus)
    {
        OnGetKeyStatusCompleted?.Invoke(null, new KeyStatus(checkSum, keyInjectStatus));
    }

    private void EventGetActiveKeyCompleted(IntPtr pObj, short KeyIndex, string keyCheck, short macIndex, string macCheck, string serialPartA, string serialPartB)
    {
        OnGetActiveKeyCompleted?.Invoke(null, new GetActiveKeyResult(KeyIndex, macIndex, keyCheck, macCheck, serialPartA, serialPartB));
    }

    private void EventGetKeyModeCompleted(IntPtr pObj, short curKeyMode)
    {
        OnGetKeyModeCompleted?.Invoke(null, curKeyMode);
    }

    private void EventDeviceError(IntPtr pObj, short reason)
    {
        OnDeviceError?.Invoke(null, reason);
    }

    private void EventSetKeyModeCompleted(IntPtr pObj)
    {
        OnSetKeyModeCompleted?.Invoke(null, new ());
    }

    private void EventSetKeyModeCompleted(IntPtr pObj, short keyIndex,string keyCheck, string serialPartA, string serialPartB)
    {
        OnSetActiveKeyCompleted?.Invoke(null, new SetActiveKeyResult(keyIndex, keyCheck,serialPartA, serialPartB));
    }

    private void EventInputControlCompleted(IntPtr pObj)
    {
        OnInputControlCompleted?.Invoke(null, new ());
    }

    /*
    private void EPPEventInjectKeyCompleted(IntPtr pObj, String keyCheck)
    {
        OnInjectKeyCompleted?.Invoke(null, keyCheck);
    }

    private void EventInjectKeyStarted(IntPtr pObj)
    {
        OnInjectKeyStarted?.Invoke(null, new ());
    }

    private void EventSetSecureModeCompleted(IntPtr pObj)
    {
        OnSetSecureModeCompleted?.Invoke(null, new ());
    }

    private void EventSetSecureModeStarted(IntPtr pObj)
    {
        OnSetSecureModeStarted?.Invoke(null, new ());
    }

    private void EPPEventGetStatusCompleted(IntPtr pObj, string curStatus)
    {
        OnGetStatusCompleted?.Invoke(null, curStatus);
    }

    private void EventChangePasswordCompleted(IntPtr pObj)
    {
        OnChangePasswordCompleted?.Invoke(null, new ());
    }

    private void EventChangePasswordStarted(IntPtr pObj)
    {
        OnChangePasswordStarted?.Invoke(null, new ());
    }

    private void EventDownloadTRKeyCompleted(IntPtr pObj)
    {
        OnDownloadTRKeyCompleted?.Invoke(null, new ());
    }

    private void EventAuthorizedMovingCompleted(IntPtr pObj)
    {
        OnAuthorizedMovingCompleted?.Invoke(null, new ());
    }

    private void EventAuthorizedFixingCompleted(IntPtr pObj)
    {
        OnAuthorizedFixingCompleted?.Invoke(null, new ());
    }
    */



    //  Delegate can be deleted by Gabage collector if it pass as marshalling callback function.
    //  It need to keep reference to get callback function works.
     private readonly EPPEventDeviceOpenedDelegate _eppEventDeviceOpenedDelegate;
     private readonly EPPEventDeviceClosedDelegate _eppEventDeviceClosedDelegate;
     private readonly EPPEventInitializeCompletedDelegate _eppEventInitializeCompletedDelegate;
     private readonly EPPEventKeyPressedDelegate _eppEventKeyPressedDelegate;
     private readonly EPPEventKeyReleasedDelegate _eppEventKeyReleasedDelegate;
     private readonly EPPEventEncryptCompletedDelegate _eppEventEncryptCompletedDelegate;
     private readonly EPPEventClearDataCompletedDelegate _eppEventClearDataCompletedDelegate;
     private readonly EPPEventDownloadKeyCompletedDelegate _eppEventDownloadKeyCompletedDelegate;
     private readonly EEPPEventConfirmKeyCompletedDelegate _eppPEventConfirmKeyCompletedDelegate;
     private readonly EPPEventEncryptCanceledDelegate _eppEventEncryptCanceledDelegate;
     private readonly EPPEventEncryptStartedDelegate _eppEventEncryptStartedDelegate;
     private readonly EPPEventGetKeyStatusCompletedDelegate _eppEventGetKeyStatusCompletedDelegate;
     private readonly EPPEventGetActiveKeyCompletedDelegate _eppEventGetActiveKeyCompletedDelegate;
     private readonly EPPEventGetKeyModeCompletedDelegate _eppEventGetKeyModeCompletedDelegate;
     private readonly EPPEventDeviceErrorDelegate _eppEventDeviceErrorDelegate;
     private readonly EPPEventSetKeyModeCompletedDelegate _eppEventSetKeyModeCompletedDelegate;
     private readonly EPPEventSetActiveKeyCompletedDelegate _eppEventSetActiveKeyCompletedDelegate;
     private readonly EPPEventInputControlCompletedDelegate _eppEventInputControlCompletedDelegate;

     /*
     private readonly EPPEventInjectKeyCompletedDelegate _eppEventInjectKeyCompletedDelegate;
     private readonly EPPEventInjectKeyStartedDelegate _eppEventInjectKeyStartedDelegate;
     private readonly EPPEventSetSecureModeCompletedDelegate _eppEventSetSecureModeCompletedDelegate;
     private readonly EPPEventSetSecureModeStartedDelegate _eppEventSetSecureModeStartedDelegate;
     private readonly EPPEventGetStatusCompleteddDelegate _eppEventGetStatusCompleteddDelegate;
     private readonly EPPEventChangePasswordCompletedDelegate _eppEventChangePasswordCompletedDelegate;
     private readonly EPPEventChangePasswordStartedDelegate _eppEventChangePasswordStartedDelegate;
     private readonly EPPEventDownloadTRKeyCompletedDelegate _eppEventDownloadTRKeyCompletedDelegate;
    private readonly EPPEventAuthorizedMovingCompletedDelegate _eppEventAuthorizedMovingCompletedDelegate;
    private readonly EPPEventAuthorizedFixingCompletedDelegate _eppEventAuthorizedFixingCompletedDelegate;
    */

}
