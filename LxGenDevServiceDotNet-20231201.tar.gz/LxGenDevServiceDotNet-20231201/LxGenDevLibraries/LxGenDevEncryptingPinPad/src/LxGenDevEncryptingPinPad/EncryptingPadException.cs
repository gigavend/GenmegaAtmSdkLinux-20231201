namespace LxGenDevEncryptingPinPad;

public class EncryptingPadException : Exception
{
    public int ErrorCode { get; internal set; }

    internal EncryptingPadException(int errorCode) : base($"Error Code : {errorCode}")
    {
        ErrorCode = errorCode;
    }
}