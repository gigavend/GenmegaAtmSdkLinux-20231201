
using System.Runtime.InteropServices;
using System.Text;

namespace LxGenDevEncryptingPinPad;

internal static class GenDevEncryptingPinPadLib
{
    private const string LibraryName = "libLxGenDevEncryptingPinPad.so";

    private delegate int GetStringPropertyDelegate(StringBuilder buffer, int bufferLenth);

    private static String GetStringProperty(GetStringPropertyDelegate getProperty)
    {
        int bufferSize = 1024; // Adjust the buffer size as needed
        StringBuilder buffer = new StringBuilder(bufferSize);
        getProperty(buffer, bufferSize);
        return buffer.ToString();
    }

    /*
    typedef void (*EPPEventDeviceOpened)(void* pobj, const char* OpenedPortPath);
    typedef void (*EPPEventDeviceClosed)(void* pobj);
    typedef void (*EPPEventInitializeCompleted)(void* pobj);
    typedef void (*EPPEventKeyPressed)(void* pobj, const char* Key);
    typedef void (*EPPEventKeyReleased)(void* pobj, const char* Key);
    typedef void (*EPPEventEncryptCompleted)(void* pobj, const char* EncryptedPIN);
    typedef void (*EPPEventClearDataCompleted)(void* pobj);
    typedef void (*EPPEventDownloadKeyCompleted)(void* pobj, const char* KeyCheck1, const char* KeyCheck2, const char* KeyCheck3, const char* MacCheck);
    typedef void (*EPPEventConfirmKeyCompleted)(void* pobj, const char* KeyCheck1, const char* KeyCheck2, const char* KeyCheck3, const char* MacCheck);
    typedef void (*EPPEventEncryptCanceled)(void* pobj);
    typedef void (*EPPEventEncryptStarted)(void* pobj);
    typedef void (*EPPEventGetKeyStatusCompleted)(void* pobj, const char* CheckSum, const char* KeyInjectStatus);
    typedef void (*EPPEventGetActiveKeyCompleted)(void* pobj, short KeyIndex, const char* KeyCheck, short MacIndex, const char* MacCheck, const char* SerialPartA, const char* SerialPartB);
    typedef void (*EPPEventGetKeyModeCompleted)(void* pobj, short CurKeyMode);
    typedef void (*EPPEventDeviceError)(void* pobj, short Reason);
    typedef void (*EPPEventSetKeyModeCompleted)(void* pobj);
    typedef void (*EPPEventSetActiveKeyCompleted)(void* pobj, short KeyIndex, const char* KeyCheck, const char* SerialPartA, const char* SerialPartB);
    typedef void (*EPPEventInputControlCompleted)(void* pobj);
    typedef void (*EPPEventInjectKeyCompleted)(void* pobj, const char* KeyCheck);
    typedef void (*EPPEventInjectKeyStarted)(void* pobj);
    typedef void (*EPPEventSetSecureModeCompleted)(void* pobj);
    typedef void (*EPPEventSetSecureModeStarted)(void* pobj);
    typedef void (*EPPEventGetStatusCompleted)(void* pobj, const char* CurStatus);
    typedef void (*EPPEventChangePasswordCompleted)(void* pobj);
    typedef void (*EPPEventChangePasswordStarted)(void* pobj);
    typedef void (*EPPEventDownloadTRKeyCompleted)(void* pobj);
    typedef void (*EPPEventAuthorizedMovingCompleted)(void* pobj);
    typedef void (*EPPEventAuthorizedFixingCompleted)(void* pobj);

    void EPPRegCallbackDeviceOpened(EPPEventDeviceOpened eventfunc);
    void EPPRegCallbackDeviceClosed(EPPEventDeviceClosed eventfunc);
    void EPPRegCallbackInitializeCompleted(EPPEventInitializeCompleted eventfunc);
    void EPPRegCallbackKeyPressed(EPPEventKeyPressed eventfunc);
    void EPPRegCallbackKeyReleased(EPPEventKeyReleased eventfunc);
    void EPPRegCallbackEncryptCompleted(EPPEventEncryptCompleted eventfunc);
    void EPPRegCallbackClearDataCompleted(EPPEventClearDataCompleted eventfunc);
    void EPPRegCallbackDownloadKeyCompleted(EPPEventDownloadKeyCompleted eventfunc);
    void EPPRegCallbackConfirmKeyCompleted(EPPEventConfirmKeyCompleted eventfunc);
    void EPPRegCallbackEncryptCanceled(EPPEventEncryptCanceled eventfunc);
    void EPPRegCallbackEncryptStarted(EPPEventEncryptStarted eventfunc);
    void EPPRegCallbackGetKeyStatusCompleted(EPPEventGetKeyStatusCompleted eventfunc);
    void EPPRegCallbackGetActiveKeyCompleted(EPPEventGetActiveKeyCompleted eventfunc);
    void EPPRegCallbackGetKeyModeCompleted(EPPEventGetKeyModeCompleted eventfunc);
    void EPPRegCallbackDeviceError(EPPEventDeviceError eventfunc);
    void EPPRegCallbackSetKeyModeCompleted(EPPEventSetKeyModeCompleted eventfunc);
    void EPPRegCallbackSetActiveKeyCompleted(EPPEventSetActiveKeyCompleted eventfunc);
    void EPPRegCallbackInputControlCompleted(EPPEventInputControlCompleted eventfunc);
    void EPPRegCallbackInjectKeyCompleted(EPPEventInjectKeyCompleted eventfunc);
    void EPPRegCallbackInjectKeyStarted(EPPEventInjectKeyStarted eventfunc);
    void EPPRegCallbackSetSecureModeCompleted(EPPEventSetSecureModeCompleted eventfunc);
    void EPPRegCallbackSetSecureModeStarted(EPPEventSetSecureModeStarted eventfunc);
    void EPPRegCallbackGetStatusCompleted(EPPEventGetStatusCompleted eventfunc);
    void EPPRegCallbackChangePasswordCompleted(EPPEventChangePasswordCompleted eventfunc);
    void EPPRegCallbackChangePasswordStarted(EPPEventChangePasswordStarted eventfunc);
    void EPPRegCallbackDownloadTRKeyCompleted(EPPEventDownloadTRKeyCompleted eventfunc);
    void EPPRegCallbackAuthorizedMovingCompleted(EPPEventAuthorizedMovingCompleted eventfunc);
    void EPPRegCallbackAuthorizedFixingCompleted(EPPEventAuthorizedFixingCompleted eventfunc);
    */

    //Callback Delegates
    internal delegate void EPPEventDeviceOpenedDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String portPath);
    internal delegate void EPPEventDeviceClosedDelegate(IntPtr pObj);
    internal delegate void EPPEventInitializeCompletedDelegate(IntPtr pObj);
    internal delegate void EPPEventKeyPressedDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String key);
    internal delegate void EPPEventKeyReleasedDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String key);
    internal delegate void EPPEventEncryptCompletedDelegate(IntPtr pOb, [MarshalAs(UnmanagedType.LPStr)] String encryptedPIN);
    internal delegate void EPPEventClearDataCompletedDelegate(IntPtr pObj);
    internal delegate void EPPEventDownloadKeyCompletedDelegate(IntPtr pObj, 
                                                [MarshalAs(UnmanagedType.LPStr)] String keyCheck1,
                                                [MarshalAs(UnmanagedType.LPStr)] String keyCheck2,
                                                [MarshalAs(UnmanagedType.LPStr)] String keyCheck3,
                                                [MarshalAs(UnmanagedType.LPStr)] String macCheck);

    internal delegate void EEPPEventConfirmKeyCompletedDelegate(IntPtr pObj, 
                                                [MarshalAs(UnmanagedType.LPStr)] String keyCheck1,
                                                [MarshalAs(UnmanagedType.LPStr)] String keyCheck2,
                                                [MarshalAs(UnmanagedType.LPStr)] String keyCheck3,
                                                [MarshalAs(UnmanagedType.LPStr)] String macCheck);

    internal delegate void EPPEventEncryptCanceledDelegate(IntPtr pObj);
    internal delegate void EPPEventEncryptStartedDelegate(IntPtr pObj);
    internal delegate void EPPEventGetKeyStatusCompletedDelegate(IntPtr pObj, 
                                                [MarshalAs(UnmanagedType.LPStr)] String charheckSum,
                                                [MarshalAs(UnmanagedType.LPStr)] String keyInjectStatus);

    internal delegate void EPPEventGetActiveKeyCompletedDelegate(IntPtr pObj, 
                                                short keyIndex,
                                                [MarshalAs(UnmanagedType.LPStr)] String keyCheck,
                                                short macIndex,
                                                [MarshalAs(UnmanagedType.LPStr)] String macCheck,
                                                [MarshalAs(UnmanagedType.LPStr)] String serialPartA,
                                                [MarshalAs(UnmanagedType.LPStr)] String serialPartB);

    internal delegate void EPPEventGetKeyModeCompletedDelegate(IntPtr pObj, short curKeyMode);
    internal delegate void EPPEventDeviceErrorDelegate(IntPtr pObj, short reason);
    internal delegate void EPPEventSetKeyModeCompletedDelegate(IntPtr pObj);
    internal delegate void EPPEventSetActiveKeyCompletedDelegate(IntPtr pObj, 
                                                short keyIndex,
                                                [MarshalAs(UnmanagedType.LPStr)] String keyCheck,
                                                [MarshalAs(UnmanagedType.LPStr)] String serialPartA,
                                                [MarshalAs(UnmanagedType.LPStr)] String serialPartB);
    internal delegate void EPPEventInputControlCompletedDelegate(IntPtr pObj);


    /*
    internal delegate void EPPEventInjectKeyCompletedDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String keyCheck);
    internal delegate void EPPEventInjectKeyStartedDelegate(IntPtr pObj);
    internal delegate void EPPEventSetSecureModeCompletedDelegate(IntPtr pObj);
    internal delegate void EPPEventSetSecureModeStartedDelegate(IntPtr pObj);
    internal delegate void EPPEventGetStatusCompleteddDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String curStatus);
    internal delegate void EPPEventChangePasswordCompletedDelegate(IntPtr pObj);
    internal delegate void EPPEventChangePasswordStartedDelegate(IntPtr pObj);
    internal delegate void EPPEventDownloadTRKeyCompletedDelegate(IntPtr pObj);
    internal delegate void EPPEventAuthorizedMovingCompletedDelegate(IntPtr pObj);
    internal delegate void EPPEventAuthorizedFixingCompletedDelegate(IntPtr pObj);
    */

     //Raw Event
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackDeviceOpened([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventDeviceOpenedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackDeviceClosed([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventDeviceClosedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackInitializeCompleted([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventInitializeCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackKeyPressed([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventKeyPressedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackKeyReleased([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventKeyReleasedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackEncryptCompleted([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventEncryptCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackClearDataCompleted([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventClearDataCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackDownloadKeyCompleted([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventDownloadKeyCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackConfirmKeyCompleted([MarshalAs(UnmanagedType.FunctionPtr)] EEPPEventConfirmKeyCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackEncryptCanceled([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventEncryptCanceledDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackEncryptStarted([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventEncryptStartedDelegate func);
    
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackGetKeyStatusCompleted([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventGetKeyStatusCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackGetActiveKeyCompleted([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventGetActiveKeyCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackGetKeyModeCompleted([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventGetKeyModeCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackDeviceError([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventDeviceErrorDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackSetKeyModeCompleted([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventSetKeyModeCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackSetActiveKeyCompleted([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventSetActiveKeyCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackInputControlCompleted([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventInputControlCompletedDelegate func);



    /*
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackInjectKeyCompleted([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventInjectKeyCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackInjectKeyStarted([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventInjectKeyStartedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackSetSecureModeCompleted([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventSetSecureModeCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackSetSecureModeStarted([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventSetSecureModeStartedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackGetStatusCompleted([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventGetStatusCompleteddDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackChangePasswordCompleted([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventChangePasswordCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackChangePasswordStarted([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventChangePasswordStartedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackDownloadTRKeyCompleted([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventDownloadTRKeyCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackAuthorizedMovingCompleted([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventAuthorizedMovingCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPRegCallbackAuthorizedFixingCompleted([MarshalAs(UnmanagedType.FunctionPtr)] EPPEventAuthorizedFixingCompletedDelegate func);
    */

    /*
    //Properties
    int EPPGetPortPath(char* pPortPath, int nMaxLength);
    void EPPSetPortPath(const char* lpszNewValue);
    int EPPGetBaudRate();
    void EPPSetBaudRate(int nNewValue);
    short EPPGetByteSize();
    void EPPSetByteSize(short nNewValue);
    short EPPGetParity();
    void EPPSetParity(short nNewValue);
    short EPPGetStopBits();
    void EPPSetStopBits(short nNewValue);
    bool EPPGetTraceLog();
    void EPPSetTraceLog(bool bNewValue);
    int EPPGetVersion(char* pVersion, int nMaxLength);
    int EPPGetPCIVersion(char* pPCIVersion, int nMaxLength);
    int EPPGetSerialNumber(char* pSerialNumber, int nMaxLength);
    */

    internal static string PortPath
    {
        get { return GetStringProperty(EPPGetPortPath); }
        set { EPPSetPortPath(value); }
    }

    internal static int BaudRate
    {
        get { return EPPGetBaudRate(); }
        set { EPPSetBaudRate(value); }
    }

    internal static int ByteSize
    {
        get { return EPPGetByteSize(); }
        set { EPPSetByteSize((short)value); }
    }

    internal static int Parity
    {
        get { return EPPGetParity(); }
        set { EPPSetParity((short)value); }
    }

    internal static int StopBits
    {
        get { return EPPGetStopBits(); }
        set { EPPSetStopBits((short)value); }
    }

    internal static bool TraceLog
    {
        get { return EPPGetTraceLog(); }
        set { EPPSetTraceLog(value); }
    }

    internal static String Version
    {
        get { return GetStringProperty(EPPGetVersion); }
    }

    internal static String PCIVersion
    {
        get { return GetStringProperty(EPPGetPCIVersion); }
    }

    internal static String SerialNumber
    {
        get { return GetStringProperty(EPPGetSerialNumber); }
    }

    // Raw Properties
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int EPPGetPortPath(StringBuilder pPortPath, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPSetPortPath([MarshalAs(UnmanagedType.LPStr)] string str);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int EPPGetBaudRate();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPSetBaudRate(int baudrate);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPGetByteSize();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPSetByteSize(short byteSize);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPGetParity();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPSetParity(short parity);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPGetStopBits();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPSetStopBits(short stopBits);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern bool EPPGetTraceLog();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void EPPSetTraceLog([MarshalAs(UnmanagedType.I1)] bool traceLog);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int EPPGetVersion(StringBuilder version, int length);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int EPPGetPCIVersion(StringBuilder version, int length);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int EPPGetSerialNumber(StringBuilder version, int length);


    //Methods
    /*
    short EPPOpenDevice();
    short EPPCloseDevice();
    short EPPInitializeDevice();
    short EPPEncryptPIN(const char* AccountNo, short LeastLen, bool EnterKey);
    short EPPClearAllData();
    short EPPEncryptByMac(const char* Data, long Len);
    short EPPDownloadKey(short KeyMode, const char* Key1, const char* Key2, const char* Key3, const char* MacKey);
    short EPPConfirmKeyValue(short KeyMode);
    short EPPGetKeyStatus(short KeyMode);
    short EPPGetActiveKey(short KeyMode);
    short EPPGetKeyMode();
    short EPPCancelEncryptPIN();
    short EPPSetKeyMode(short KeyMode);
    short EPPSetActiveKey(short KeyIndex);
    short EPPEndEncryptPIN();
    short EPPCallKeyManagementApp();
    short EPPInputControl(bool bEnable);
    short EPPInjectKey(short KeyMode, short KeyIndex, short InputPart, short InputType);
    short EPPCheckSensitivePwd(short Part);
    short EPPGetStatus(void);
    short EPPChangeSensitivePwd(short Part, short InputType);
    short EPPDownloadTRKey(short InputPart, const char* TRKey);
    short EPPAuthorizedMoving(const char* Pwd, const char* UserID);
    short EPPAuthorizedFixing(const char* Pwd, const char* UserID);
    short EPPDownloadNPKey(const char* Key1, const char* Key2, const char* Key3);
    short EPPOpenPort(void);
    */

     // Raw Methods
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPOpenDevice();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPCloseDevice();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPInitializeDevice();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPEncryptPIN([MarshalAs(UnmanagedType.LPStr)] string accountNo, short leastLen, [MarshalAs(UnmanagedType.I1)] bool enterKey);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPClearAllData();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPEncryptByMac([MarshalAs(UnmanagedType.LPStr)] string data, long len);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPDownloadKey(short keyMode, [MarshalAs(UnmanagedType.LPStr)] string key1, [MarshalAs(UnmanagedType.LPStr)] string key2, [MarshalAs(UnmanagedType.LPStr)] string key3, [MarshalAs(UnmanagedType.LPStr)] string macKey);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPConfirmKeyValue(short keyMode);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPGetKeyStatus(short keyMode);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPGetActiveKey(short keyMode);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPGetKeyMode();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPCancelEncryptPIN();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPSetKeyMode(short keyMode);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPSetActiveKey(short keyIndex);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPEndEncryptPIN();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPCallKeyManagementApp();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPInputControl([MarshalAs(UnmanagedType.I1)] bool enable);

    /*
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPInjectKey(short keyMode, short keyIndex, short inputPart, short inputType);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPCheckSensitivePwd(short inputType);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPGetStatus();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPChangeSensitivePwd(short part, short inputType);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPDownloadTRKey(short inputPart, [MarshalAs(UnmanagedType.LPStr)] string trKey);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPAuthorizedMoving([MarshalAs(UnmanagedType.LPStr)] string pwd, [MarshalAs(UnmanagedType.LPStr)] string userID);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPAuthorizedFixing([MarshalAs(UnmanagedType.LPStr)] string pwd, [MarshalAs(UnmanagedType.LPStr)] string userID);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPDownloadNPKey([MarshalAs(UnmanagedType.LPStr)] string key1, [MarshalAs(UnmanagedType.LPStr)] string key2, [MarshalAs(UnmanagedType.LPStr)] string key3);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short EPPOpenPort();
    */
}