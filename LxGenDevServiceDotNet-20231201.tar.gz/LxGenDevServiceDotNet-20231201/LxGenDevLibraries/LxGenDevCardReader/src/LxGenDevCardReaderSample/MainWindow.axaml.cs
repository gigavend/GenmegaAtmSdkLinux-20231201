using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Platform.Storage;
using Avalonia.Threading;
using LxGenDevCardReader;

namespace LxGenDevCardReaderSample;

public partial class MainWindow : Window
{
    GenDevCardReader _cardReader = new GenDevCardReader();
    public MainWindow()
    {
            InitializeComponent();

            ComboBoxPorts.ItemsSource = new String[] {"/dev/ttyS0","/dev/ttyS1","/dev/ttyS2","/dev/ttyS3","/dev/ttyS4","/dev/ttyS5", "/dev/ttyUSB0", "/dev/ttyUSB1" };
            ComboBoxPorts.SelectedIndex = 4; // Kiosk default is COM5

            ComboBoxMCRType.ItemsSource = new String[] { "STANDARD","EMV" };
            ComboBoxMCRType.SelectedIndex = 0; // # inches printer for Kiosk has 115200.

            TextBoxAcceptCardTimeout.Text = "-1";
            TextBoxAcceptEMVCardTimeout.Text = "-1";
            TextBoxChipIO.Text = "00A404000E315041592E5359532E444446303100";

            Initialize();
    }

    public void Initialize()
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            CheckBoxTraceLog.IsDefault = _cardReader.TraceLog;
        });

        _cardReader.OnDeviceOpened += CardReaderOpened;
        _cardReader.OnDeviceClosed += CardReaderClosed;
        _cardReader.OnDeviceError += CardReaderDeviceError;
        _cardReader.OnCardReadCompleted +=  CardReadCompleted;   
        _cardReader.OnCardReadError +=  CardReadError;
        _cardReader.OnCardPresented += CardPresented;
        _cardReader.OnCardNotPresented +=  CardNotPresented;
        _cardReader.OnAcceptCardCanceled += AcceptCardCanceled;
        _cardReader.OnChipResetCompleted += ChipResetCompleted;
        _cardReader.OnChipResetError += ChipResetError;
        _cardReader.OnEjectCardCompleted += EjectCardCompleted;
        _cardReader.OnPowerResetCompleted +=  PowerResetCompleted;  
    }

    public void CardReaderOpened(Object? sender, String portPath)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Device Opened: {portPath}";
            TextBlockVersion.Text = _cardReader.Version;
        });

        ClearTrackText();
    }

    private void CardReaderClosed(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Closed device";
        });

        ClearTrackText();
    }

    private void CardReaderDeviceError(object? sender, int e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Device Error: {e}";
        });
    }

    private void CardReadCompleted(object? sender, CardReaderTrack track)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"CardReader Completed";

            TextBoxTrack1.Text = track.Track1;
            TextBoxTrack2.Text = track.Track2;
            TextBoxTrack3.Text = track.Track3;
        });
    }

    private void CardReadError(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Card ReadError";
        });
    }

    private void CardPresented(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Card Presented";
        });
    }

    private void CardNotPresented(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Card Not Presented";
        });
    }

    private void AcceptCardCanceled(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"AcceptCard Canceled";
        });
    }

    private void ChipResetCompleted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"ChipReset Completed";
        });
    }

    private void ChipResetError(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"ChipReset Error";
        });
    }

    private void EjectCardCompleted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Eject Card Completed";
        });
    }

    private void PowerResetCompleted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Power Reset Completed";
        });
    }


    public void OnCheckTraceLog(object sender, RoutedEventArgs e)
    {
        _cardReader.TraceLog = CheckBoxTraceLog.IsChecked??false;
    }

    public void OnOpenClick(object sender, RoutedEventArgs e)
    {
        try
        {
            _cardReader.PortPath = ComboBoxPorts.SelectedValue?.ToString() ?? "/dev/ttyUSB0";
            //_cardReader.BaudRate = int.Parse(ComboBoxBaudRate.SelectedValue?.ToString() ?? "115200");
            if(ComboBoxMCRType.SelectedIndex == 0)
                _cardReader.BaudRate = 9600;
            else
                _cardReader.BaudRate = 19200;

            _cardReader.MCRType = ComboBoxMCRType.SelectedIndex;
            _cardReader.OpenDevice();

            ClearTrackText();
        }
        catch(Exception ex)
        {
            CardReaderError(ex.Message);
        }
    }

    public void OnCloseClick(object sender, RoutedEventArgs e)
    {
        try
        {
            _cardReader.CloseDevice();

            ClearTrackText();
        }
        catch(Exception ex)
        {
            CardReaderError(ex.Message);
        }
    }

    public void OnAcceptCardClick(object sender, RoutedEventArgs e)
    {
        if (TextBoxAcceptCardTimeout == null || TextBoxAcceptCardTimeout.Text == null)
            return;

        try
        {
            string value = TextBoxAcceptCardTimeout.Text;
            int timeout = int.Parse(value);
            _cardReader.AcceptCard(timeout);

            Dispatcher.UIThread.Invoke( () => 
            {
                TextBoxResult.Text = $"AcceptCard success.";
            });
        }
        catch(Exception ex)
        {
            CardReaderError(ex.Message);
        }
    }

    public void OnAcceptEMVCardClick(object sender, RoutedEventArgs e)
    {
        if (TextBoxAcceptEMVCardTimeout == null || TextBoxAcceptEMVCardTimeout.Text == null)
            return;

        try
        {
            string value = TextBoxAcceptEMVCardTimeout.Text;
            int timeout = int.Parse(value);

            _cardReader.EMVOption = 1;
            _cardReader.AcceptEmvCard(timeout);

            ClearTrackText();

            Dispatcher.UIThread.Invoke( () => 
            {
                TextBoxResult.Text = $"Accept EMV Card success.";
            });
        }
        catch(Exception ex)
        {
            CardReaderError(ex.Message);
        }
    }

    public void OnChipIOClick(object sender, RoutedEventArgs e)
    {
        if (TextBoxChipIO == null || TextBoxChipIO.Text == null)
            return;

        try
        {
            string value = TextBoxChipIO.Text;
            string respValue;
           
            respValue = _cardReader.ChipIO(value);

            Dispatcher.UIThread.Invoke( () => 
            {
                TextBoxResult.Text = $"ChipIO : " + respValue;
            });
        }
        catch(Exception ex)
        {
            CardReaderError(ex.Message);
        }
    }

    public void OnEjectClick(object sender, RoutedEventArgs e)
    {
        try
        {
            _cardReader.EjectCard();

            Dispatcher.UIThread.Invoke( () => 
            {
                TextBoxResult.Text = $"EjectCard success.";
            });
        }
        catch(Exception ex)
        {
            CardReaderError(ex.Message);
        }
    }

    public void OnCancelAcceptClick(object sender, RoutedEventArgs e)
    {
        try
        {
            _cardReader.CancelAccept();

            Dispatcher.UIThread.Invoke( () => 
            {
                TextBoxResult.Text = $"Cancel Accept success.";
            });
        }
        catch(Exception ex)
        {
            CardReaderError(ex.Message);
        }
    }

    public void OnPowerResetClick(object sender, RoutedEventArgs e)
    {
        try
        {
            _cardReader.PowerReset();

            Dispatcher.UIThread.Invoke( () => 
            {
                TextBoxResult.Text = $"Power Reset success.";
            });
        }
        catch(Exception ex)
        {
            CardReaderError(ex.Message);
        }
    }

    void CardReaderError(String errorMsg)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxResult.Text = errorMsg;
        });
    }

    void ClearTrackText()
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxTrack1.Text = "";
            TextBoxTrack2.Text = "";
            TextBoxTrack3.Text = "";
        });
    }
}
