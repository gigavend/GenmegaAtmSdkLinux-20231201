using System.Runtime.InteropServices;
using System.Text;

namespace LxGenDevCardReader;

internal static class GenDevCardReaderLib
{
    private const string LibraryName = "LxGenDevCardReader.so";

    private delegate int GetStringPropertyDelegate(StringBuilder buffer, int bufferLenth);

    private static String GetStringProperty(GetStringPropertyDelegate getProperty)
    {
        int bufferSize = 1024; // Adjust the buffer size as needed
        StringBuilder buffer = new StringBuilder(bufferSize);
        getProperty(buffer, bufferSize);
        return buffer.ToString();
    }


    /*
    typedef void (*MCREventDeviceOpened)(void* pobj, const char* OpenedPortPath);
    typedef void (*MCREventDeviceClosed)(void* pobj);
    typedef void (*MCREventCardNotPresented)(void* pobj);
    typedef void (*MCREventCardPresented)(void* pobj);
    typedef void (*MCREventCardReadCompleted)(void* pobj, const char* CardTrack1, const char* CardTrack2, const char* CardTrack3);
    typedef void (*MCREventCardReadError)(void* pobj);
    typedef void (*MCREventAcceptCardCanceled)(void* pobj);
    typedef void (*MCREventDeviceError)(void* pobj, short Reason);
    typedef void (*MCREventPowerResetCompleted)(void* pobj);
    typedef void (*MCREventChipResetCompleted)(void* pobj);
    typedef void (*MCREventChipResetError)(void* pobj);
    typedef void (*MCREventEjectCardCompleted)(void* pobj);
    typedef void (*MCREventStatusChanged)(void* pobj);

    void MCRRegCallbackDeviceOpened(MCREventDeviceOpened eventfunc);
    void MCRRegCallbackDeviceClosed(MCREventDeviceClosed eventfunc);
    void MCRRegCallbackCardNotPresented(MCREventCardNotPresented eventfunc);
    void MCRRegCallbackCardPresented(MCREventCardPresented eventfunc);
    void MCRRegCallbackCardReadCompleted(MCREventCardReadCompleted eventfunc);
    void MCRRegCallbackCardReadError(MCREventCardReadError eventfunc);
    void MCRRegCallbackAcceptCardCanceled(MCREventAcceptCardCanceled eventfunc);
    void MCRRegCallbackDeviceError(MCREventDeviceError eventfunc);
    void MCRRegCallbackPowerResetCompleted(MCREventPowerResetCompleted eventfunc);
    void MCRRegCallbackChipResetCompleted(MCREventChipResetCompleted eventfunc);
    void MCRRegCallbackChipResetError(MCREventChipResetError eventfunc);
    void MCRRegCallbackEjectCardCompleted(MCREventEjectCardCompleted eventfunc);
    void MCRRegCallbackStatusChanged(MCREventStatusChanged eventfunc);
    */

    //Callback Delegates
    internal delegate void MCREventDeviceOpenedDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String portPath);
    internal delegate void MCREventDeviceClosedDelegate(IntPtr pObj);
    internal delegate void MCREventCardNotPresentedDelegate(IntPtr pObj);
    internal delegate void MCREventCardPresentedDelegate(IntPtr pObj);
    internal delegate void MCREventCardReadCompletedDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String cardTrack1,[MarshalAs(UnmanagedType.LPStr)] String cardTrack2, [MarshalAs(UnmanagedType.LPStr)] String cardTrack3);
    internal delegate void MCREventCardReadErrorDelegate(IntPtr pObj);
    internal delegate void MCREventAcceptCardCanceledDelegate(IntPtr pObj);
    internal delegate void MCREventDeviceErrorDelegate(IntPtr pObj, short reason);
    internal delegate void MCREventPowerResetCompletedDelegate(IntPtr pObj);
    internal delegate void MCREventChipResetCompletedDelegate(IntPtr pObj);
    internal delegate void MCREventChipResetErrorDelegate(IntPtr pObj);
    internal delegate void MCREventEjectCardCompletedDelegate(IntPtr pObj);
    internal delegate void MCREventStatusChangedDelegate(IntPtr pObj);

    //Raw Event
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void MCRRegCallbackDeviceOpened([MarshalAs(UnmanagedType.FunctionPtr)] MCREventDeviceOpenedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void MCRRegCallbackDeviceClosed([MarshalAs(UnmanagedType.FunctionPtr)] MCREventDeviceClosedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void MCRRegCallbackCardNotPresented([MarshalAs(UnmanagedType.FunctionPtr)] MCREventCardNotPresentedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void MCRRegCallbackCardPresented([MarshalAs(UnmanagedType.FunctionPtr)] MCREventCardPresentedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void MCRRegCallbackCardReadCompleted([MarshalAs(UnmanagedType.FunctionPtr)] MCREventCardReadCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void MCRRegCallbackCardReadError([MarshalAs(UnmanagedType.FunctionPtr)] MCREventCardReadErrorDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void MCRRegCallbackAcceptCardCanceled([MarshalAs(UnmanagedType.FunctionPtr)] MCREventAcceptCardCanceledDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void MCRRegCallbackDeviceError([MarshalAs(UnmanagedType.FunctionPtr)] MCREventDeviceErrorDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void MCRRegCallbackPowerResetCompleted([MarshalAs(UnmanagedType.FunctionPtr)] MCREventPowerResetCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void MCRRegCallbackChipResetCompleted([MarshalAs(UnmanagedType.FunctionPtr)] MCREventChipResetCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void MCRRegCallbackChipResetError([MarshalAs(UnmanagedType.FunctionPtr)] MCREventChipResetErrorDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void MCRRegCallbackEjectCardCompleted([MarshalAs(UnmanagedType.FunctionPtr)] MCREventEjectCardCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void MCRRegCallbackStatusChanged([MarshalAs(UnmanagedType.FunctionPtr)] MCREventStatusChangedDelegate func);

    
    /*
    int MCRGetPortPath(char* pPortPath, int nMaxLength);
    void MCRSetPortPath(const char* lpszNewValue);
    int MCRGetBaudRate();
    void MCRSetBaudRate(int nNewValue);
    short MCRGetParity();
    void MCRSetParity(short nNewValue);
    short MCRGetStopBits();
    void MCRSetStopBits(short nNewValue);
    short MCRGetByteSize();
    void MCRSetByteSize(short nNewValue);
    bool MCRGetTraceLog();
    void MCRSetTraceLog(bool bNewValue);
    short MCRGetMCRType();
    void MCRSetMCRType(short nNewValue);
    short MCRGetEMVOption();
    void MCRSetEMVOption(short nNewValue);
    int MCRGetStDevice(char* pStDevice, int nMaxLength);
    int MCRGetStMedia(char* pStMedia, int nMaxLength);
    int MCRGetVersion(char* pVersion, int nMaxLength);
    int MCRGetStSensorInfo(char* pStSensorInfo, int nMaxLength);
    */

    //Properties
    internal static string PortPath
    {
        get { return GetStringProperty(MCRGetPortPath); }
        set { MCRSetPortPath(value); }
    }

    internal static int BaudRate
    {
        get { return MCRGetBaudRate(); }
        set { MCRSetBaudRate(value); }
    }

    internal static int ByteSize
    {
        get { return MCRGetByteSize(); }
        set { MCRSetByteSize((short)value); }
    }

    internal static int Parity
    {
        get { return MCRGetParity(); }
        set { MCRSetParity((short)value); }
    }

    internal static int StopBits
    {
        get { return MCRGetStopBits(); }
        set { MCRSetByteSize((short)value); }
    }

    internal static bool TraceLog
    {
        get { return MCRGetTraceLog(); }
        set { MCRSetTraceLog(value); }
    }

    internal static int MCRType
    {
        get { return MCRGetMCRType(); }
        set { MCRSetMCRType((short)value); }
    }

    internal static int EMVOption
    {
        get { return MCRGetEMVOption(); }
        set { MCRSetEMVOption((short)value); }
    }

    internal static string StDevice
    {
        get {return GetStringProperty(MCRGetStDevice);}
    }

    internal static string StMedia
    {
        get {return GetStringProperty(MCRGetStMedia);}
    }

    internal static string Version
    {
        get {return GetStringProperty(MCRGetVersion);}
    }

    internal static string SensorInfo
    {
        get {return GetStringProperty(MCRGetStSensorInfo);}
    }


    // Raw Properties
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int MCRGetPortPath(StringBuilder pPortPath, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void MCRSetPortPath([MarshalAs(UnmanagedType.LPStr)] string str);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int MCRGetBaudRate();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void MCRSetBaudRate(int baudrate);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCRGetParity();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void MCRSetParity(short parity);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCRGetStopBits();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void MCRSetStopBits(short stopBits);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCRGetByteSize();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void MCRSetByteSize(short byteSize);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    [return: MarshalAs(UnmanagedType.I1)]
    internal static extern bool MCRGetTraceLog();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void MCRSetTraceLog([MarshalAs(UnmanagedType.I1)] bool traceLog);


    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCRGetMCRType();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void MCRSetMCRType(short type);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCRGetEMVOption();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void MCRSetEMVOption(short type);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int MCRGetStDevice(StringBuilder pStDevice, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int MCRGetStMedia(StringBuilder pStMedia, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int MCRGetVersion(StringBuilder pVersion, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int MCRGetStSensorInfo(StringBuilder pStSensorInfo, int nMaxLength);


    /*
    short MCROpenDevice();
    short MCRCloseDevice();
    short MCRAcceptCard(long WaitTimeout);
    short MCRCancelAccept();
    short MCRPowerReset();
    short MCREjectCard();
    short MCRAcceptEmvCard(long WaitTimeout);
    int MCRChipIO(const char* szSendData, char* pRespData, int nMaxLength) ;
    int MCRGetATRasChipReset(char* pRespData, int nMaxLength);
    int MCRICDirection(int iIcSendLen, unsigned char *szIcSend, int *iIcRecvLen, unsigned char *szIcRecv);
    */

    // Raw Methods
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCROpenDevice();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCRCloseDevice();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCRAcceptCard(long waitTimeout);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCRCancelAccept();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCRPowerReset();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCREjectCard();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCRAcceptEmvCard(long waitTimeout);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCRChipIO([MarshalAs(UnmanagedType.LPStr)] string szSendData, StringBuilder pRespData, int nMaxLength);

    /*
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCRGetATRasChipReset(StringBuilder pRespData, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCRICDirection(int iIcSendLen, [MarshalAs(UnmanagedType.LPStr)] string szIcSend, ref int iIcRecvLen, StringBuilder szIcRecv);
    */
    
    /*  [EMV Method]
        short MCR_emvkrnl_parameter_init(int terminalType, const char* termID, const char* paramPath);
        short MCR_emvkrnl_set_term(int seq_cnt);
        short MCR_emvkrnl_transaction_type_select(int tranType);
        short MCR_emvkrnl_account_type_select(int accType);
        short MCR_emvkrnl_application_selection(int keyValue);
        int MCR_emvkrnl_get_candidateList(char* pRespData, int nMaxLength);
        short MCR_emvkrnl_read_application(void);
        short MCR_emvkrnl_offline_data_authentication(void);
        short MCR_emvkrnl_processing_restrictions(void);
        short MCR_emvkrnl_cardholder_verification(const char* pinValue);
        short MCR_emvkrnl_terminal_risk_management(void);
        short MCR_emvkrnl_terminal_action_analysis(void);
        short MCR_emvkrnl_set_purchase_amount(int nType, int nAmount);
        short MCR_emvkrnl_card_action_analysis(void);
        short MCR_emvkrnl_online_reversal(void);
        short MCR_emvkrnl_online_confirm(void);
        short MCR_emvkrnl_online_advice(void);
        short MCR_emvkrnl_online_reject(void);
        short MCR_emvkrnl_online_referral(void);
        short MCR_emvkrnl_unable_online(void);
        short MCR_emvkrnl_online_process(const char* arc, const char* iad, const char* issuerscript);
        short MCR_emvkrnl_completion(void);
        int MCR_emvkrnl_read_dataElemet(const char* tagName, char* pRespData, int nMaxLength);
    */
    // Raw Methods[EMV]
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCR_emvkrnl_parameter_init(int terminalType, [MarshalAs(UnmanagedType.LPStr)] string termID, [MarshalAs(UnmanagedType.LPStr)] string paramPath);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCR_emvkrnl_set_term(int seq_cnt);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCR_emvkrnl_transaction_type_select(int tranType);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCR_emvkrnl_account_type_select(int accType);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCR_emvkrnl_application_selection(int keyValue);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int MCR_emvkrnl_get_candidateList(StringBuilder pRespData, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCR_emvkrnl_read_application();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCR_emvkrnl_offline_data_authentication();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCR_emvkrnl_processing_restrictions();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCR_emvkrnl_cardholder_verification([MarshalAs(UnmanagedType.LPStr)] string pinValue);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCR_emvkrnl_terminal_risk_management();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCR_emvkrnl_terminal_action_analysis();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCR_emvkrnl_set_purchase_amount(int nType, int nAmount);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCR_emvkrnl_card_action_analysis();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCR_emvkrnl_online_reversal();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCR_emvkrnl_online_confirm();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCR_emvkrnl_online_advice();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCR_emvkrnl_online_reject();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCR_emvkrnl_online_referral();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCR_emvkrnl_unable_online();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCR_emvkrnl_online_process([MarshalAs(UnmanagedType.LPStr)] string arc,[MarshalAs(UnmanagedType.LPStr)] string iad, [MarshalAs(UnmanagedType.LPStr)] string issuerscript);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short MCR_emvkrnl_completion();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int MCR_emvkrnl_read_dataElemet([MarshalAs(UnmanagedType.LPStr)] string tagName, StringBuilder pRespData, int nMaxLength);

}