﻿using System.Diagnostics;
using System.Net;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.VisualBasic.FileIO;
using static LxGenDevCardReader.GenDevCardReaderLib;


namespace LxGenDevCardReader;

public class GenDevCardReader
{
    // Properties
    public string PortPath
    {
        get { return GenDevCardReaderLib.PortPath; }
        set { GenDevCardReaderLib.PortPath = value; }
    }

    public int BaudRate
    {
        get { return GenDevCardReaderLib.BaudRate; }
        set { GenDevCardReaderLib.BaudRate = value; }
    }

    public int ByteSize
    {
        get { return GenDevCardReaderLib.ByteSize; }
        set { GenDevCardReaderLib.ByteSize = value; }
    }

    public int Parity
    {
        get { return GenDevCardReaderLib.Parity; }
        set { GenDevCardReaderLib.Parity = value; }
    }

    public int StopBits
    {
        get { return GenDevCardReaderLib.StopBits; }
        set { GenDevCardReaderLib.StopBits = value; }
    }

    public bool TraceLog
    {
        get { return GenDevCardReaderLib.TraceLog; }
        set { GenDevCardReaderLib.TraceLog = value; }
    }

    public int MCRType
    {
        get { return GenDevCardReaderLib.MCRType; }
        set { GenDevCardReaderLib.MCRType = value; }
    }

    public int EMVOption
    {
        get { return GenDevCardReaderLib.EMVOption; }
        set { GenDevCardReaderLib.EMVOption = value; }
    }

    public string StDevice => GenDevCardReaderLib.StDevice;

    public string StMedia => GenDevCardReaderLib.StMedia;

    public string Version => GenDevCardReaderLib.Version;

    public string SensorInfo => GenDevCardReaderLib.SensorInfo;

    public GenDevCardReader()
    {
        _mcrEventDeviceOpenedDelegate = new MCREventDeviceOpenedDelegate(EventDeviceOpened);
        _mcrEventDeviceClosedDelegate = new MCREventDeviceClosedDelegate(EventDeviceClosed);
        _mcrEventCardNotPresentedDelegate = new MCREventCardNotPresentedDelegate(EventCardNotPresented);
        _mcrEventCardPresentedDelegate = new MCREventCardPresentedDelegate(EventCardPresented);
        _mcrEventCardReadCompletedDelegate = new MCREventCardReadCompletedDelegate(EventCardReadCompleted);
        _mcrEventCardReadErrorDelegate = new MCREventCardReadErrorDelegate(EventCardReadError);
        _mcrEventAcceptCardCanceledDelegate = new MCREventAcceptCardCanceledDelegate(EventAcceptCardCanceled);
        _mcrEventDeviceErrorDelegate = new MCREventDeviceErrorDelegate(EventDeviceError);
        _mcrEventPowerResetCompletedDelegate = new MCREventPowerResetCompletedDelegate(EventPowerResetCompleted);
        _mcrEventChipResetErrorDelegate = new MCREventChipResetErrorDelegate(EventChipResetError);
        _mcrEventChipResetCompletedDelegate = new MCREventChipResetCompletedDelegate(EventChipResetCompleted);
        _mcrEventEjectCardCompletedDelegate = new MCREventEjectCardCompletedDelegate(EventEjectCardCompleted);
        _mcrEventStatusChangedDelegate = new MCREventStatusChangedDelegate(EventStatusChanged);

        MCRRegCallbackDeviceOpened(_mcrEventDeviceOpenedDelegate);
        MCRRegCallbackDeviceClosed(_mcrEventDeviceClosedDelegate);
        MCRRegCallbackCardNotPresented(_mcrEventCardNotPresentedDelegate);
        MCRRegCallbackCardPresented(_mcrEventCardPresentedDelegate);
        MCRRegCallbackCardReadCompleted(_mcrEventCardReadCompletedDelegate);
        MCRRegCallbackCardReadError(_mcrEventCardReadErrorDelegate);
        MCRRegCallbackAcceptCardCanceled(_mcrEventAcceptCardCanceledDelegate);
        MCRRegCallbackDeviceError(_mcrEventDeviceErrorDelegate);
        MCRRegCallbackPowerResetCompleted(_mcrEventPowerResetCompletedDelegate);
        MCRRegCallbackChipResetCompleted(_mcrEventChipResetCompletedDelegate);
        MCRRegCallbackChipResetError(_mcrEventChipResetErrorDelegate);
        MCRRegCallbackEjectCardCompleted(_mcrEventEjectCardCompletedDelegate);
        MCRRegCallbackStatusChanged(_mcrEventStatusChangedDelegate);
    }

    // Methods
    public void OpenDevice()
    {
        short retval = MCROpenDevice();
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void CloseDevice()
    {
        int retval = MCRCloseDevice();
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void AcceptCard(long waitTimeout)
    {
        int retval = MCRAcceptCard(waitTimeout);
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void CancelAccept()
    {
        int retval = MCRCancelAccept();
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void PowerReset()
    {
        int retval = MCRPowerReset();
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void EjectCard()
    {
        int retval = MCREjectCard();
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void AcceptEmvCard(long waitTimeout)
    {
        int retval = MCRAcceptEmvCard(waitTimeout);
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public string ChipIO(string data)
    {
        int maxLen = 1024;
        StringBuilder respData = new StringBuilder(maxLen);
        
        int retval = MCRChipIO(data, respData, maxLen);
        if (retval < 0)
        {
            throw new CardReaderException(retval);
        }

        return respData.ToString();
    }

    /*
    public string GetATRasChipReset()
    {
        int maxLen = 1024;
        StringBuilder respData = new StringBuilder(maxLen);

        int retval = MCRGetATRasChipReset(respData, maxLen);
        if (retval < 0)
        {
            throw new CardReaderException(retval);
        }

        return respData.ToString();
    }

    public string ICDirection(string icSend)
    {
        int icSendLength = icSend.Length;
        int maxLen = 1024;
        int iIcRecvLen = 0;
        StringBuilder respData = new StringBuilder(maxLen);

        int retval = MCRICDirection(icSendLength, icSend, ref iIcRecvLen, respData);
        if (retval < 0)
        {
            throw new CardReaderException(retval);
        }

        return respData.ToString();
    }
    */

    // EMV Methods
    public void EMV_parameter_init(int terminalType, string termID, string paramPath)
    {
        int retval = MCR_emvkrnl_parameter_init(terminalType, termID, paramPath );
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void EMV_set_term(int seq_cnt)
    {
        int retval = MCR_emvkrnl_set_term(seq_cnt);
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void EMV_transaction_type_select(int tranType)
    {
        int retval = MCR_emvkrnl_transaction_type_select(tranType);
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void EMV_account_type_select(int accType)
    {
        int retval = MCR_emvkrnl_account_type_select(accType);
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void EMV_application_selection(int keyValue)
    {
        int retval = MCR_emvkrnl_application_selection(keyValue);
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public string EMV_get_candidateList()
    {
        int maxLength = 1024;
        StringBuilder respData = new StringBuilder(maxLength);
        int retval = MCR_emvkrnl_get_candidateList(respData, maxLength);

        if (retval < 0)
        {
            throw new CardReaderException(retval);
        }

        return respData.ToString();
    }

    public void EMV_read_application()
    {
        int retval = MCR_emvkrnl_read_application();
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void EMV_offline_data_authentication()
    {
        int retval = MCR_emvkrnl_offline_data_authentication();
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void EMV_processing_restrictions()
    {
        int retval = MCR_emvkrnl_processing_restrictions();
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void EMV_cardholder_verification(ref string pinValue)
    {
        int retval = MCR_emvkrnl_cardholder_verification(pinValue);
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void EMV_terminal_risk_management()
    {
        int retval = MCR_emvkrnl_terminal_risk_management();
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void EMV_terminal_action_analysis()
    {
        int retval = MCR_emvkrnl_terminal_action_analysis();
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void EMV_set_purchase_amount(int type, int amount)
    {
        int retval = MCR_emvkrnl_set_purchase_amount(type, amount);
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void EMV_card_action_analysis()
    {
        int retval = MCR_emvkrnl_card_action_analysis();
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void EMV_online_reversal()
    {
        int retval = MCR_emvkrnl_online_reversal();
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void EMV_online_confirm()
    {
        int retval = MCR_emvkrnl_online_confirm();
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void EMV_online_advice()
    {
        int retval = MCR_emvkrnl_online_advice();
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void EMV_online_reject()
    {
        int retval = MCR_emvkrnl_online_reject();
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void EMV_online_referral()
    {
        int retval = MCR_emvkrnl_online_referral();
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void EMV_emvkrnl_unable_online()
    {
        int retval = MCR_emvkrnl_unable_online();
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void EMV_online_process(string arc, string iad, string issuerscript)
    {
        int retval = MCR_emvkrnl_online_process(arc, iad, issuerscript);
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public void EMV_completion()
    {
        int retval = MCR_emvkrnl_completion();
        if (retval != 0)
        {
            throw new CardReaderException(retval);
        }
    }

    public string EMV_read_dataElemet(string tagName)
    {
        int maxLength = 1024;
        StringBuilder respData = new StringBuilder(maxLength);

        int retval = MCR_emvkrnl_read_dataElemet(tagName, respData, maxLength);
        if (retval < 0)
        {
            throw new CardReaderException(retval);
        }

        return respData.ToString();
    }






    // Processing callback
    public void EventDeviceOpened(IntPtr pObj, String portPath)
    {
        OnDeviceOpened?.Invoke(null, portPath);
    }

    public void EventDeviceClosed(IntPtr pObj)
    {
        OnDeviceClosed?.Invoke(null, new ());
    }

    public void EventCardNotPresented(IntPtr pObj)
    {
        OnCardNotPresented?.Invoke(null, new ());
    }

    public void EventCardPresented(IntPtr pObj)
    {
        OnCardPresented?.Invoke(null, new ());
    }

    public void EventCardReadCompleted(IntPtr pObj, string track1, string track2, string track3)
    {
        OnCardReadCompleted?.Invoke(null, new CardReaderTrack(track1, track2, track3));
    }

    public void EventCardReadError(IntPtr pObj)
    {
        OnCardReadError?.Invoke(null, new ());
    }

    public void EventAcceptCardCanceled(IntPtr pObj)
    {
        OnAcceptCardCanceled?.Invoke(null, new ());
    }

    private void EventDeviceError(nint pObj, short reason)
    {
        OnDeviceError?.Invoke(null, reason);
    }

    public void EventPowerResetCompleted(IntPtr pObj)
    {
        OnPowerResetCompleted?.Invoke(null, new ());
    }

    public void EventChipResetCompleted(IntPtr pObj)
    {
        OnChipResetCompleted?.Invoke(null, new ());
    }

    public void EventChipResetError(IntPtr pObj)
    {
        OnChipResetError?.Invoke(null, new ());
    }

    public void EventEjectCardCompleted(IntPtr pObj)
    {
        OnEjectCardCompleted?.Invoke(null, new ());
    }

    public void EventStatusChanged(IntPtr pObj)
    {
        OnStatusChanged?.Invoke(null, new ());
    }



    // Events
    public event EventHandler<String>? OnDeviceOpened;
    public event EventHandler? OnDeviceClosed;
    public event EventHandler? OnCardNotPresented;
    public event EventHandler? OnCardPresented;
    public event EventHandler<CardReaderTrack>? OnCardReadCompleted;
    public event EventHandler? OnCardReadError;
    public event EventHandler? OnAcceptCardCanceled;
    public event EventHandler<int>? OnDeviceError;
    public event EventHandler? OnPowerResetCompleted;
    public event EventHandler? OnChipResetCompleted;
    public event EventHandler? OnChipResetError;
    public event EventHandler? OnEjectCardCompleted;
    public event EventHandler? OnStatusChanged;

    //
    //  Delegate can be deleted by Gabage collector if it pass as marshalling callback function.
    //  It need to keep reference to get callback function works.
    //
    private readonly MCREventDeviceOpenedDelegate _mcrEventDeviceOpenedDelegate;
    private readonly MCREventDeviceClosedDelegate _mcrEventDeviceClosedDelegate;
    private readonly MCREventCardNotPresentedDelegate _mcrEventCardNotPresentedDelegate;
    private readonly MCREventCardPresentedDelegate _mcrEventCardPresentedDelegate;
    private readonly MCREventCardReadCompletedDelegate _mcrEventCardReadCompletedDelegate;
    private readonly MCREventCardReadErrorDelegate _mcrEventCardReadErrorDelegate;
    private readonly MCREventAcceptCardCanceledDelegate _mcrEventAcceptCardCanceledDelegate;
    private readonly MCREventDeviceErrorDelegate _mcrEventDeviceErrorDelegate;
    private readonly MCREventPowerResetCompletedDelegate _mcrEventPowerResetCompletedDelegate ;
    private readonly MCREventChipResetErrorDelegate _mcrEventChipResetErrorDelegate;
    private readonly MCREventChipResetCompletedDelegate _mcrEventChipResetCompletedDelegate;
    private readonly MCREventEjectCardCompletedDelegate _mcrEventEjectCardCompletedDelegate;
    private readonly MCREventStatusChangedDelegate _mcrEventStatusChangedDelegate;

    
}
