﻿namespace LxGenDevCardReader;

public class CardReaderTrack
{
    public string? Track1 {get;set;}
    public string? Track2 {get;set;}
    public string? Track3 {get;set;}

    public CardReaderTrack(string track1, string track2, string track3)
    {
        Track1 = track1;
        Track2 = track2;
        Track3 = track3;
    }
}
