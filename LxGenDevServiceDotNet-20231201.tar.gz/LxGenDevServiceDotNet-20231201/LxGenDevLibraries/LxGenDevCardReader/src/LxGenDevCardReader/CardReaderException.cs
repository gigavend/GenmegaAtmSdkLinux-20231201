namespace LxGenDevCardReader;

public class CardReaderException : Exception
{
    public int ErrorCode { get; internal set; }

    internal CardReaderException(int errorCode) : base($"Error Code : {errorCode}")
    {
        ErrorCode = errorCode;
    }
}