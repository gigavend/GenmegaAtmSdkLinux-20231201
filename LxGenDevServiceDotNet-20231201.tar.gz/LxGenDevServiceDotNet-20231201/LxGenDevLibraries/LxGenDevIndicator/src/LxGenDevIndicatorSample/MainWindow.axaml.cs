using System;
using System.Linq;
using System.Threading.Tasks;
using System.Timers;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Platform.Storage;
using Avalonia.Threading;
using LxGenDevIndicator;

namespace LxGenDevIndicatorSample;

public partial class MainWindow : Window
{
    GenDevIndicator _indicator = new GenDevIndicator();

    Timer LEDTimer;
    short LedStyle;
    short Order;

    public MainWindow()
    {
        InitializeComponent();

        LEDTimer = new Timer();
        LEDTimer.Elapsed += (sender, e) => TimerED_Elapsed(this, e, LedStyle);

        
        ComboBoxPorts.ItemsSource = new String[] {"/dev/ttyS0","/dev/ttyS1","/dev/ttyS2","/dev/ttyS3","/dev/ttyS4","/dev/ttyS5", "/dev/ttyUSB0", "/dev/ttyUSB1" };
        ComboBoxPorts.SelectedIndex = 4; 

        ComboBoxSetById.ItemsSource = new String[] {"-1","1","2","3","4","5","6","7","8","9","10","10","12" };
        ComboBoxSetById.SelectedIndex = 1; 

        ComboBoxSetByIdEx.ItemsSource = new String[] {"-1","1","2","3","4","5","6","7","8","9","10","10","12" };
        ComboBoxSetByIdEx.SelectedIndex = 1; 

        TextBoxSetByName.Text = "ALL";
        TextBoxSetByNameEx.Text = "ALL";

        ComboBoxSetLEDStyle.ItemsSource = new String[] {"0 : Default" , "1 : SET" , "2 : Random"};
        ComboBoxSetLEDStyle.SelectedIndex = 0; 

        TextBoxFLK1.Text = "255,255,255"; 
        TextBoxFLK2.Text = "255,255,255";
        TextBoxFLK3.Text = "255,255,255";
        TextBoxFLK4.Text = "255,255,255";
        TextBoxFLK5.Text = "255,255,255";
        TextBoxFLK6.Text = "255,255,255";
        TextBoxFLK7.Text = "255,255,255";
        TextBoxFLK8.Text = "255,255,255";
        TextBoxFLK9.Text = "255,255,255";
        TextBoxFLK11.Text = "255,255,255";

        TextBoxLED1.Text ="255,255,255";
        TextBoxLED2.Text ="255,255,255";
        TextBoxLED3.Text ="255,255,255";
        TextBoxLED4.Text ="255,255,255";
        TextBoxLED5.Text ="255,255,255";
        TextBoxLED6.Text ="255,255,255";

        TextBoxSetLEDTimer.Text = "5";

        Initialize();
    }

    public void Initialize()
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            CheckBoxTraceLog.IsDefault = _indicator.TraceLog;
        });

        _indicator.OnDeviceOpened += SIUOpened;
        _indicator.OnDeviceClosed += SIUClosed;
        _indicator.OnInitialized += SIUInitialized; 
        _indicator.OnStatusChanged +=  SIUStatusChanged; 
        _indicator.OnSetIndicatorCompleted +=  SIUSetIndicatorCompleted;
        _indicator.OnDeviceError += SIUDeviceError;
        _indicator.OnFunctionKeyPressed += SIUFunctionKeyPressed;
        _indicator.OnFunctionKeyReleased += SIUFunctionKeyReleased;
        _indicator.OnAudioGuidanceChanged +=SIUAudioGuidanceChanged;
        _indicator.OnSetFeedActionCompleted +=  SIUSetFeedActionCompleted;
        _indicator.OnSetLEDCompleted += SIUSetLEDCompleted;
        _indicator.OnAdminSwitchChanged +=  SIUAdminSwitchChanged;
        _indicator.OnSetIndicatorRGBCompleted +=  SIUSetIndicatorRGBCompleted;  
        _indicator.OnMcrPowerResetCompleted +=  SIUMcrPowerResetCompleted;
    }

    public void SIUOpened(Object? sender, String portPath)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Device Opened: {portPath}";
            TextBlockVersion.Text = _indicator.Version;
        });
    }

    private void SIUClosed(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Closed device";
        });
    }

    private void SIUInitialized(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Initialize Completed";
        });
    }

    private void SIUStatusChanged(object? sender, StatusChanged e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxstDevice.Text = _indicator.StDevice;
            TextBoxstDoor1.Text = _indicator.StDoor;
            TextBoxstDoor2.Text = _indicator.StDoor2;
            TextBoxstDoor3.Text = _indicator.StDoor3;
            TextBoxstDoor4.Text = _indicator.StDoor4;
            TextBoxstDoor5.Text = _indicator.StDoor5;
            TextBoxstDoor6.Text = _indicator.StDoor6;
            TextBoxstDoor7.Text = _indicator.StDoor7;
            TextBoxstDoor8.Text = _indicator.StDoor8;
            TextBoxstDoor9.Text = _indicator.StDoor9;
            TextBoxProximity.Text = _indicator.Proximity;
        });
    }

    private void SIUSetIndicatorCompleted(object? sender, SetIndicatorCompleted e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"SetIndicator Completed. ID : {e.IndicatorID},  Name : {e.IndicatorName},  State : {e.CurrentState}";
        });
    }

    private void SIUDeviceError(object? sender, short e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Device Error: {e}";
        });
    }

    private void SIUFunctionKeyPressed(object? sender, short e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"FunctionKey Pressed : {e}";
        });
    }

    
    private void SIUFunctionKeyReleased(object? sender, short e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"FunctionKey Released : {e}";
        });
    }

    private void SIUAudioGuidanceChanged(object? sender, string CurrentStatus)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Audio Guidance Changed : {CurrentStatus}";
        });
    }

   
    private void SIUSetFeedActionCompleted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Set FeedAction Completed";
        });
    }

    private void SIUSetLEDCompleted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Set LED Completed";
        });
    }

    private void SIUAdminSwitchChanged(object? sender, string CurrentStatus)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Admin Switch Changed : {CurrentStatus}";
        });
    }

    private void SIUSetIndicatorRGBCompleted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Set Indicator RGB Completed";
        });
    }

    private void SIUMcrPowerResetCompleted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Mcr PowerReset Completed";
        });
    }


    void TimerED_Elapsed(object sender, ElapsedEventArgs e, short style)
    {
        
        if (style == 1)
        {
            if (Order == 0) //RED
            {
                    _indicator.LED1_RGB = "255,0,0";
                    _indicator.LED2_RGB = "255,0,0";
                    _indicator.LED3_RGB = "255,0,0";
                    _indicator.LED4_RGB = "255,0,0";
                    _indicator.LED5_RGB = "255,0,0";
                    _indicator.LED6_RGB = "255,0,0";
                    Order = 1;
            }
            else if (Order == 1) //Green
            {
                    _indicator.LED1_RGB = "0,255,0";
                    _indicator.LED2_RGB = "0,255,0";
                    _indicator.LED3_RGB = "0,255,0";
                    _indicator.LED4_RGB = "0,255,0";
                    _indicator.LED5_RGB = "0,255,0";
                    _indicator.LED6_RGB = "0,255,0";
                    Order = 2;
            }
            else if (Order == 2) //Blue
            {
                    _indicator.LED1_RGB = "0,0,255";
                    _indicator.LED2_RGB = "0,0,255";
                    _indicator.LED3_RGB = "0,0,255";
                    _indicator.LED4_RGB = "0,0,255";
                    _indicator.LED5_RGB = "0,0,255";
                    _indicator.LED6_RGB = "0,0,255";
                    Order = 0;
            }
        }

        try
        {
            IndicatorEventErrorClear();
            _indicator.SetLED(true, style);
        }
        catch(Exception ex)
        {
            IndicatorError(ex.Message);
        }
    }

    public void OnCheckTraceLog(object sender, RoutedEventArgs e)
    {
        _indicator.TraceLog = CheckBoxTraceLog.IsChecked??false;
    }

    public void OnOpenClick(object sender, RoutedEventArgs e)
    {
        try
        {
            IndicatorEventErrorClear();

            _indicator.PortPath = ComboBoxPorts.SelectedValue?.ToString() ?? "/dev/ttyUSB0";
            _indicator.OpenDevice();
        }
        catch(Exception ex)
        {
            IndicatorError(ex.Message);
        }
    }

    public void OnCloseClick(object sender, RoutedEventArgs e)
    {
        try
        {
            if(LEDTimer.Enabled)
                LEDTimer.Stop();

            IndicatorEventErrorClear();
            _indicator.CloseDevice();
        }
        catch(Exception ex)
        {
            IndicatorError(ex.Message);
        }
    }

    public void OnInitializeClick(object sender, RoutedEventArgs e)
    {
        try
        {
            IndicatorEventErrorClear();
            _indicator.Initialize();
        }
        catch(Exception ex)
        {
            IndicatorError(ex.Message);
        }
    }

    public void OnSetIndicatorNamesClick(object sender, RoutedEventArgs e)
    {
        try
        {
            IndicatorEventErrorClear();

            string IndicatorNames = TextBoxIndicatorNames.Text ?? "";
            _indicator.SetIndicatorNames(IndicatorNames);
        }
        catch(Exception ex)
        {
            IndicatorError(ex.Message);
        }
    }

    public void OnGetIndicatorNamesClick(object sender, RoutedEventArgs e)
    {
        try
        {
            IndicatorEventErrorClear();

            string IndicatorNames = _indicator.GetIndicatorNames();

            Dispatcher.UIThread.Invoke( () => 
            {
                TextBoxGetIndicatorNames.Text = IndicatorNames;
            });
        }
        catch(Exception ex)
        {
            //IndicatorError(ex.Message);
            Dispatcher.UIThread.Invoke( () => 
            {
                TextBoxGetIndicatorNames.Text = ex.Message;
            });
        }
    }

    //
    public void OnSetIndicatorByIdClick(object sender, RoutedEventArgs e)
    {
        try
        {
            IndicatorEventErrorClear();
            
            short IndicatorID =  (short)int.Parse(ComboBoxSetById.SelectedValue?.ToString() ?? "-1");
            bool State = CheckBoxSetByIdState.IsChecked ?? false;

            _indicator.SetIndicatorById(IndicatorID, State);
        }
        catch(Exception ex)
        {
            IndicatorError(ex.Message);
        }
    }

    public void OnSetIndicatorByIdExClick(object sender, RoutedEventArgs e)
    {
        try
        {
            IndicatorEventErrorClear();
            
            short IndicatorID =  (short)int.Parse(ComboBoxSetByIdEx.SelectedValue?.ToString() ?? "-1");
            bool State = CheckBoxSetByIdExState.IsChecked ?? false;
            short Mode = 0;
            
            if(CheckBoxSetByIdExMode.IsChecked ?? false)
                Mode = 1;

            _indicator.SetIndicatorByIdEx(IndicatorID, State, Mode);
        }
        catch(Exception ex)
        {
            IndicatorError(ex.Message);
        }
    }

    public void OnSetIndicatorByNameClick(object sender, RoutedEventArgs e)
    {
        try
        {
            IndicatorEventErrorClear();
            
            string IndicatorName =  TextBoxSetByName.Text ?? "";
            bool State = CheckBoxSetByNameState.IsChecked ?? false;

            _indicator.SetIndicatorByName(IndicatorName, State);
        }
        catch(Exception ex)
        {
            IndicatorError(ex.Message);
        }
    }

    public void OnSetIndicatorByNameExClick(object sender, RoutedEventArgs e)
    {
        try
        {
            IndicatorEventErrorClear();
            
            string IndicatorName =  TextBoxSetByName.Text ?? "";
            bool State = CheckBoxSetByNameExState.IsChecked ?? false;
            short Mode = 0;
            
            if(CheckBoxSetByNameExMode.IsChecked ?? false)
                Mode = 1;

            _indicator.SetIndicatorByNameEx(IndicatorName, State, Mode);
        }
        catch(Exception ex)
        {
            IndicatorError(ex.Message);
        }
    }

    public void OnSetFeedActionClick(object sender, RoutedEventArgs e)
    {
        try
        {
            IndicatorEventErrorClear();
            _indicator.SetFeedAction();
        }
        catch(Exception ex)
        {
            IndicatorError(ex.Message);
        }
    }

    public void OnMCRPowerResetClick(object sender, RoutedEventArgs e)
    {
        try
        {
            IndicatorEventErrorClear();
            _indicator.McrPowerReset();
        }
        catch(Exception ex)
        {
            IndicatorError(ex.Message);
        }
    }


    public void OnSetIndicatorRGBClick(object sender, RoutedEventArgs e)
    {
        try
        {
            IndicatorEventErrorClear();

            _indicator.FLK1_RGB = TextBoxFLK1.Text ?? "255,255,255";
            _indicator.FLK2_RGB = TextBoxFLK2.Text ?? "255,255,255";
            _indicator.FLK3_RGB = TextBoxFLK3.Text ?? "255,255,255";
            _indicator.FLK4_RGB = TextBoxFLK4.Text ?? "255,255,255";
            _indicator.FLK5_RGB = TextBoxFLK5.Text ?? "255,255,255";
            _indicator.FLK6_RGB = TextBoxFLK6.Text ?? "255,255,255";
            _indicator.FLK7_RGB = TextBoxFLK7.Text ?? "255,255,255";
            _indicator.FLK8_RGB = TextBoxFLK8.Text ?? "255,255,255";
            _indicator.FLK9_RGB = TextBoxFLK9.Text ?? "255,255,255";
            _indicator.FLK11_RGB = TextBoxFLK11.Text ?? "255,255,255";    

            _indicator.SetIndicatorRGB();
        }
        catch(Exception ex)
        {
            IndicatorError(ex.Message);
        }
    }

    //
    public void OnSetLEDClick(object sender, RoutedEventArgs e)
    {
        try
        {
            IndicatorEventErrorClear();

            short style = (short)ComboBoxSetLEDStyle.SelectedIndex;
            bool state = CheckBoxSetLEDState.IsChecked ?? false;

            _indicator.LED1_RGB = TextBoxLED1.Text ?? "255,255,255";
            _indicator.LED2_RGB = TextBoxLED2.Text ?? "255,255,255";
            _indicator.LED3_RGB = TextBoxLED3.Text ?? "255,255,255";
            _indicator.LED4_RGB = TextBoxLED4.Text ?? "255,255,255";
            _indicator.LED5_RGB = TextBoxLED5.Text ?? "255,255,255";
            _indicator.LED6_RGB = TextBoxLED6.Text ?? "255,255,255";

            _indicator.SetLED(state, style);

        }
        catch(Exception ex)
        {
            IndicatorError(ex.Message);
        }
    }
    
    //
    public void OnSetLEDIndicatorRedClick(object sender, RoutedEventArgs e)
    {
        try
        {
            IndicatorEventErrorClear();

            short style = 1;
            bool state = true;

            _indicator.LED1_RGB = "255,0,0";
            _indicator.LED2_RGB = "255,0,0";
            _indicator.LED3_RGB = "255,0,0";
            _indicator.LED4_RGB = "255,0,0";
            _indicator.LED5_RGB = "255,0,0";
            _indicator.LED6_RGB = "255,0,0";

            _indicator.FLK1_RGB = "255,0,0";
            _indicator.FLK2_RGB = "255,0,0";
            _indicator.FLK3_RGB = "255,0,0";
            _indicator.FLK4_RGB = "255,0,0";
            _indicator.FLK5_RGB = "255,0,0";
            _indicator.FLK6_RGB = "255,0,0";
            _indicator.FLK7_RGB = "255,0,0";
            _indicator.FLK8_RGB = "255,0,0";
            _indicator.FLK9_RGB = "255,0,0";
            _indicator.FLK11_RGB = "255,0,0";

            _indicator.SetLED(state, style);

        }
        catch(Exception ex)
        {
            IndicatorError(ex.Message);
        }
    }

    public void OnSetLEDIndicatorGreenClick(object sender, RoutedEventArgs e)
    {
        try
        {
            IndicatorEventErrorClear();

            short style = 1;
            bool state = true;

            _indicator.LED1_RGB = "0,255,0";
            _indicator.LED2_RGB = "0,255,0";
            _indicator.LED3_RGB = "0,255,0";
            _indicator.LED4_RGB = "0,255,0";
            _indicator.LED5_RGB = "0,255,0";
            _indicator.LED6_RGB = "0,255,0";

            _indicator.FLK1_RGB = "0,255,0";
            _indicator.FLK2_RGB = "0,255,0";
            _indicator.FLK3_RGB = "0,255,0";
            _indicator.FLK4_RGB = "0,255,0";
            _indicator.FLK5_RGB = "0,255,0";
            _indicator.FLK6_RGB = "0,255,0";
            _indicator.FLK7_RGB = "0,255,0";
            _indicator.FLK8_RGB = "0,255,0";
            _indicator.FLK9_RGB = "0,255,0";
            _indicator.FLK11_RGB = "0,255,0";

            _indicator.SetLED(state, style);

        }
        catch(Exception ex)
        {
            IndicatorError(ex.Message);
        }
    }

    public void OnSetLEDIndicatorBlueClick(object sender, RoutedEventArgs e)
    {
        try
        {
            IndicatorEventErrorClear();

            short style = 1;
            bool state = true;

            _indicator.LED1_RGB = "0,0,255";
            _indicator.LED2_RGB = "0,0,255";
            _indicator.LED3_RGB = "0,0,255";
            _indicator.LED4_RGB = "0,0,255";
            _indicator.LED5_RGB = "0,0,255";
            _indicator.LED6_RGB = "0,0,255";

            _indicator.FLK1_RGB = "0,0,255";
            _indicator.FLK2_RGB = "0,0,255";
            _indicator.FLK3_RGB = "0,0,255";
            _indicator.FLK4_RGB = "0,0,255";
            _indicator.FLK5_RGB = "0,0,255";
            _indicator.FLK6_RGB = "0,0,255";
            _indicator.FLK7_RGB = "0,0,255";
            _indicator.FLK8_RGB = "0,0,255";
            _indicator.FLK9_RGB = "0,0,255";
            _indicator.FLK11_RGB = "0,0,255";

            _indicator.SetLED(state, style);

        }
        catch(Exception ex)
        {
            IndicatorError(ex.Message);
        }
    }

    public void OnSetLEDIndicatorMiddleClick(object sender, RoutedEventArgs e)
    {
        try
        {
            IndicatorEventErrorClear();

            short style = 1;
            bool state = true;

            _indicator.LED1_RGB = "128,128,128";
            _indicator.LED2_RGB = "128,128,128";
            _indicator.LED3_RGB = "128,128,128";
            _indicator.LED4_RGB = "128,128,128";
            _indicator.LED5_RGB = "128,128,128";
            _indicator.LED6_RGB = "128,128,128";

            _indicator.FLK1_RGB = "128,128,128";
            _indicator.FLK2_RGB = "128,128,128";
            _indicator.FLK3_RGB = "128,128,128";
            _indicator.FLK4_RGB = "128,128,128";
            _indicator.FLK5_RGB = "128,128,128";
            _indicator.FLK6_RGB = "128,128,128";
            _indicator.FLK7_RGB = "128,128,128";
            _indicator.FLK8_RGB = "128,128,128";
            _indicator.FLK9_RGB = "128,128,128";
            _indicator.FLK11_RGB = "128,128,128";

            _indicator.SetLED(state, style);

        }
        catch(Exception ex)
        {
            IndicatorError(ex.Message);
        }
    }

    //
    public void OnSetLEDAutoClick(object sender, RoutedEventArgs e)
    {
        try
        {
            IndicatorEventErrorClear();

            int interval = int.Parse(TextBoxSetLEDTimer.Text ?? "5");
            LEDTimer.Interval = interval * 1000;

            LedStyle = 1;  //Auto
            Order = 0;
            LEDTimer.Start();

        }
        catch(Exception ex)
        {
            IndicatorError(ex.Message);
        }
    }

    public void OnSetLEDRanDomClick(object sender, RoutedEventArgs e)
    {
        try
        {
            IndicatorEventErrorClear();

            int interval = int.Parse(TextBoxSetLEDTimer.Text ?? "5");
            LEDTimer.Interval = interval * 1000;

            LedStyle = 2; //Random
            LEDTimer.Start();                         
        }
        catch(Exception ex)
        {
            IndicatorError(ex.Message);
        }
    }

    public void OnSetLEDCancelClick(object sender, RoutedEventArgs e)
    {
        try
        {
            IndicatorEventErrorClear();

            if(LEDTimer.Enabled)
                LEDTimer.Stop();

        }
        catch(Exception ex)
        {
            IndicatorError(ex.Message);
        }
    }


    void IndicatorError(String errorMsg)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxResult.Text = errorMsg;
        });
    }

    void IndicatorEventErrorClear()
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxResult.Text = "";
            TextBoxEvent.Text = "";
        });
    }

}
