﻿using System.Diagnostics;
using System.Net;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.VisualBasic.FileIO;

using static LxGenDevIndicator.GenDevIndicatorLib;

namespace LxGenDevIndicator;


public class GenDevIndicator
{
    private TaskCompletionSource<bool>? _tcsCommand;

    // Properties
    public string PortPath
    {
        get { return GenDevIndicatorLib.PortPath; }
        set { GenDevIndicatorLib.PortPath = value; }
    }

    public int BaudRate
    {
        get { return GenDevIndicatorLib.BaudRate; }
        set { GenDevIndicatorLib.BaudRate = value; }
    }

    public int ByteSize
    {
        get { return GenDevIndicatorLib.ByteSize; }
        set { GenDevIndicatorLib.ByteSize = value; }
    }

    public int Parity
    {
        get { return GenDevIndicatorLib.Parity; }
        set { GenDevIndicatorLib.Parity = value; }
    }

    public int StopBits
    {
        get { return GenDevIndicatorLib.StopBits; }
        set { GenDevIndicatorLib.StopBits = value; }
    }

    public bool TraceLog
    {
        get { return GenDevIndicatorLib.TraceLog; }
        set { GenDevIndicatorLib.TraceLog = value; }
    }

    public string LED1_RGB
    {
        get { return GenDevIndicatorLib.LED1_RGB; }
        set { GenDevIndicatorLib.LED1_RGB = value; }
    }

    public string LED2_RGB
    {
        get { return GenDevIndicatorLib.LED2_RGB; }
        set { GenDevIndicatorLib.LED2_RGB = value; }
    }

    public string LED3_RGB
    {
        get { return GenDevIndicatorLib.LED3_RGB; }
        set { GenDevIndicatorLib.LED3_RGB = value; }
    }

    public string LED4_RGB
    {
        get { return GenDevIndicatorLib.LED4_RGB; }
        set { GenDevIndicatorLib.LED4_RGB = value; }
    }

    public string LED5_RGB
    {
        get { return GenDevIndicatorLib.LED5_RGB; }
        set { GenDevIndicatorLib.LED5_RGB = value; }
    }

    public string LED6_RGB
    {
        get { return GenDevIndicatorLib.LED6_RGB; }
        set { GenDevIndicatorLib.LED6_RGB = value; }
    }

    public string FLK1_RGB
    {
        get { return GenDevIndicatorLib.FLK1_RGB; }
        set { GenDevIndicatorLib.FLK1_RGB = value; }
    }

    public string FLK2_RGB
    {
        get { return GenDevIndicatorLib.FLK2_RGB; }
        set { GenDevIndicatorLib.FLK2_RGB = value; }
    }

    public string FLK3_RGB
    {
        get { return GenDevIndicatorLib.FLK3_RGB; }
        set { GenDevIndicatorLib.FLK3_RGB = value; }
    }

    public string FLK4_RGB
    {
        get { return GenDevIndicatorLib.FLK4_RGB; }
        set { GenDevIndicatorLib.FLK4_RGB = value; }
    }

    public string FLK5_RGB
    {
        get { return GenDevIndicatorLib.FLK5_RGB; }
        set { GenDevIndicatorLib.FLK5_RGB = value; }
    }

    public string FLK6_RGB
    {
        get { return GenDevIndicatorLib.FLK6_RGB; }
        set { GenDevIndicatorLib.FLK6_RGB = value; }
    }
    public string FLK7_RGB
    {
        get { return GenDevIndicatorLib.FLK7_RGB; }
        set { GenDevIndicatorLib.FLK7_RGB = value; }
    }
    public string FLK8_RGB
    {
        get { return GenDevIndicatorLib.FLK8_RGB; }
        set { GenDevIndicatorLib.FLK8_RGB = value; }
    }
    public string FLK9_RGB
    {
        get { return GenDevIndicatorLib.FLK9_RGB; }
        set { GenDevIndicatorLib.FLK9_RGB = value; }
    }
    public string FLK11_RGB
    {
        get { return GenDevIndicatorLib.FLK11_RGB; }
        set { GenDevIndicatorLib.FLK11_RGB = value; }
    }

    public string Proximity => GenDevIndicatorLib.Proximity; 
    public string StDevice => GenDevIndicatorLib.StDevice; 
    public string StDoor => GenDevIndicatorLib.StDoor; 
    public string StDoor2 => GenDevIndicatorLib.StDoor2; 
    public string StDoor3 => GenDevIndicatorLib.StDoor3; 
    public string StDoor4 => GenDevIndicatorLib.StDoor4; 
    public string StDoor5 => GenDevIndicatorLib.StDoor5; 
    public string StDoor6 => GenDevIndicatorLib.StDoor6; 
    public string StDoor7 => GenDevIndicatorLib.StDoor7; 
    public string StDoor8 => GenDevIndicatorLib.StDoor8; 
    public string StDoor9 => GenDevIndicatorLib.StDoor9; 
    public string Version => GenDevIndicatorLib.Version; 

    public GenDevIndicator()
    {
        _siuEventDeviceOpenedDelegate = new SIUEventDeviceOpenedDelegate(EventDeviceOpened);
        _siuEventDeviceClosedDelegate = new SIUEventDeviceClosedDelegate(EventDeviceClosed);
        _siuEventInitializeCompletedDelegate = new SIUEventInitializeCompletedDelegate(EventInitializeCompleted);
        _siuEventSetIndicatorCompletedDelegate = new SIUEventSetIndicatorCompletedDelegate(EventSetIndicatorCompleted);
        _siuEventDeviceErrorDelegate = new SIUEventDeviceErrorDelegate(EventDeviceError);
        _siuEventFunctionKeyPressedDelegate = new SIUEventFunctionKeyPressedDelegate(EventFunctionKeyPressed);
        _siuEventFunctionKeyReleasedDelegate = new SIUEventFunctionKeyReleasedDelegate(EventFunctionKeyReleased);
        _siuEventAudioGuidanceChangedDelegate = new SIUEventAudioGuidanceChangedDelegate(EventAudioGuidanceChanged);
        _siuEventStatusChangedDelegate = new SIUEventStatusChangedDelegate(EventStatusChanged);
        _siuEventSetFeedActionCompletedDelegate = new SIUEventSetFeedActionCompletedDelegate(EventSetFeedActionCompleted);
        _siuEventSetLEDCompletedDelegate = new SIUEventSetLEDCompletedDelegate(EventSetLEDCompleted);
        _siuEventAdminSwitchChangedDelegate = new SIUEventAdminSwitchChangedDelegate(EventAdminSwitchChanged);
        _siuEventSetIndicatorRGBCompletedDelegate = new SIUEventSetIndicatorRGBCompletedDelegate(EventSetIndicatorRGBCompleted);
        _siuventMcrPowerResetCompletedDelegate = new SIUEventMcrPowerResetCompletedDelegate(EventMcrPowerResetCompleted);

        SIURegCallbackDeviceOpened(_siuEventDeviceOpenedDelegate);
        SIURegCallbackDeviceClosed(_siuEventDeviceClosedDelegate);
        SIURegCallbackInitializeCompleted(_siuEventInitializeCompletedDelegate);
        SIURegCallbackSetIndicatorCompleted(_siuEventSetIndicatorCompletedDelegate);
        SIURegCallbackDeviceError(_siuEventDeviceErrorDelegate);
        SIURegCallbackFunctionKeyPressed(_siuEventFunctionKeyPressedDelegate);
        SIURegCallbackFunctionKeyReleased(_siuEventFunctionKeyReleasedDelegate);
        SIURegCallbackAudioGuidanceChanged(_siuEventAudioGuidanceChangedDelegate);
        SIURegCallbackStatusChanged(_siuEventStatusChangedDelegate);
        SIURegCallbackSetFeedActionCompleted(_siuEventSetFeedActionCompletedDelegate);
        SIURegCallbackSetLEDCompleted(_siuEventSetLEDCompletedDelegate);
        SIURegCallbackAdminSwitchChanged(_siuEventAdminSwitchChangedDelegate);
        SIURegCallbackSetIndicatorRGBCompleted(_siuEventSetIndicatorRGBCompletedDelegate);
        SIURegCallbackMcrPowerResetCompleted(_siuventMcrPowerResetCompletedDelegate);
    }

    // Methods
    public void OpenDevice()
    {
        short retval = SIUOpenDevice();
        if (retval != 0)
        {
            throw new IndicatorException(retval);
        }
    }

    public void CloseDevice()
    {
        int retval = SIUCloseDevice();
        if (retval != 0)
        {
            throw new IndicatorException(retval);
        }
    }

    public void Initialize()
    {
        int retval = SIUInitializeDevice();
        if (retval != 0)
        {
            throw new IndicatorException(retval);
        }
    }

    public void SetIndicatorById(short IndicatorID, bool State)
    {
        if (_tcsCommand != null)
            throw new IndicatorException(-3);

        _tcsCommand = new TaskCompletionSource<bool>();
        int retval = SIUSetIndicatorById(IndicatorID, State);
        if (retval != 0)
        {
            _tcsCommand = null;
            throw new IndicatorException(retval);
        }
        Task.WaitAll(_tcsCommand.Task);
        _tcsCommand = null;
    }

    public void SetIndicatorByName(string IndicatorName, bool State)
    {
        if (_tcsCommand != null)
            throw new IndicatorException(-3);

        _tcsCommand = new TaskCompletionSource<bool>();
        int retval = SIUSetIndicatorByName(IndicatorName, State);
        if (retval != 0)
        {
            _tcsCommand = null;
            throw new IndicatorException(retval);
        }
        Task.WaitAll(_tcsCommand.Task);
        _tcsCommand = null;
    }

    public string GetIndicatorNames()
    {
        int MaxLength = 1024;
        StringBuilder IndicatorNames = new StringBuilder(MaxLength);

        int retval = SIUGetIndicatorNames(IndicatorNames, MaxLength);
        if (retval < 0)
        {
            throw new IndicatorException(retval);
        }

        return IndicatorNames.ToString();
    }

    public void SetIndicatorNames(string IndicatorNames)
    {
        int retval = SIUSetIndicatorNames(IndicatorNames);
        if (retval != 0)
        {
            throw new IndicatorException(retval);
        }
    }

    public void SetIndicatorByIdEx(short IndicatorID, bool State, short Mode)
    {
        if (_tcsCommand != null)
            throw new IndicatorException(-3);

        _tcsCommand = new TaskCompletionSource<bool>();
        int retval = SIUSetIndicatorByIdEx(IndicatorID, State, Mode);
        if (retval != 0)
        {
            _tcsCommand = null;
            throw new IndicatorException(retval);
        }
        Task.WaitAll(_tcsCommand.Task);
        _tcsCommand = null;
    }

    public void SetIndicatorByNameEx(string IndicatorName, bool State, short Mode)
    {
        int retval = SIUSetIndicatorByNameEx(IndicatorName, State, Mode);
        if (retval != 0)
        {
            throw new IndicatorException(retval);
        }
    }

    public void SetLED(bool State, short Mode)
    {
        if (_tcsCommand != null)
            throw new IndicatorException(-3);

        _tcsCommand = new TaskCompletionSource<bool>();
        int retval = SIUSetLED(State, Mode);
        if (retval != 0)
        {
            _tcsCommand = null;
            throw new IndicatorException(retval);
        }
        Task.WaitAll(_tcsCommand.Task);
        _tcsCommand = null;
    }

    public void SetIndicatorRGB()
    {
        if (_tcsCommand != null)
            throw new IndicatorException(-3);

        _tcsCommand = new TaskCompletionSource<bool>();
        int retval = SIUSetIndicatorRGB();

        if (retval != 0)
        {
            _tcsCommand = null;
            throw new IndicatorException(retval);
        }
        Task.WaitAll(_tcsCommand.Task);
        _tcsCommand = null;
    }

    // Events
    public event EventHandler<String>? OnDeviceOpened;
    public event EventHandler? OnDeviceClosed;
    public event EventHandler? OnInitialized;
    public event EventHandler<SetIndicatorCompleted>? OnSetIndicatorCompleted;
    public event EventHandler<short>? OnDeviceError;
    public event EventHandler<short>? OnFunctionKeyPressed;
    public event EventHandler<short>? OnFunctionKeyReleased;
    public event EventHandler<string>? OnAudioGuidanceChanged;
    public event EventHandler<StatusChanged>? OnStatusChanged;
    public event EventHandler? OnSetFeedActionCompleted;
    public event EventHandler? OnSetLEDCompleted;
    public event EventHandler<string>? OnAdminSwitchChanged;
    public event EventHandler? OnSetIndicatorRGBCompleted;
    //public event EventHandler? OnMcrPowerResetCompleted;

    // Processing callback
    private void EventDeviceOpened(IntPtr pObj, String portPath)
    {
        OnDeviceOpened?.Invoke(null, portPath);
    }

    private void EventDeviceClosed(IntPtr pObj)
    {
        OnDeviceClosed?.Invoke(null, new ());
    }

    private void EventInitializeCompleted(IntPtr pObj)
    {
        if (_tcsCommand != null)
        {
            _tcsCommand.SetResult(true);
        }
        OnInitialized?.Invoke(null, new ());
    }

    private void EventSetIndicatorCompleted(IntPtr pObj, short IndicatorID, string IndicatorName, string CurrentState)
    {
        if (_tcsCommand != null)
        {
            _tcsCommand.SetResult(true);
        }
        OnSetIndicatorCompleted?.Invoke(null, new SetIndicatorCompleted(IndicatorID, IndicatorName, CurrentState));
    }

    private void EventDeviceError(IntPtr pObj, short Reason)
    {
        if (_tcsCommand != null)
        {
            _tcsCommand.SetResult(false);
        }
        OnDeviceError?.Invoke(null, Reason);
    }

    private void EventFunctionKeyPressed(IntPtr pObj, short FunctionKey)
    {
        OnFunctionKeyPressed?.Invoke(null, FunctionKey);
    }

    private void EventFunctionKeyReleased(IntPtr pObj, short FunctionKey)
    {
        OnFunctionKeyReleased?.Invoke(null, FunctionKey);
    }

    private void EventAudioGuidanceChanged(IntPtr pObj, string CurrentState)
    {
        OnAudioGuidanceChanged?.Invoke(null, CurrentState);
    }

    private void EventStatusChanged(IntPtr pObj, string ChangedStatus, string PrevStatus, string CurrentStatus)
    {
        OnStatusChanged?.Invoke(null, new StatusChanged(ChangedStatus, PrevStatus, CurrentStatus));
    }

    private void EventSetFeedActionCompleted(IntPtr pObj)
    {
        if (_tcsCommand != null)
        {
            _tcsCommand.SetResult(true);
        }
        OnSetFeedActionCompleted?.Invoke(null, new ());
    }

    private void EventSetLEDCompleted(IntPtr pObj)
    {
        if (_tcsCommand != null)
        {
            _tcsCommand.SetResult(true);
        }
        OnSetLEDCompleted?.Invoke(null, new ());
    }

    private void EventAdminSwitchChanged(IntPtr pObj, string CurrentStatus)
    {
        OnAdminSwitchChanged?.Invoke(null, CurrentStatus);
    }

    private void EventSetIndicatorRGBCompleted(IntPtr pObj)
    {
        if (_tcsCommand != null)
        {
            _tcsCommand.SetResult(true);
        }
        OnSetIndicatorRGBCompleted?.Invoke(null, new ());
    }

    private void EventMcrPowerResetCompleted(IntPtr pObj)
    {
        //OnMcrPowerResetCompleted?.Invoke(null, new ());
    }


    //  Delegate can be deleted by Gabage collector if it pass as marshalling callback function.
    //  It need to keep reference to get callback function works.
    private readonly SIUEventDeviceOpenedDelegate _siuEventDeviceOpenedDelegate;
    private readonly SIUEventDeviceClosedDelegate _siuEventDeviceClosedDelegate;
    private readonly SIUEventInitializeCompletedDelegate _siuEventInitializeCompletedDelegate;
    private readonly SIUEventSetIndicatorCompletedDelegate _siuEventSetIndicatorCompletedDelegate;
    private readonly SIUEventDeviceErrorDelegate _siuEventDeviceErrorDelegate;
    private readonly SIUEventFunctionKeyPressedDelegate _siuEventFunctionKeyPressedDelegate;
    private readonly SIUEventFunctionKeyReleasedDelegate _siuEventFunctionKeyReleasedDelegate;
    private readonly SIUEventAudioGuidanceChangedDelegate _siuEventAudioGuidanceChangedDelegate;
    private readonly SIUEventStatusChangedDelegate _siuEventStatusChangedDelegate;
    private readonly SIUEventSetFeedActionCompletedDelegate _siuEventSetFeedActionCompletedDelegate;
    private readonly SIUEventSetLEDCompletedDelegate _siuEventSetLEDCompletedDelegate;
    private readonly SIUEventAdminSwitchChangedDelegate _siuEventAdminSwitchChangedDelegate;
    private readonly SIUEventSetIndicatorRGBCompletedDelegate _siuEventSetIndicatorRGBCompletedDelegate;
    private readonly SIUEventMcrPowerResetCompletedDelegate _siuventMcrPowerResetCompletedDelegate;
}
