namespace LxGenDevIndicator;

public class IndicatorException : Exception
{
    public int ErrorCode { get; internal set; }

    internal IndicatorException(int errorCode) : base($"Error Code : {errorCode}")
    {
        ErrorCode = errorCode;
    }
}