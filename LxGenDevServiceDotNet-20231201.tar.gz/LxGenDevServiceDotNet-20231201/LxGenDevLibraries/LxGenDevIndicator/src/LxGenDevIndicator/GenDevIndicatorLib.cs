using System.Runtime.InteropServices;
using System.Text;

namespace LxGenDevIndicator;

public class GenDevIndicatorLib
{
    private const string LibraryName = "libLxGenDevIndicator.so";

    private delegate int GetStringPropertyDelegate(StringBuilder buffer, int bufferLenth);

    private static String GetStringProperty(GetStringPropertyDelegate getProperty)
    {
        int bufferSize = 1024; // Adjust the buffer size as needed
        StringBuilder buffer = new StringBuilder(bufferSize);
        getProperty(buffer, bufferSize);
        return buffer.ToString();
    }

    /*
    //Register Callback Event Function
    typedef void (*SIUEventDeviceOpened)(void* pObj, const char* OpenedPortPath);
    typedef void (*SIUEventDeviceClosed)(void* pObj);
    typedef void (*SIUEventInitializeCompleted)(void* pObj);
    typedef void (*SIUEventSetIndicatorCompleted)(void* pObj, short IndicatorID, const char* IndicatorName, const char* CurrentState);
    typedef void (*SIUEventDeviceError)(void* pObj, short Reason);
    typedef void (*SIUEventFunctionKeyPressed)(void* pObj, short FunctionKey);
    typedef void (*SIUEventFunctionKeyReleased)(void* pObj, short FunctionKey);
    typedef void (*SIUEventAudioGuidanceChanged)(void* pObj, const char* CurrentStatus);
    typedef void (*SIUEventStatusChanged)(void* pObj, const char* ChangedStatus, const char* PrevStatus, const char* CurrentStatus);
    typedef void (*SIUEventSetFeedActionCompleted)(void* pObj);
    typedef void (*SIUEventSetLEDCompleted)(void* pObj);
    typedef void (*SIUEventAdminSwitchChanged)(void* pObj, const char* CurrentStatus);
    typedef void (*SIUEventSetIndicatorRGBCompleted)(void* pObj);
    typedef void (*SIUEventMcrPowerResetCompleted)(void* pObj);

    void SIURegisterCallbackObject(void* pObject);
    void SIURegCallbackDeviceOpened(SIUEventDeviceOpened eventfunc);
    void SIURegCallbackDeviceClosed(SIUEventDeviceClosed eventfunc);
    void SIURegCallbackInitializeCompleted(SIUEventInitializeCompleted eventfunc);
    void SIURegCallbackSetIndicatorCompleted(SIUEventSetIndicatorCompleted eventfunc);
    void SIURegCallbackDeviceError(SIUEventDeviceError eventfunc);
    void SIURegCallbackFunctionKeyPressed(SIUEventFunctionKeyPressed eventfunc);
    void SIURegCallbackFunctionKeyReleased(SIUEventFunctionKeyReleased eventfunc);
    void SIURegCallbackAudioGuidanceChanged(SIUEventAudioGuidanceChanged eventfunc);
    void SIURegCallbackStatusChanged(SIUEventStatusChanged eventfunc);
    void SIURegCallbackSetFeedActionCompleted(SIUEventSetFeedActionCompleted eventfunc);
    void SIURegCallbackSetLEDCompleted(SIUEventSetLEDCompleted eventfunc);
    void SIURegCallbackAdminSwitchChanged(SIUEventAdminSwitchChanged eventfunc);
    void SIURegCallbackSetIndicatorRGBCompleted(SIUEventSetIndicatorRGBCompleted eventfunc);
    void SIURegCallbackMcrPowerResetCompleted(SIUEventMcrPowerResetCompleted eventfunc);
    */

    //Callback Delegates
    internal delegate void SIUEventDeviceOpenedDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String portPath);
    internal delegate void SIUEventDeviceClosedDelegate(IntPtr pObj);
    internal delegate void SIUEventInitializeCompletedDelegate(IntPtr pObj);
    internal delegate void SIUEventSetIndicatorCompletedDelegate(IntPtr pObj, short indicatorID, [MarshalAs(UnmanagedType.LPStr)] String indicatorName, [MarshalAs(UnmanagedType.LPStr)] String currentState);
    internal delegate void SIUEventDeviceErrorDelegate(IntPtr pObj, short reason);
    internal delegate void SIUEventFunctionKeyPressedDelegate(IntPtr pObj, short functionKey);
    internal delegate void SIUEventFunctionKeyReleasedDelegate(IntPtr pObj, short functionKey);
    internal delegate void SIUEventAudioGuidanceChangedDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String currentStatus);
    internal delegate void SIUEventStatusChangedDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String changedStatus, [MarshalAs(UnmanagedType.LPStr)] String prevStatus, [MarshalAs(UnmanagedType.LPStr)] String currentStatus);
    internal delegate void SIUEventSetFeedActionCompletedDelegate(IntPtr pObj);
    internal delegate void SIUEventSetLEDCompletedDelegate(IntPtr pObj);
    internal delegate void SIUEventAdminSwitchChangedDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String currentStatus);
    internal delegate void SIUEventSetIndicatorRGBCompletedDelegate(IntPtr pObj);
    internal delegate void SIUEventMcrPowerResetCompletedDelegate(IntPtr pObj);

    //Raw Event
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIURegCallbackDeviceOpened([MarshalAs(UnmanagedType.FunctionPtr)] SIUEventDeviceOpenedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIURegCallbackDeviceClosed([MarshalAs(UnmanagedType.FunctionPtr)] SIUEventDeviceClosedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIURegCallbackInitializeCompleted([MarshalAs(UnmanagedType.FunctionPtr)] SIUEventInitializeCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIURegCallbackSetIndicatorCompleted([MarshalAs(UnmanagedType.FunctionPtr)] SIUEventSetIndicatorCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIURegCallbackDeviceError([MarshalAs(UnmanagedType.FunctionPtr)] SIUEventDeviceErrorDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIURegCallbackFunctionKeyPressed([MarshalAs(UnmanagedType.FunctionPtr)] SIUEventFunctionKeyPressedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIURegCallbackFunctionKeyReleased([MarshalAs(UnmanagedType.FunctionPtr)] SIUEventFunctionKeyReleasedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIURegCallbackAudioGuidanceChanged([MarshalAs(UnmanagedType.FunctionPtr)] SIUEventAudioGuidanceChangedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIURegCallbackStatusChanged([MarshalAs(UnmanagedType.FunctionPtr)] SIUEventStatusChangedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIURegCallbackSetFeedActionCompleted([MarshalAs(UnmanagedType.FunctionPtr)] SIUEventSetFeedActionCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIURegCallbackSetLEDCompleted([MarshalAs(UnmanagedType.FunctionPtr)] SIUEventSetLEDCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIURegCallbackAdminSwitchChanged([MarshalAs(UnmanagedType.FunctionPtr)] SIUEventAdminSwitchChangedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIURegCallbackSetIndicatorRGBCompleted([MarshalAs(UnmanagedType.FunctionPtr)] SIUEventSetIndicatorRGBCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIURegCallbackMcrPowerResetCompleted([MarshalAs(UnmanagedType.FunctionPtr)] SIUEventMcrPowerResetCompletedDelegate func);


    /*
    //Properties
    int SIUGetPortPath(OUT char* pPortPath, IN int nMaxLength);
    void SIUSetPortPath(IN const char* newValue);
    int SIUGetBaudRate();
    void SIUSetBaudRate(IN int newValue);
    short SIUGetByteSize();
    void SIUSetByteSize(IN short newValue);
    short SIUGetParity();
    void SIUSetParity(IN short newValue);
    short SIUGetStopBits();
    void SIUSetStopBits(IN short newValue);
    bool SIUGetTraceLog();
    void SIUSetTraceLog(IN bool newValue);
    int SIUGetLED1_RGB(OUT char* pLED1_RGB, IN int nMaxLength);
    int SIUGetLED2_RGB(OUT char* pLED2_RGB, IN int nMaxLength);
    int SIUGetLED3_RGB(OUT char* pLED3_RGB, IN int nMaxLength);
    int SIUGetLED4_RGB(OUT char* pLED4_RGB, IN int nMaxLength);
    int SIUGetLED5_RGB(OUT char* pLED5_RGB, IN int nMaxLength);
    int SIUGetLED6_RGB(OUT char* pLED6_RGB, IN int nMaxLength);
    void SIUSetLED1_RGB(IN const char* newValue);
    void SIUSetLED2_RGB(IN const char* newValue);
    void SIUSetLED3_RGB(IN const char* newValue);
    void SIUSetLED4_RGB(IN const char* newValue);
    void SIUSetLED5_RGB(IN const char* newValue);
    void SIUSetLED6_RGB(IN const char* newValue);
    int SIUGetFLK1_RGB(OUT char* pFLK1_RGB, IN int nMaxLength);
    int SIUGetFLK2_RGB(OUT char* pFLK2_RGB, IN int nMaxLength);
    int SIUGetFLK3_RGB(OUT char* pFLK3_RGB, IN int nMaxLength);
    int SIUGetFLK4_RGB(OUT char* pFLK4_RGB, IN int nMaxLength);
    int SIUGetFLK5_RGB(OUT char* pFLK5_RGB, IN int nMaxLength);
    int SIUGetFLK6_RGB(OUT char* pFLK6_RGB, IN int nMaxLength);
    int SIUGetFLK7_RGB(OUT char* pFLK7_RGB, IN int nMaxLength);
    int SIUGetFLK8_RGB(OUT char* pFLK8_RGB, IN int nMaxLength);
    int SIUGetFLK9_RGB(OUT char* pFLK9_RGB, IN int nMaxLength);
    int SIUGetFLK11_RGB(OUT char* pFLK11_RGB, IN int nMaxLength);
    void SIUSetFLK1_RGB(IN const char* newValue);
    void SIUSetFLK2_RGB(IN const char* newValue);
    void SIUSetFLK3_RGB(IN const char* newValue);
    void SIUSetFLK4_RGB(IN const char* newValue);
    void SIUSetFLK5_RGB(IN const char* newValue);
    void SIUSetFLK6_RGB(IN const char* newValue);
    void SIUSetFLK7_RGB(IN const char* newValue);
    void SIUSetFLK8_RGB(IN const char* newValue);
    void SIUSetFLK9_RGB(IN const char* newValue);
    void SIUSetFLK11_RGB(IN const char* newValue);
    int SIUGetProximity(OUT char* pProximity, IN int nMaxLength);
    int SIUGetStDevice(OUT char* pStDevice, IN int nMaxLength);
    int SIUGetStDoor(OUT char* pStDoor, IN int nMaxLength);
    int SIUGetStDoor2(OUT char* pStDoor2, IN int nMaxLength);
    int SIUGetStDoor3(OUT char* pStDoor3, IN int nMaxLength);
    int SIUGetStDoor4(OUT char* pStDoor4, IN int nMaxLength);
    int SIUGetStDoor5(OUT char* pStDoor5, IN int nMaxLength);
    int SIUGetStDoor6(OUT char* pStDoor6, IN int nMaxLength);
    int SIUGetStDoor7(OUT char* pStDoor7, IN int nMaxLength);
    int SIUGetStDoor8(OUT char* pStDoor8, IN int nMaxLength);
    int SIUGetStDoor9(OUT char* pStDoor9, IN int nMaxLength);
    int SIUGetStVersion(OUT char* pStVersion, IN int nMaxLength);
    */

    internal static string PortPath
    {
        get { return GetStringProperty(SIUGetPortPath); }
        set { SIUSetPortPath(value); }
    }

    internal static int BaudRate
    {
        get { return SIUGetBaudRate(); }
        set { SIUSetBaudRate(value); }
    }

    internal static int ByteSize
    {
        get { return SIUGetByteSize(); }
        set { SIUSetByteSize((short)value); }
    }

    internal static int Parity
    {
        get { return SIUGetParity(); }
        set { SIUSetParity((short)value); }
    }

    internal static int StopBits
    {
        get { return SIUGetStopBits(); }
        set { SIUSetStopBits((short)value); }
    }

    internal static bool TraceLog
    {
        get { return SIUGetTraceLog(); }
        set { SIUSetTraceLog(value); }
    }

    internal static string LED1_RGB
    {
        get { return GetStringProperty(SIUGetLED1_RGB); }
        set { SIUSetLED1_RGB(value); }
    }

    internal static string LED2_RGB
    {
        get { return GetStringProperty(SIUGetLED2_RGB); }
        set { SIUSetLED2_RGB(value); }
    }

    internal static string LED3_RGB
    {
        get { return GetStringProperty(SIUGetLED3_RGB); }
        set { SIUSetLED3_RGB(value); }
    }

    internal static string LED4_RGB
    {
        get { return GetStringProperty(SIUGetLED4_RGB); }
        set { SIUSetLED4_RGB(value); }
    }

    internal static string LED5_RGB
    {
        get { return GetStringProperty(SIUGetLED5_RGB); }
        set { SIUSetLED5_RGB(value); }
    }

    internal static string LED6_RGB
    {
        get { return GetStringProperty(SIUGetLED6_RGB); }
        set { SIUSetLED6_RGB(value); }
    }

    internal static string FLK1_RGB
    {
        get { return GetStringProperty(SIUGetFLK1_RGB); }
        set { SIUSetFLK1_RGB(value); }
    }

    internal static string FLK2_RGB
    {
        get { return GetStringProperty(SIUGetFLK2_RGB); }
        set { SIUSetFLK2_RGB(value); }
    }

    internal static string FLK3_RGB
    {
        get { return GetStringProperty(SIUGetFLK3_RGB); }
        set { SIUSetFLK3_RGB(value); }
    }

    internal static string FLK4_RGB
    {
        get { return GetStringProperty(SIUGetFLK4_RGB); }
        set { SIUSetFLK4_RGB(value); }
    }

     internal static string FLK5_RGB
    {
        get { return GetStringProperty(SIUGetFLK5_RGB); }
        set { SIUSetFLK5_RGB(value); }
    }

    internal static string FLK6_RGB
    {
        get { return GetStringProperty(SIUGetFLK6_RGB); }
        set { SIUSetFLK6_RGB(value); }
    }

    internal static string FLK7_RGB
    {
        get { return GetStringProperty(SIUGetFLK7_RGB); }
        set { SIUSetFLK7_RGB(value); }
    }

     internal static string FLK8_RGB
    {
        get { return GetStringProperty(SIUGetFLK8_RGB); }
        set { SIUSetFLK8_RGB(value); }
    }

    internal static string FLK9_RGB
    {
        get { return GetStringProperty(SIUGetFLK9_RGB); }
        set { SIUSetFLK9_RGB(value); }
    }

    internal static string FLK11_RGB
    {
        get { return GetStringProperty(SIUGetFLK11_RGB); }
        set { SIUSetFLK11_RGB(value); }
    }

   
    internal static String Proximity
    {
        get { return GetStringProperty(SIUGetProximity); }
    }

    internal static String StDevice
    {
        get { return GetStringProperty(SIUGetStDevice); }
    }

    internal static String StDoor
    {
        get { return GetStringProperty(SIUGetStDoor); }
    }

    internal static String StDoor2
    {
        get { return GetStringProperty(SIUGetStDoor2); }
    }

    internal static String StDoor3
    {
        get { return GetStringProperty(SIUGetStDoor2); }
    }

    internal static String StDoor4
    {
        get { return GetStringProperty(SIUGetStDoor4); }
    }

    internal static String StDoor5
    {
        get { return GetStringProperty(SIUGetStDoor5); }
    }

    internal static String StDoor6
    {
        get { return GetStringProperty(SIUGetStDoor6); }
    }

    internal static String StDoor7
    {
        get { return GetStringProperty(SIUGetStDoor7); }
    }

    internal static String StDoor8
    {
        get { return GetStringProperty(SIUGetStDoor8); }
    }

    internal static String StDoor9
    {
        get { return GetStringProperty(SIUGetStDoor9); }
    }

    internal static String Version
    {
        get { return GetStringProperty(SIUGetStVersion); }
    }

     // Raw Properties
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetPortPath(StringBuilder pPortPath, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIUSetPortPath([MarshalAs(UnmanagedType.LPStr)] string str);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetBaudRate();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIUSetBaudRate(int baudrate);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short SIUGetByteSize();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIUSetByteSize(short byteSize);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short SIUGetParity();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIUSetParity(short parity);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short SIUGetStopBits();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIUSetStopBits(short stopBits);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern bool SIUGetTraceLog();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIUSetTraceLog([MarshalAs(UnmanagedType.I1)] bool traceLog);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetLED1_RGB(StringBuilder pLED1_RGB, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetLED2_RGB(StringBuilder pLED2_RGB, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetLED3_RGB(StringBuilder pLED3_RGB, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetLED4_RGB(StringBuilder pLED4_RGB, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetLED5_RGB(StringBuilder pLED5_RGB, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetLED6_RGB(StringBuilder pLED6_RGB, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIUSetLED1_RGB([MarshalAs(UnmanagedType.LPStr)] string value);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIUSetLED2_RGB([MarshalAs(UnmanagedType.LPStr)] string value);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIUSetLED3_RGB([MarshalAs(UnmanagedType.LPStr)] string value);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIUSetLED4_RGB([MarshalAs(UnmanagedType.LPStr)] string value);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIUSetLED5_RGB([MarshalAs(UnmanagedType.LPStr)] string value);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIUSetLED6_RGB([MarshalAs(UnmanagedType.LPStr)] string value);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetFLK1_RGB(StringBuilder pFLK1_RGB, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetFLK2_RGB(StringBuilder pFLK2_RGB, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetFLK3_RGB(StringBuilder pFLK3_RGB, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetFLK4_RGB(StringBuilder pFLK4_RGB, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetFLK5_RGB(StringBuilder pFLK5_RGB, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetFLK6_RGB(StringBuilder pFLK6_RGB, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetFLK7_RGB(StringBuilder pFLK7_RGB, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetFLK8_RGB(StringBuilder pFLK8_RGB, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetFLK9_RGB(StringBuilder pFLK9_RGB, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetFLK11_RGB(StringBuilder pFLK11_RGB, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIUSetFLK1_RGB([MarshalAs(UnmanagedType.LPStr)] string value);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIUSetFLK2_RGB([MarshalAs(UnmanagedType.LPStr)] string value);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIUSetFLK3_RGB([MarshalAs(UnmanagedType.LPStr)] string value);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIUSetFLK4_RGB([MarshalAs(UnmanagedType.LPStr)] string value);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIUSetFLK5_RGB([MarshalAs(UnmanagedType.LPStr)] string value);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIUSetFLK6_RGB([MarshalAs(UnmanagedType.LPStr)] string value);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIUSetFLK7_RGB([MarshalAs(UnmanagedType.LPStr)] string value);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIUSetFLK8_RGB([MarshalAs(UnmanagedType.LPStr)] string value);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIUSetFLK9_RGB([MarshalAs(UnmanagedType.LPStr)] string value);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void SIUSetFLK11_RGB([MarshalAs(UnmanagedType.LPStr)] string value);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetProximity(StringBuilder pProximity, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetStDevice(StringBuilder pStDevice, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetStDoor(StringBuilder pStDoor, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetStDoor2(StringBuilder pStDoor2, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetStDoor3(StringBuilder pStDoor3, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetStDoor4(StringBuilder pStDoor4, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetStDoor5(StringBuilder pStDoor5, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetStDoor6(StringBuilder pStDoor6, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetStDoor7(StringBuilder pStDoor7, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetStDoor8(StringBuilder pStDoor8, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetStDoor9(StringBuilder pStDoor9, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int SIUGetStVersion(StringBuilder pStVersion, int nMaxLength);


    /*
    //Methods
    short SIUOpenDevice();
    short SIUCloseDevice();
    short SIUInitializeDevice();
    short SIUSetIndicatorById(IN short IndicatorID, IN bool State);
    short SIUSetIndicatorByName(IN const char* IndicatorName, IN bool State);
    int SIUGetIndicatorNames(IN char* pIndicatorNames, IN int nMaxLength);
    bool SIUSetIndicatorNames(IN const char* IndicatorNames);
    short SIUSetWatchDog(IN bool State);
    short SIUSetFeedAction();
    short SIUSetIndicatorByIdEx(IN short IndicatorID, IN bool State, IN short Mode);
    short SIUSetIndicatorByNameEx(IN const char* IndicatorName, IN bool State, IN short Mode);
    short SIUSetLED(IN bool State, IN short Mode);
    short SIUSetIndicatorRGB();
    short SIUMcrPowerReset();
    */

    // Raw Methods
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short SIUOpenDevice();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short SIUCloseDevice();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short SIUInitializeDevice();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short SIUSetIndicatorById(short IndicatorID, [MarshalAs(UnmanagedType.I1)] bool State);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short SIUSetIndicatorByName([MarshalAs(UnmanagedType.LPStr)] string IndicatorName, [MarshalAs(UnmanagedType.I1)] bool State);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short SIUGetIndicatorNames(StringBuilder pIndicatorNames, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short SIUSetIndicatorNames([MarshalAs(UnmanagedType.LPStr)] string IndicatorNames);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short SIUSetWatchDog([MarshalAs(UnmanagedType.I1)] bool State);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short SIUSetFeedAction();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short SIUSetIndicatorByIdEx(short IndicatorID, [MarshalAs(UnmanagedType.I1)] bool State, short Mode);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short SIUSetIndicatorByNameEx(string IndicatorName, [MarshalAs(UnmanagedType.I1)] bool State, short Mode);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short SIUSetLED([MarshalAs(UnmanagedType.I1)] bool State, short Mode);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short SIUSetIndicatorRGB();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short SIUMcrPowerReset();


}