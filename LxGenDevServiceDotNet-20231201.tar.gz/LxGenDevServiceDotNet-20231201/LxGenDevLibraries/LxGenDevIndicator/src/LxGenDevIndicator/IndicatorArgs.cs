namespace LxGenDevIndicator;

public class SetIndicatorCompleted
{
    public short IndicatorID {get;set;}
    public string IndicatorName {get;set;}
    public string CurrentState {get;set;}

    public SetIndicatorCompleted(short indicatorID,  string indicatorName,  string currentState)
    {
        IndicatorID = indicatorID;
        IndicatorName = indicatorName;
        CurrentState = currentState;
    }

}

public class StatusChanged
{
    public string ChangedStatus {get;set;}
    public string PrevStatus {get;set;}
    public string CurrentStatus {get;set;}

    public StatusChanged(string changedStatus, string prevStatus, string currentStatus)
    {
        ChangedStatus = changedStatus;
        PrevStatus = prevStatus;
        CurrentStatus = currentStatus;
    }
}