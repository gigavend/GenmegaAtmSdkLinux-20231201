using System;
using System.Linq;
using System.Threading.Tasks;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Platform.Storage;
using Avalonia.Threading;
using LxGenDevBarcodeScanner;

namespace LxGenDevBarcodeScannerSample;

public partial class MainWindow : Window
{
    GenDevBarcodeScanner _scanner = new GenDevBarcodeScanner();

    public MainWindow()
    {
        InitializeComponent();

        ComboBoxPorts.ItemsSource = new String[] {"/dev/ttyS0","/dev/ttyS1","/dev/ttyS2","/dev/ttyS3","/dev/ttyS4","/dev/ttyS5", "/dev/ttyUSB0", "/dev/ttyUSB1" };
        ComboBoxPorts.SelectedIndex = 4; // Kiosk default is COM5

        ComboBoxBaudRate.ItemsSource = new int[] { 9600, 38400, 57600,115200, 460800 };
        ComboBoxBaudRate.SelectedIndex = 3; // # inches printer for Kiosk has 115200.

        Initialize();
    }

    public void Initialize()
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            CheckBoxTraceLog.IsDefault = _scanner.TraceLog;
        });

        _scanner.OnDeviceOpened += BarcodeScannerOpened;
        _scanner.OnDeviceClosed += BarcodeScannerClosed;
        _scanner.OnDeviceError += BarcodeScannerDeviceError;     
        _scanner.OnResetCompleted += BarcodeResetCompleted;   
        _scanner.OnScancodeCancel += BarcodeScancodeCancel;   
        _scanner.OnScanCodeCompleted += BarcodeScannerScancodeCompleted;
        _scanner.OnScanDataCompleted += BarcodeScannerScandataCompleted;
        _scanner.OnScancodeError += BarcodeScannerScancodeError;
        _scanner.OnSendSerialCommandCompleted += BarcodeScannerSerialCommandCompleted;
        
    }

    public void BarcodeScannerOpened(Object? sender, String portPath)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Device Opened: {portPath}";
            TextBlockVersion.Text = _scanner.Version;
        });
    }

    private void BarcodeScannerClosed(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Closed device";
        });
    }

    private void BarcodeScannerDeviceError(object? sender, int e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Device Error: {e}";
        });
    }

    private void BarcodeResetCompleted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Reset Completed";
        });
    }

    private void BarcodeScancodeCancel(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Scancode Cancel";
        });
    }

    public void BarcodeScannerScancodeCompleted(Object? sender, String scanCode)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxScancode.Text = scanCode;
            TextBoxEvent.Text = $"Scancode Completed";
        });
    }

    public void BarcodeScannerScandataCompleted(Object? sender, String scanData)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxScandata.Text = scanData;
            TextBoxEvent.Text = $"Scandata Completed";
        });
    }

    private void BarcodeScannerScancodeError(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"Scanecode Error";
        });
    }

    private void BarcodeScannerSerialCommandCompleted(object? sender, EventArgs e)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxEvent.Text = $"SerialCommand Completed";
        });
    }



    public void OnCheckTraceLog(object sender, RoutedEventArgs e)
    {
        _scanner.TraceLog = CheckBoxTraceLog.IsChecked??false;
    }

    public void OnOpenClick(object sender, RoutedEventArgs e)
    {
        try
        {
            _scanner.PortPath = ComboBoxPorts.SelectedValue?.ToString() ?? "/dev/ttyUSB0";
            _scanner.BaudRate = int.Parse(ComboBoxBaudRate.SelectedValue?.ToString() ?? "115200");
            _scanner.MobilePhoneMode = CheckBoxMobilePhone.IsChecked ?? false;
            _scanner.OpenDevice();
        }
        catch(Exception ex)
        {
            ScannerError(ex.Message);
        }
    }

    public void OnScanCodeClick(object sender, RoutedEventArgs e)
    {
        try
        {
            bool flag = CheckBoxPresentation.IsChecked ?? false;
            _scanner.AcceptScanCode(flag);
        }
        catch(Exception ex)
        {
            ScannerError(ex.Message);
        }
    }

    public void OnCancelAcceptClick(object sender, RoutedEventArgs e)
    {
        try
        {
            _scanner.CancelScanCode();
        }
        catch(Exception ex)
        {
            ScannerError(ex.Message);
        }
    }

    public void OnSendCommandClick(object sender, RoutedEventArgs e)
    {
        if (TextBoxSendCommand == null || TextBoxSendCommand.Text == null)
            return;

        try
        {
            string command = TextBoxSendCommand.Text;
            _scanner.SendSerialCommand(command);
        }
        catch(Exception ex)
        {
            ScannerError(ex.Message);
        }
    }

    public void OnResetDeviceClick(object sender, RoutedEventArgs e)
    {
        try
        {
            _scanner.ResetDevice();
        }
        catch(Exception ex)
        {
            ScannerError(ex.Message);
        }
    }


    public void OnCloseClick(object sender, RoutedEventArgs e)
    {
        try
        {
            _scanner.CloseDevice();
        }
        catch(Exception ex)
        {
            ScannerError(ex.Message);
        }
    }


    void ScannerError(String errorMsg)
    {
        Dispatcher.UIThread.Invoke( () => 
        {
            TextBoxResult.Text = errorMsg;
        });
    }
}
