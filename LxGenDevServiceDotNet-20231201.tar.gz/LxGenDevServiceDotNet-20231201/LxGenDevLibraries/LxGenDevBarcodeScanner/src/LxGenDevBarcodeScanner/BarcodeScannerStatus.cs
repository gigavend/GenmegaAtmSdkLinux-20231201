namespace LxGenDevBarcodeScanner;

public class BarcodeScannerstatus
{
    public String Status { get; set; }
    public String PreviousStatus { get; set; }
    public String CurrentStatus { get; set;}

    internal  BarcodeScannerstatus(String status, String prevStatus, String currentStatus)
    {
        Status = status;
        PreviousStatus = prevStatus;
        CurrentStatus = currentStatus;
    }
}
