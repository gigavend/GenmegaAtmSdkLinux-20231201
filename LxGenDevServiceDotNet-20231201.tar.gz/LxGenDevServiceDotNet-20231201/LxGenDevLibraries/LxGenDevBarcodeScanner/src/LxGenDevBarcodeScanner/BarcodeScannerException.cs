namespace LxGenDevBarcodeScanner;

public class BarcodeScannerException : Exception
{
    public int ErrorCode { get; internal set; }

    internal BarcodeScannerException(int errorCode) : base($"Error Code : {errorCode}")
    {
        ErrorCode = errorCode;
    }
}