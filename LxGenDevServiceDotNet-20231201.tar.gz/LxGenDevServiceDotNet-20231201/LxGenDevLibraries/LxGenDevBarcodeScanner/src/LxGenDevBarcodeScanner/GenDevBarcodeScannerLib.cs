using System.Runtime.InteropServices;
using System.Text;

namespace LxGenDevBarcodeScanner;

internal static class GenDevBarcodeScannerLib
{
    private const string LibraryName = "LxGenDevBarcodeScanner.so";

    private delegate int GetStringPropertyDelegate(StringBuilder buffer, int bufferLenth);

    private static String GetStringProperty(GetStringPropertyDelegate getProperty)
    {
        int bufferSize = 1024; // Adjust the buffer size as needed
        StringBuilder buffer = new StringBuilder(bufferSize);
        getProperty(buffer, bufferSize);
        return buffer.ToString();
    }

    /*
    typedef void (*BCSEventDeviceOpened)(void* pobj, const char* OpenedPortPath);
    typedef void (*BCSEventDeviceClosed)(void* pobj);
    typedef void (*BCSEventScanCodeError)(void* pobj);
    typedef void (*BCSEventScanCodeCanceled)(void* pobj);
    typedef void (*BCSEventDeviceError)(void* pobj, short Reason);
    typedef void (*BCSEventScanCodeCompleted)(void* pobj, const char* ScanCode);
    typedef void (*BCSEventDeviceResetCompleted)(void* pobj);
    typedef void (*BCSEventSendSerialCommandCompleted)(void* pobj);
    typedef void (*BCSEventScanDataCompleted)(void* pobj, const char* ScanData, short DataLen);
    
    void BCSRegCallbackDeviceOpened(BCSEventDeviceOpened eventfunc);
    void BCSRegCallbackDeviceClosed(BCSEventDeviceClosed eventfunc);
    void BCSRegCallbackScanCodeError(BCSEventScanCodeError eventfunc);
    void BCSRegCallbackScanCodeCanceled(BCSEventScanCodeCanceled eventfunc);
    void BCSRegCallbackDeviceError(BCSEventDeviceError eventfunc);
    void BCSRegCallbackScanCodeCompleted(BCSEventScanCodeCompleted eventfunc);
    void BCSRegCallbackDeviceResetCompleted(BCSEventDeviceResetCompleted eventfunc);
    void BCSRegCallbackSendSerialCommandCompleted(BCSEventSendSerialCommandCompleted eventfunc);
    void BCSRegCallbackScanDataCompleted(BCSEventScanDataCompleted eventfunc);
    */


    //Callback Delegates
    internal delegate void BCSEventDeviceOpenedDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String portPath);
    internal delegate void BCSEventDeviceClosedDelegate(IntPtr pObj);
    internal delegate void BCSEventScanCodeErrorDelegate(IntPtr pObj);
    internal delegate void BCSEventScanCodeCanceledDelegate(IntPtr pObj);
    internal delegate void BCSEventDeviceErrorDelegate(IntPtr pObj, short reason);
    internal delegate void BCSEventScanCodeCompletedDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String scanCode);
    internal delegate void BCSEventDeviceResetCompletedDelegate(IntPtr pObj);
    internal delegate void BCSEventSendSerialCommandCompletedDelegate(IntPtr pObj);
    internal delegate void BCSEventScanDataCompletedDelegate(IntPtr pObj, [MarshalAs(UnmanagedType.LPStr)] String scanData);
 
    //Raw Event
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BCSRegCallbackDeviceOpened([MarshalAs(UnmanagedType.FunctionPtr)] BCSEventDeviceOpenedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BCSRegCallbackDeviceClosed([MarshalAs(UnmanagedType.FunctionPtr)] BCSEventDeviceClosedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BCSRegCallbackScanCodeError([MarshalAs(UnmanagedType.FunctionPtr)] BCSEventScanCodeErrorDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BCSRegCallbackScanCodeCanceled([MarshalAs(UnmanagedType.FunctionPtr)] BCSEventScanCodeCanceledDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BCSRegCallbackDeviceError([MarshalAs(UnmanagedType.FunctionPtr)] BCSEventDeviceErrorDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BCSRegCallbackScanCodeCompleted([MarshalAs(UnmanagedType.FunctionPtr)] BCSEventScanCodeCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BCSRegCallbackScanDataCompleted([MarshalAs(UnmanagedType.FunctionPtr)] BCSEventScanDataCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BCSRegCallbackDeviceResetCompleted([MarshalAs(UnmanagedType.FunctionPtr)] BCSEventDeviceResetCompletedDelegate func);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BCSRegCallbackSendSerialCommandCompleted([MarshalAs(UnmanagedType.FunctionPtr)] BCSEventSendSerialCommandCompletedDelegate func);


    //Properties
    internal static string PortPath
    {
        get { return GetStringProperty(BCSGetPortPath); }
        set { BCSSetPortPath(value); }
    }

    internal static int BaudRate
    {
        get { return BCSGetBaudRate(); }
        set { BCSSetBaudRate(value); }
    }

    internal static int ByteSize
    {
        get { return BCSGetByteSize(); }
        set { BCSSetByteSize((short)value); }
    }

    internal static int Parity
    {
        get { return BCSGetParity(); }
        set { BCSSetParity((short)value); }
    }

    internal static int StopBits
    {
        get { return BCSGetStopBits(); }
        set { BCSSetStopBits((short)value); }
    }

    internal static bool TraceLog
    {
        get { return BCSGetTraceLog(); }
        set { BCSSetTraceLog(value); }
    }

    internal static bool ScanMode
    {
        get {return BCSGetScanMode();}
        set {BCSSetScanMode(value);}
    }

    internal static bool MobilePhoneMode
    {
        get {return BCSGetMobilePhoneMode();}
        set {BCSSetMobilePhoneMode(value);}
    }

    internal static string StDevice
    {
        get {return GetStringProperty(BCSGetStDevice);}
    }

    internal static String Version
    {
        get { return GetStringProperty(BCSGetVersion); }
    }
 
    //Raw Properties
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int BCSGetPortPath(StringBuilder pPortPath, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BCSSetPortPath([MarshalAs(UnmanagedType.LPStr)] string str);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int BCSGetBaudRate();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BCSSetBaudRate(int baudrate);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short BCSGetParity();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BCSSetParity(short parity);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short BCSGetStopBits();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BCSSetStopBits(short stopBits);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short BCSGetByteSize();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BCSSetByteSize(short byteSize);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    [return: MarshalAs(UnmanagedType.I1)]
    internal static extern bool BCSGetTraceLog();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BCSSetTraceLog([MarshalAs(UnmanagedType.I1)] bool traceLog);


    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    [return: MarshalAs(UnmanagedType.I1)]
    internal static extern bool BCSGetScanMode();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BCSSetScanMode([MarshalAs(UnmanagedType.I1)] bool mode);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    [return: MarshalAs(UnmanagedType.I1)]
    internal static extern bool BCSGetMobilePhoneMode();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern void BCSSetMobilePhoneMode([MarshalAs(UnmanagedType.I1)] bool mode);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int BCSGetStDevice(StringBuilder pPortPath, int nMaxLength);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern int BCSGetVersion(StringBuilder pPortPath, int nMaxLength);


    // Raw Methods
    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short BCSOpenDevice();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short BCSCloseDevice();

     [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short BCSAcceptScanCode([MarshalAs(UnmanagedType.I1)] bool flag);

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short BCSCancelScanCode();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short BCSResetDevice();

    [DllImport(LibraryName, CallingConvention = CallingConvention.Cdecl)]
    internal static extern short BCSSendSerialCommand([MarshalAs(UnmanagedType.LPStr)] string command);
}