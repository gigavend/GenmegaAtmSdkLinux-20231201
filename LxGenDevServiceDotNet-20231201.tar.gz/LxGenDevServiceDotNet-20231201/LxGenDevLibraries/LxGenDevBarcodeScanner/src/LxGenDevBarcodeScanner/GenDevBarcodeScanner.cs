﻿using System.Diagnostics;
using System.Net;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using Microsoft.VisualBasic.FileIO;
using static LxGenDevBarcodeScanner.GenDevBarcodeScannerLib;


namespace LxGenDevBarcodeScanner;

public class GenDevBarcodeScanner
{
    // Properties
    public string PortPath
    {
        get { return GenDevBarcodeScannerLib.PortPath; }
        set { GenDevBarcodeScannerLib.PortPath = value; }
    }

    public int BaudRate
    {
        get { return GenDevBarcodeScannerLib.BaudRate; }
        set { GenDevBarcodeScannerLib.BaudRate = value; }
    }

    public int ByteSize
    {
        get { return GenDevBarcodeScannerLib.ByteSize; }
        set { GenDevBarcodeScannerLib.ByteSize = value; }
    }

    public int Parity
    {
        get { return GenDevBarcodeScannerLib.Parity; }
        set { GenDevBarcodeScannerLib.Parity = value; }
    }

    public int StopBits
    {
        get { return GenDevBarcodeScannerLib.StopBits; }
        set { GenDevBarcodeScannerLib.StopBits = value; }
    }

    public bool TraceLog
    {
        get { return GenDevBarcodeScannerLib.TraceLog; }
        set { GenDevBarcodeScannerLib.TraceLog = value; }
    }

    public bool ScanMode
    {
        get { return GenDevBarcodeScannerLib.ScanMode; }
        set { GenDevBarcodeScannerLib.ScanMode = value; }
    }

    public bool MobilePhoneMode
    {
        get { return GenDevBarcodeScannerLib.MobilePhoneMode; }
        set { GenDevBarcodeScannerLib.MobilePhoneMode = value; }
    }

    public String Version => GenDevBarcodeScannerLib.Version;
    public String StDevice => GenDevBarcodeScannerLib.StDevice;

    public GenDevBarcodeScanner()
    {
        _bcsEventDeviceOpenedDelegate = new BCSEventDeviceOpenedDelegate(EventDeviceOpened);
        _bcsEventDeviceClosedDelegate = new BCSEventDeviceClosedDelegate(EventDeviceClosed);
        _bcsEventDeviceErrorDelegate = new BCSEventDeviceErrorDelegate(EventDeviceError);
        _bcsEventScanCodeErrorDelegate = new BCSEventScanCodeErrorDelegate(EventScancodeError);
        _bcsEventScanCodeCanceledDelegate = new BCSEventScanCodeCanceledDelegate(EventScancodeCancel);
        _bcsEventResetCompletedDelegate = new BCSEventDeviceResetCompletedDelegate(EventResetCompleted);
        _bcsEventScanCodeCompletedDelegate = new BCSEventScanCodeCompletedDelegate(EventScanCodeCompleted);
        _bcsEventSendSerialCommandCompletedDelegate = new BCSEventSendSerialCommandCompletedDelegate(EventSendSerialCommandCompleted);
        _bcsEventScanDataCompletedDelegate = new BCSEventScanDataCompletedDelegate(EventScanDataCompleted);

        BCSRegCallbackDeviceOpened(_bcsEventDeviceOpenedDelegate);
        BCSRegCallbackDeviceClosed(_bcsEventDeviceClosedDelegate);
        BCSRegCallbackDeviceError(_bcsEventDeviceErrorDelegate);
        BCSRegCallbackScanCodeError(_bcsEventScanCodeErrorDelegate);
        BCSRegCallbackScanCodeCanceled(_bcsEventScanCodeCanceledDelegate);
        BCSRegCallbackDeviceResetCompleted(_bcsEventResetCompletedDelegate);
        BCSRegCallbackScanCodeCompleted(_bcsEventScanCodeCompletedDelegate);
        BCSRegCallbackSendSerialCommandCompleted(_bcsEventSendSerialCommandCompletedDelegate);
        BCSRegCallbackScanDataCompleted(_bcsEventScanDataCompletedDelegate);
    }
    
    // Events
    public event EventHandler<String>? OnDeviceOpened;
    public event EventHandler? OnDeviceClosed;
    public event EventHandler<int>? OnDeviceError;
    public event EventHandler? OnScancodeError;
    public event EventHandler? OnScancodeCancel;
    public event EventHandler? OnResetCompleted;
    public event EventHandler? OnSendSerialCommandCompleted;
    public event EventHandler<String>? OnScanCodeCompleted;
    public event EventHandler<String>? OnScanDataCompleted;

    // Processing callback
    void EventDeviceOpened(IntPtr pObj, String portPath)
    {
        OnDeviceOpened?.Invoke(null, portPath);
    }

    private void EventDeviceClosed(IntPtr pObj)
    {
        OnDeviceClosed?.Invoke(null, new ());
    }

    private void EventDeviceError(IntPtr pObj, short reason)
    {
        OnDeviceError?.Invoke(null, reason);
    }

    private void EventScancodeError(IntPtr pObj)
    {
        OnScancodeError?.Invoke(null, new ());
    }

    private void EventScancodeCancel(IntPtr pObj)
    {
        OnScancodeCancel?.Invoke(null, new ());
    }

    private void EventResetCompleted(IntPtr pObj)
    {
        OnResetCompleted?.Invoke(null, new ());
    }

    private void EventSendSerialCommandCompleted(IntPtr pObj)
    {
        OnSendSerialCommandCompleted?.Invoke(null, new ());
    }

    private void EventScanCodeCompleted(IntPtr pObj, String scanCode)
    {
        OnScanCodeCompleted?.Invoke(null, scanCode);
    }

      private void EventScanDataCompleted(IntPtr pObj, String scanData)
    {
        OnScanDataCompleted?.Invoke(null, scanData);
    }


    //
    //  Delegate can be deleted by Gabage collector if it pass as marshalling callback function.
    //  It need to keep reference to get callback function works.
    //
    private readonly BCSEventDeviceOpenedDelegate _bcsEventDeviceOpenedDelegate;
    private readonly BCSEventDeviceClosedDelegate _bcsEventDeviceClosedDelegate;
    private readonly BCSEventScanCodeErrorDelegate _bcsEventScanCodeErrorDelegate;
    private readonly BCSEventScanCodeCanceledDelegate _bcsEventScanCodeCanceledDelegate;
    private readonly BCSEventDeviceErrorDelegate _bcsEventDeviceErrorDelegate;
    private readonly BCSEventScanCodeCompletedDelegate _bcsEventScanCodeCompletedDelegate;
    private readonly BCSEventScanDataCompletedDelegate _bcsEventScanDataCompletedDelegate;
    private readonly BCSEventDeviceResetCompletedDelegate _bcsEventResetCompletedDelegate;
    private readonly BCSEventSendSerialCommandCompletedDelegate _bcsEventSendSerialCommandCompletedDelegate;


    // Methods
    public void OpenDevice()
    {
        short retval = BCSOpenDevice();
        if (retval != 0)
        {
            throw new BarcodeScannerException(retval);
        }
    }

    public void CloseDevice()
    {
        int retval = BCSCloseDevice();
        if (retval != 0)
        {
            throw new BarcodeScannerException(retval);
        }
    }

    public void AcceptScanCode(bool presentationMode)
    {
        int retval = BCSAcceptScanCode(presentationMode);
        if (retval != 0)
        {
            throw new BarcodeScannerException(retval);
        }
    }

    public void CancelScanCode()
    {
        int retval = BCSCancelScanCode();
        if (retval != 0)
        {
            throw new BarcodeScannerException(retval);
        }
    }

    public void ResetDevice()
    {
        int retval = BCSResetDevice();
        if (retval != 0)
        {
            throw new BarcodeScannerException(retval);
        }
    }

    public void SendSerialCommand(string command)
    {
        int retval = BCSSendSerialCommand(command);
        if (retval != 0)
        {
            throw new BarcodeScannerException(retval);
        }
    }


}